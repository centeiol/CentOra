# Phase 0 — Evidence-Based Assessment (Runbook)

**Project:** Table partitioning for an Oracle 19c DW (~60 TB)
**Priority:** accuracy over speed (nothing advances to Phase 1 without documented evidence)
**Documentation basis:** Oracle Database 19c *VLDB and Partitioning Guide*, *SQL Language Reference* (ALTER TABLE), *Database Licensing Information User Manual* 19c, *Performance Tuning Guide* 19c

---

## 0. Execution principles (read before starting)

1. **Everything produces evidence.** Every script runs with `SPOOL` enabled; the `.log` file is an annex of the dossier (section 6). No log, no evidence.
2. **Nothing is modified.** Phase 0 is 100% read-only, except for documentation objects (a SQL Tuning Set and the `fase0_evidence.*` tables), which never touch business data.
3. **Order matters.** Inventory → Workload → Capacity/Growth. Workload is interpreted in light of the inventory; capacity is confirmed in light of the candidate tables.
4. **Licensing gate.** Step 2 uses AWR/ASH (`DBA_HIST_*` views). Check `control_management_pack_access` and your license agreement first: the Diagnostics Pack is extra-cost, and Oracle treats **any direct access** to those views as licensed use. If you are not licensed, follow the **Plan B** documented at the end of `phase0_02_workload_en.sql`.
5. **Statistics hygiene.** If `last_analyzed` on the top tables is badly stale, note it in the dossier. Gathering statistics **now** would change plans and contaminate the evidence — gathering is deliberately deferred to Phase 1.
6. **Execution window.** The scripts read the data dictionary and are lightweight; still, run them outside the DW load peak (identified in Step 2.7). `v$undostat` and `v$archived_log` reflect recent activity — avoid running during or immediately after an anomalous load.

---

## 1. Execution map

| Step | File | Estimated duration | Produces |
|---|---|---|---|
| 1 | `phase0_01_inventory_en.sql` | 15–30 min | Environment, top segments, existing partitioning, MVs, compression |
| 2 | `phase0_02_workload_en.sql` | 30–60 min + analysis | Top SQLs, predicates, per-table access, STS |
| 2b | `phase0_02b_columns_en.sql` | 15–30 min + table scans | Column profile: types, nulls, time span, skew, top values |
| 3 | `phase0_03_capacity_growth_en.sql` | 20–30 min + 7–30 days wait | Space, UNDO, REDO, FRA, growth baseline |
| 4 | `phase0_04_excel_dw_en.sql` | 20–40 min + table scans | Consolidates everything into master tables + 3 Excel-ready CSVs |
| 5 | Fill in the dossier (section 6) | 2–4 h | Phase 0 decision document |

Adjust `DEFINE dias = 7` / `DEFINE days = 7` in the workload scripts (ideally cover at least one full load + query cycle; in DWs often 14 days). Default AWR retention is ~8 days.

---

## 2. Step 1 — Inventory (`phase0_01_inventory_en.sql`)

### What to look for in the output

- **1.2 Licensing:** `PARTITIONING = TRUE` in `v$option` (you have already confirmed); record `control_management_pack_access` and the history in `dba_feature_usage_statistics` — Oracle's own internal audit.
- **1.3 Tablespaces:** note bigfiles, `max_autoextend_gb` and `pct_free`. Flag tablespaces with `< 20%` free and no autoextend ceiling.
- **1.4 Top segments:** these are the **partitioning candidates**. Record the top 20 with GB.
- **1.4b Tables vs `num_rows`:** if `last_analyzed` is months old, treat `num_rows` as indicative — note it in the dossier.
- **1.5 Existing partitioning:** if partitioned tables already exist, record type and count; the skew from the second query (GB per partition for the 20 largest) reveals poorly chosen keys — partitions 10× larger than the median are an **ALERT**.
- **1.6 MVs:** in a DW, fast-refreshable MVs benefit from partitioned base tables (PCT). Record `refresh_method`, `refresh_on`, and any `NEEDS_COMPILE` MVs.
- **1.8 IOT/cluster/parallelism:** IOTs and clustered tables are **not eligible** for `MODIFY PARTITION BY` — they go to `DBMS_REDEFINITION` in Phase 3. Record them now.
- **1.9 LOBs:** large LOBs have their own strategy (partitioning the table partitions the LOBs; `SECUREFILE` compresses/deduplicates).

### Step 1 acceptance criteria

- [ ] Closed list of top 20 candidate tables (owner, name, GB, row count, statistics freshness)
- [ ] No candidate is an IOT/cluster **without being recorded** in the dossier (a known exception, not a surprise)
- [ ] Candidate tablespaces identified with documented free space/ceiling

---

## 3. Step 2 — Workload (`phase0_02_workload_en.sql`)

### What to look for in the output

- **2.1 Gate:** if `control_management_pack_access = NONE` and you have no Diagnostics Pack license → **Plan B**.
- **2.3 Top SQLs:** manually classify each of the top 20 (user report? ETL load? MV refresh?). Record the classification in the dossier.
- **2.4 Plans/predicates (key evidence):** for each critical SQL reading the top tables:
  - The columns in `FILTER_PREDICATES`/`ACCESS_PREDICATES` define the **partitioning key candidates**. In a DW, expect a predominance of business-date range predicates (e.g., `dt_movimento BETWEEN ...`) or equality on dimensions (e.g., `id_produto = ...`).
  - `OPTIONS` with `PARTITION RANGE ALL` in a critical plan = existing partitioning **without pruning** (alert to fix, not to add partitioning).
  - `PARTITION RANGE ITERATOR/SINGLE` with restricted `PSTART/PSTOP` = healthy pruning (for already-partitioned tables).
- **2.5 Access per table:** `TABLE ACCESS FULL` predominance on the top tables is **normal and desirable in a DW** (full scan + pruning + compression). `INDEX ROWID` predominance on huge tables may indicate the current access key does not serve partitioning — record it.
- **2.6 Criticality:** tables touched by many distinct SQLs are high-impact; model them first in Phase 1.
- **2.7 Time profile:** identify the load windows (ETL write windows) and query windows. Online conversions in Phase 3 must avoid the load window.
- **2.8 STS:** `PHASE0_DW_STS` is kept and will be reused in Phase 2 (rewrite/validation) and Phase 3 (before/after comparison). Running the SQL Tuning Advisor on it requires the Tuning Pack — without it, use it as a queryable repository only.

### Plan B (no Diagnostics Pack)

1. Run the captures documented at the end of the script (snapshot `v$sql` and `v$sql_plan` every 6–24 h for 7–14 days, covering load and query windows).
2. Instead of `dba_hist_seg_stat`, measure growth via the Step 3.5 baseline (manual diff).
3. Shorten the analysis window and increase capture frequency on peak days.

### Step 2 acceptance criteria

- [ ] Each candidate table from Step 1 has the predicates of its critical SQLs mapped (table → filter columns → predicate type)
- [ ] Each critical SQL classified (ETL / report / MV / other)
- [ ] DW load and query windows documented
- [ ] STS created and statement count recorded in the dossier

---

## 3b. Step 2b — Column profile of the candidates (`phase0_02b_columns_en.sql`)

Closes the gap between inventory and workload: it provides the **column-level** data the six key-quality tests require. Run after Step 2 (the candidate list comes from the top tables by size — adjust `DEFINE num_tables`).

### What to look for in the output

- **A (catalog):** `data_type` confirms DATE/TIMESTAMP vs NUMBER/VARCHAR2 candidates; `num_distinct` + `histogram` give cardinality; `col_analyzed`/`tab_analyzed` tell whether the numbers can be trusted — if statistics are months old, treat them as indicative.
- **A.2 (immutability proxy):** `updates > 0` since the last statistics means the table was updated. It does not prove the candidate column was touched, but it forces confirmation with the application team before choosing the key.
- **B (time profile, one line per DATE/TIMESTAMP column):**
  - `MONTHS` vs target retention — the span must cover the history that justifies the granularity;
  - `PCT_NULL` — > 5% is an alert (rows without a date concentrate at one extreme, breaking pruning);
  - `PCT_IN_TOP_MONTH` — monthly skew; > 30–40% indicates a useless time granularity or concentrated history;
  - `MIN/MAX` — dates truncated at 00:00 (good candidate) vs scattered times (consider `TRUNC` + virtual column); `MAX` far above SYSDATE = future-dated rows.
- **C (top 5 values per equality column):** stable discrete domains validate List+DEFAULT; `< 100` distinct values rules Hash out on that column (hash requires an almost-unique column).

### Cost and care

- Section B performs 2 full scans of the table per temporal column (min/max + monthly bucket); C performs 1 per equality column. Allow minutes per column on 1–2 TB tables. Run outside the load peak.
- Disable heavy parts if needed: `DEFINE measure_buckets = 0` / `DEFINE measure_top_values = 0`.
- Identifiers are passed through `DBMS_ASSERT` (SQL-injection protection in dynamic SQL).

### Step 2b acceptance criteria

- [ ] Each candidate has its DATE/TIMESTAMP columns cataloged with span, nulls, and measured skew
- [ ] Each candidate has its equality columns cataloged with cardinality and top values
- [ ] Columns with `updates > 0` (A.2) have written confirmation from the application team about immutability
- [ ] No column chosen as key has `PCT_NULL > 5%` or skew > 40% **without written justification in the dossier**

---

## 3c. Step 4 — Excel consolidation (`phase0_04_excel_dw_en.sql`)

Consolidates the evidence from Steps 1–2b into **master tables** persisted in the `fase0_evidence` schema and exports **3 CSVs ready to open in Excel** (`;` delimiter for PT/EN Excel depending on NLS) — each CSV maps to one tab:

| CSV | Content | Dossier section |
|---|---|---|
| `tab1_candidates` | 1 row per candidate table: size, stats, immutability (proxy), existing partitioning, bitmaps, MVs, AWR workload, predicate columns | Sections 2 and 3 |
| `tab2_columns` | 1 row per column: type, stats, temporal/predicate flags + time profile + top1 value — **the consolidated tab** | Section 3b |
| `tab3_top_values` | Top 5 values per discrete column | Skew detail |

Notes:

- **Prerequisite:** create the `fase0_evidence` schema (commented command in the script header).
- **Packs gate:** AWR columns are only populated if `control_management_pack_access` contains `DIAGNOSTIC`; without the pack the script still runs and those columns stay NULL/`NO`.
- **Cost:** the time profile reads each candidate 2× per temporal column; top values 1× per discrete column. Run outside the load peak.
- **Alternative to CSV:** with the master tables created, SQL Developer exports directly to `.xlsx` (SELECT → Export) — a richer format if preferred.
- The `Phase0_Template_EN.xlsx` workbook has the 3 tabs with the exact headers and an example row — just paste each CSV over the matching tab.

---

## 4. Step 3 — Capacity and growth (`phase0_03_capacity_growth_en.sql`)

### What to look for in the output

- **3.1 Space:** confirm that usable free space (or the autoextend ceiling) accommodates converting the 2–3 largest candidates **simultaneously** — rule of thumb: ≥ 1× the largest candidate table in tablespaces separate from the current ones (new segments).
- **3.2 UNDO:** the last-24 h peak is the reference ceiling. `MODIFY PARTITION BY ONLINE` generates UNDO proportional to the table; if the normal peak already approaches the UNDO tablespace ceiling, plan an increase **before** Phase 3.
- **3.3 REDO:** normal daily volume + headroom must fit the FRA during conversion (the conversion generates redo for the data movement; `NOLOGGING` does not apply to online `MODIFY` — document the expected impact).
- **3.4 FRA:** if `pct_used` is routinely > 80%, resolve before Phase 3 (archivelog windows).
- **3.5 Baseline:** re-capture at 7, 14, and 30 days; the diff produces **GB/day per segment**, feeding the growth projection (12 months) and the partition-count sizing in Phase 1.
- **3.6 TEMP:** DW parallel full scans use TEMP; the baseline prevents surprises during Phase 2 validation tests.
- **3.7 Backup:** record actual RMAN window durations — they are the maximum maintenance windows available.

### Step 3 acceptance criteria

- [ ] Conversion space confirmed in writing (numbers in the dossier)
- [ ] UNDO/REDO/FRA within acceptable limits, or an approved increase plan
- [ ] Growth baseline captured (1st capture date recorded) and re-capture dates scheduled
- [ ] Real (RMAN) maintenance window documented

---

## 5. How to read the evidence to choose the key (bridge to Phase 1)

Documented decision **per candidate table**, with log references:

| Question | Evidence | Implication |
|---|---|---|
| Which columns do critical SQLs filter on? | Step 2.4 (predicates) | Key candidates |
| Are the filters ranges (BETWEEN/>/<) or equality? | Step 2.4 | Range → Range/Interval; equality on high cardinality → Hash; discrete domain → List |
| Is there a reliable, immutable **business** date column? | Step 2b.B + analysis | Business date vs load date: partitioning by load date breaks pruning for business-period queries |
| What column do the large tables join on? | Plans (Step 2.4) | Common join key → alignment for partition-wise joins |
| What is the temporal skew of the load? | Step 2.7 + Step 3.5 | Defines granularity (monthly/weekly/daily) |
| Is there differentiated retention (cold data)? | Step 3.5 | Cold tier → compression + read-only (+ hybrid partitioned tables, a 19c feature) |
| How do the MVs refresh? | Step 1.6 | PCT requires the base partitioned by a key included in the MV |

DW-specific notes (document in the dossier):

- **Indexes:** bitmap indexes are common on low-cardinality columns in DWs. With partitioning, prefer **local bitmaps**. Oracle's documentation warns that when enabling compression on a partitioned table with bitmap indexes, they must be marked `UNUSABLE` before and rebuilt after — record which tables have bitmap indexes (query `dba_indexes` in Phase 1).
- **Compression:** 19c offers `ROW STORE COMPRESS ADVANCED` (requires Advanced Compression) and `BASIC` included in EE; in a DW, the typical gain comes from compressing cold partitions. Do not mix the compression decision with the key decision — but measure space now (Step 3) for the projection.
- **EXCHANGE loads:** if the ETL loads a staging table and swaps with `EXCHANGE PARTITION`, interval partitioning aligns naturally with that pattern. Confirm with the ETL team and record it in the dossier (not detectable by SQL).

---

## 6. Dossier template (fill in with the logs)

```markdown
# Phase 0 Dossier — DW 19c Partitioning
Date: ____  Author: ____  Database: ____ (db_unique_name)  PDB: ____

## 1. Environment
- Version/RU: ____  RAC: ____  Role/Data Guard: ____  Container: ____
- control_management_pack_access: ____  Feature usage (partitioning): ____
- Annexes: phase0_01_inventory_*.log

## 2. Candidate tables (top 20)
| # | Owner | Table | GB | num_rows (last_analyzed) | IOT/Cluster? | Bitmap idx? | TS |
|---|---|---|---|---|---|---|---|
(classification + notes per row)

## 3. Workload
- Analysis window: ____ days  AWR retention: ____
- Top SQLs classified: (table sql_id → type → tables touched → key predicates)
- Predicates per candidate: (table → column → type: range/equality)
- Existing partitioning: (table → type → observed skew)
- Load/query windows: ____
- STS: PHASE0_DW_STS (statements: ____)  Annex: phase0_02_workload_*.log

## 3b. Column profile
- Time columns: (table → column → span, null %, top-month skew)
- Equality columns: (table → column → cardinality, top values)
- Immutability confirmations: ____
- Annex: phase0_02b_columns_*.log, phase0_04_excel_*.log

## 4. Capacity
- Usable free space per relevant tablespace: ____
- UNDO: 24 h peak ____ GB / ceiling ____ GB
- REDO: daily average ____ GB / FRA pct_used ____
- Growth baseline: 1st capture ____ ; re-captures scheduled ____ / ____
- Real RMAN window: ____  Annex: phase0_03_capacity_*.log

## 5. Preliminary decisions per candidate
| Table | Scenario (A/B/C/D) | Candidate key | Granularity | Evidence (log/section) | Risks |
|---|---|---|---|---|---|

## 6. Recorded risks and exceptions
- IOT/cluster tables: ____  NEEDS_COMPILE MVs: ____  Stale stats: ____
- No Diagnostics Pack? (Plan B applied?): ____

## 7. Phase 0 acceptance checklist
- [ ] Top 20 candidates closed
- [ ] Predicates mapped per candidate
- [ ] Licensing gate recorded
- [ ] Space/UNDO/REDO validated
- [ ] Growth baseline in progress
- [ ] Dossier peer-reviewed (cross-review by: ____)
```

## 7. Common mistakes to avoid in this phase

- Running the scripts without `SPOOL` (evidence lost).
- Concluding the partitioning key by table size alone — size tells you **where** to partition; predicates tell you **how**.
- Running the SQL Tuning Advisor (Tuning Pack) without a license, for convenience.
- Ignoring "medium" tables (50–200 GB) growing fast (Step 3.5) — the project is not only about today's largest tables.
- Gathering statistics or running DDL tests during Phase 0 and contaminating the baseline.

## 8. Next step (Phase 1)

With the dossier closed: model table by table (scenario A–D), granularity and number of partitions, local indexes, and conversion DDL — always validating pruning with `EXPLAIN PLAN`/`DBMS_XPLAN` in a test environment before any production step.
