# Fase 0 — Levantamento com Evidências (Runbook)

**Projeto:** Particionamento de tabelas numa DW Oracle 19c (~60 TB)
**Prioridade:** acertividade > rapidez (nada avança para a Fase 1 sem evidência documentada)
**Base documental:** Oracle Database 19c *VLDB and Partitioning Guide*, *SQL Language Reference* (ALTER TABLE), *Database Licensing Information User Manual* 19c, *Performance Tuning Guide* 19c

---

## 0. Princípios de execução (ler antes de começar)

1. **Tudo gera evidência.** Cada script corre com `SPOOL` ativo; o ficheiro `.log` é anexo do dossiê (seção 6). Sem log, a execução não conta.
2. **Nada se altera.** A Fase 0 é 100% leitura, exceto a criação de objetos de documentação (SQL Tuning Set e tabelas `dossie_fase0.*`), que não tocam dados de negócio.
3. **Ordem importa.** Inventário → Workload → Capacidade/Crescimento. O workload interpreta-se à luz do inventário; a capacidade confirma-se à luz das tabelas candidatas.
4. **Porta de licenciamento.** O Passo 2 usa AWR/ASH (vistas `DBA_HIST_*`). Verificar primeiro `control_management_pack_access` e o contrato de licenciamento: o Diagnostics Pack é extra-cost e a Oracle considera **qualquer acesso direto** a essas vistas como uso licenciado. Se não houver licença, executar o **Plano B** documentado no final do `fase0_02_workload.sql`.
5. **Estatísticas em alta maré.** Se `last_analyzed` das top tabelas estiver muito desatualizado, anotar no dossiê. Recolher estatísticas **neste momento** altera planos e contaminaria a evidência — a recolha fica para a Fase 1, deliberadamente.
6. **Janela de execução.** Os scripts leem o dicionário e são leves; mesmo assim, correr fora do pico de carga da DW (identificado no Passo 2.7). O `v$undostat` e o `v$archived_log` refletem atividade recente — evitar executar durante/imediatamente após uma carga anómala.

---

## 1. Mapa de execução

| Passo | Ficheiro | Duração estimada | Produz |
|---|---|---|---|
| 1 | `fase0_01_inventario.sql` | 15–30 min | Ambiente, top segmentos, particionamento existente, MVs, compressão |
| 2 | `fase0_02_workload.sql` | 30–60 min + análise | Top SQLs, predicados, acesso por tabela, STS |
| 2b | `fase0_02b_colunas_candidatas.sql` | 15–30 min + leituras das tabelas | Perfil das colunas: tipos, nulos, amplitude temporal, skew, top valores |
| 4 | `fase0_04_excel_dw.sql` | 20–40 min + leituras das tabelas | Consolida tudo em tabelas-mastro + 3 CSV prontos para Excel |
| 3 | `fase0_03_capacidade_crescimento.sql` | 20–30 min + 7–30 dias de espera | Espaço, UNDO, REDO, FRA, baseline de crescimento |
| 4 | Preencher o dossiê (seção 6) | 2–4 h | Documento de decisão da Fase 0 |

Ajustar `DEFINE dias = 7` no Passo 2 (ideal: cobrir pelo menos um ciclo completo de carga + consulta; em DW frequentemente 14 dias). Retenção AWR por defeito é ~8 dias.

---

## 2. Passo 1 — Inventário (`fase0_01_inventario.sql`)

### O que procurar na saída

- **1.2 Licenciamento:** `PARTITIONING = TRUE` no `v$option` (o utilizador já confirmou); registar o valor de `control_management_pack_access` e o histórico em `dba_feature_usage_statistics` — é a auditoria interna da Oracle.
- **1.3 Tablespaces:** anotar bigfiles, `max_autoextend_gb` e `pct_livre`. Marcar tablespaces com `< 20%` livre e sem teto de autoextend.
- **1.4 Top segmentos:** estas são as **candidatas ao particionamento**. Registar top 20 com GB.
- **1.4b Tabelas vs `num_rows`:** se `last_analyzed` tiver meses, os `num_rows` são indicativos — anotar com ressalva no dossiê.
- **1.5 Particionamento existente:** se já houver tabelas particionadas, registar tipo e contagem; o skew da segunda query (GB por partição das 20 maiores) revela chaves mal escolhidas — partições 10× maiores que a mediana são **ALERTA**.
- **1.6 MVs:** em DW, MVs refletidas (fast refresh) beneficiam-se do particionamento da base (PCT). Anotar `refresh_method`, `refresh_on` e MVs `NEEDS_COMPILE`.
- **1.8 IOT/cluster/paralelismo:** tabelas IOT e em cluster **não são elegíveis** ao `MODIFY PARTITION BY` — vão para `DBMS_REDEFINITION` na Fase 3. Já as registar agora.
- **1.9 LOBs:** LOBs grandes têm estratégia própria (particionar a tabela particiona os LOBs; `SECUREFILE` comprime/dedupe).

### Critérios de aceitação do Passo 1

- [ ] Lista fechada das top 20 tabelas candidatas (owner, nome, GB, nº de linhas, frescura das estatísticas)
- [ ] Nenhuma candidata é IOT/cluster **sem registo** no dossiê (são exceção conhecida, não surpresa)
- [ ] Tablespaces das candidatas identificados com espaço livre/teto documentado

---

## 3. Passo 2 — Workload (`fase0_02_workload.sql`)

### O que procurar na saída

- **2.1 Gate:** se `control_management_pack_access = NONE` e não houver licença Diagnostics Pack → **Plano B**.
- **2.3 Top SQLs:** classificar cada um do top 20 manualmente (relatório de utilizadores? carga ETL? refresh de MV?). Registar a classificação no dossiê.
- **2.4 Planos/predicados (evidência-chave):** para cada SQL crítico que lê as top tabelas:
  - As colunas de `FILTER_PREDICATES`/`ACCESS_PREDICATES` definem as **candidatas a chave de particionamento**. Em DW, espera-se predominância de faixas de data de negócio (ex.: `dt_movimento BETWEEN ...`) ou igualdade em dimensões (ex.: `id_produto = ...`).
  - `OPTIONS` com `PARTITION RANGE ALL` num plano crítico = particionamento existente **sem pruning** (alerta para correção, não para nova partição).
  - `PARTITION RANGE ITERATOR/SINGLE` + `PSTART/PSTOP` restritos = pruning saudável (caso de tabelas já particionadas).
- **2.5 Acesso por tabela:** predominância de `TABLE ACCESS FULL` nas top tabelas é **normal e desejável em DW** (full scan + pruning + compressão). Predominância de `INDEX ROWID` em tabelas gigantes pode indicar que a chave de acesso atual não serve o particionamento — anotar.
- **2.6 Criticidade:** tabelas com muitos SQLs distintos são de alto impacto; são as primeiras a modelar na Fase 1.
- **2.7 Perfil temporal:** identificar as janelas de carga (janela de janela de escrita: ETL) e de consulta. As conversões online da Fase 3 devem evitar a janela de carga.
- **2.8 STS:** `FASE0_DW_STS` fica guardado e será reutilizado na Fase 2 (reescrita/validação) e Fase 3 (comparação antes/depois). Executar o SQL Tuning Advisor sobre ele exige Tuning Pack — se não existir, usar apenas como repositório consultável.

### Plano B (sem Diagnostics Pack)

1. Executar as capturas documentadas no fim do script (snapshot de `v$sql` e `v$sql_plan` a cada 6–24 h durante 7–14 dias, cobrindo carga e consulta).
2. Em vez de `dba_hist_seg_stat`, medir crescimento via baseline do Passo 3.5 (diff manual).
3. Reduzir a janela de análise e aumentar a frequência das capturas em dias de pico.

### Critérios de aceitação do Passo 2

- [ ] Cada tabela candidata do Passo 1 tem os predicados dos SQLs críticos mapeados (tabela `candidata → colunas de filtro → tipo de predicado`)
- [ ] Cada SQL crítico classificado (ETL / relatório / MV / outro)
- [ ] Janelas de carga e consulta da DW documentadas
- [ ] STS criado e contagem registada no dossiê

---

## 3b. Passo 2b — Perfil das colunas das candidatas (`fase0_02b_colunas_candidatas.sql`)

Fecha a lacuna entre inventário e workload: fornece os dados de **coluna** que os 6 testes de qualidade da chave exigem. Corre depois do Passo 2 (a lista de candidatas vem das top tabelas por tamanho — ajuste `DEFINE num_tabelas`).

### O que procurar na saída

- **A (catálogo):** `data_type` confirma candidatas DATE/TIMESTAMP vs NUMBER/VARCHAR2; `num_distinct` + `histogram` dão a cardinalidade; `col_analyzed`/`tab_analyzed` dizem se se pode confiar — se as estatísticas tiverem meses, tratar os números como indicativos.
- **A.2 (imutabilidade):** `updates > 0` desde as últimas estatísticas = alarme de que a tabela é atualizada. Não prova que a coluna candidata é atualizada, mas obriga a confirmação com a equipa de aplicação antes de escolher a chave.
- **B (perfil temporal, uma linha por coluna DATE/TIMESTAMP):**
  - `MESES` vs retenção alvo — a amplitude tem de cobrir o histórico que justifica a granularidade;
  - `PCT_NULO` — > 5% é alerta (linhas sem data concentram-se todas no mesmo extremo, partindo o pruning);
  - `PCT_NO_MAIOR_MES` — skew mensal; > 30–40% indica granularidade temporal inútil ou histórico concentrado;
  - `MIN/MAX` — datas truncadas a 00:00 (boa candidata) vs horas espalhadas (avaliar `TRUNC` + coluna virtual); `MAX` muito acima de SYSDATE = dados futuros.
- **C (top 5 valores por coluna de igualdade):** domínios discretos estáveis validam List+DEFAULT; `< 100` valores distintos elimina Hash nessa coluna (hash exige coluna quase única).

### Custo e cuidados

- Secção B faz 2 leituras completas da tabela por coluna temporal (min/max + bucket mensal); C faz 1 por coluna de igualdade. Conte minutos por coluna em tabelas de 1–2 TB. Correr fora do pico de carga.
- Desligar partes pesadas se necessário: `DEFINE medir_buckets = 0` / `DEFINE medir_top_valores = 0`.
- Os identificadores são passados por `DBMS_ASSERT` (proteção contra SQL injection no SQL dinâmico).

### Critérios de aceitação do Passo 2b

- [ ] Cada candidata tem as colunas DATE/TIMESTAMP catalogadas com amplitude, nulos e skew medidos
- [ ] Cada candidata tem as colunas de igualdade catalogadas com cardinalidade e top valores
- [ ] Colunas com `updates > 0` (A.2) têm confirmação escrita da equipa de aplicação sobre imutabilidade
- [ ] Nenhuma coluna escolhida como chave tem `PCT_NULO` > 5% ou skew > 40% **sem justificação escrita no dossiê**

---

## 3c. Passo 4 — Consolidação em Excel (`fase0_04_excel_dw.sql`)

Conjuga a evidência dos Passos 1–2b em **tabelas-mastro** persistentes no schema `dossie_fase0` e exporta **3 CSV prontos a abrir no Excel** (delimitador `;` para Excel PT) — cada CSV corresponde a uma tab:

| CSV | Conteúdo | Equivale a |
|---|---|---|
| `tab1_candidatas` | 1 linha por tabela candidata: tamanho, stats, imutabilidade (proxy), particionamento existente, bitmaps, MVs, workload AWR, colunas em predicados | Secções 2 e 3 do dossiê |
| `tab2_colunas` | 1 linha por coluna: tipo, stats, flags temporal/em predicados + perfil temporal + top1 valor — **a tab conjugada** | Secção 3b |
| `tab3_top_valores` | Top 5 valores por coluna discreta | Detalhe de skew |

Pontos de atenção:

- **Pré-requisito:** criar o schema `dossie_fase0` (comando comentado no cabeçalho do script).
- **Gate de packs:** as colunas AWR só se preenchem se `control_management_pack_access` contiver `DIAGNOSTIC`; sem pack o script corre na mesma e ficam a NULL/`NAO`.
- **Custo:** perfil temporal lê cada candidata 2× por coluna temporal; top valores 1× por coluna discreta. Fora do pico.
- **Alternativa ao CSV:** com as tabelas-mastro criadas, o SQL Developer exporta diretamente para `.xlsx` (SELECT → Export) — formato mais rico se preferir.
- A folha `Fase0_Template.xlsx` tem as 3 tabs com os cabeçalhos exatos e uma linha de exemplo — basta colar cada CSV sobre a tab correspondente.

---

## 4. Passo 3 — Capacidade e crescimento (`fase0_03_capacidade_crescimento.sql`)

### O que procurar na saída

- **3.1 Espaço:** confirmar que o espaço livre utilizável (ou o teto de autoextend) comporta a conversão das 2–3 maiores candidatas **simultaneamente** — regra: ≥ 1× a maior tabela candidata em tablespaces distintos dos atuais (segmentos novos).
- **3.2 UNDO:** o pico das últimas 24 h é o teto de referência. A conversão `MODIFY PARTITION BY ONLINE` gera UNDO proporcional à tabela; se o pico normal já encosta ao teto do tablespace UNDO, planear aumento **antes** da Fase 3.
- **3.3 REDO:** o volume diário normal + headroom deve caber na FRA durante a conversão (a conversão gera REDO do movimento de dados; `NOLOGGING` não se aplica a `MODIFY` online — documentar o impacto esperado).
- **3.4 FRA:** se `pct_usado` > 80% rotineiramente, resolver antes da Fase 3 (janelas de archivelog).
- **3.5 Baseline:** repetir a captura em 7, 14 e 30 dias; o diff produz **GB/dia por segmento**, que alimenta a projeção de crescimento (12 meses) e o dimensionamento do número de partições na Fase 1.
- **3.6 TEMP:** full scans paralelos de DW usam TEMP; o baseline evita surpresas durante testes de validação da Fase 2.
- **3.7 Backup:** registar a duração real das janelas RMAN — são as janelas máximas disponíveis para manutenção.

### Critérios de aceitação do Passo 3

- [ ] Espaço para conversão confirmado por escrito (números no dossiê)
- [ ] UNDO/REDO/FRA dentro de limites aceitáveis, ou plano de aumento aprovado
- [ ] Baseline de crescimento capturada (data da 1ª captura registada) e datas das recapturas agendadas
- [ ] Janela de manutenção real (RMAN) documentada

---

## 5. Como ler a evidência para escolher a chave (ponte para a Fase 1)

Decisão documentada **por tabela candidata**, com referência aos logs:

| Pergunta | Evidência | Implicação |
|---|---|---|
| Que colunas filtram os SQLs críticos? | Passo 2.4 (predicados) | Candidatas a chave |
| Os filtros são de faixa (BETWEEN/>/<) ou de igualdade? | Passo 2.4 | Faixa → Range/Interval; igualdade em alta cardinalidade → Hash; domínio discreto → List |
| Há coluna de data de **negócio** confiável e imutável? | Passo 1.4b + análise | Data de negócio vs data de carga: particionar pela data de carga quebra o pruning das consultas por período de negócio |
| As tabelas grandes fazem join entre si por que coluna? | Planos (Passo 2.4) | Join key comum → alinhamento para partition-wise joins |
| Qual o skew temporal da carga? | Passo 2.7 + Passo 3.5 | Define granularidade (mensal/quinzenal/diária) |
| Há retenção diferenciada (dados frios)? | Passo 3.5 | Tier frio → compressão + read-only (+ hybrid partitioned tables, recurso do 19c) |
| As MVs refrescam como? | Passo 1.6 | PCT exige particionamento da base por chave incluída na MV |

Notas DW específicas (documentar no dossiê):

- **Índices:** em DW, bitmap indexes são comuns em colunas de baixa cardinalidade. Com particionamento, preferir **bitmap locais** (partitioned). A documentação da Oracle alerta que ao ativar compressão em tabela particionada com bitmap indexes é preciso marcá-los `UNUSABLE` antes e reconstruí-los depois — registar quais tabelas têm bitmap indexes (query em `dba_indexes` na Fase 1).
- **Compressão:** 19c oferece `ROW STORE COMPRESS ADVANCED` (exige Advanced Compression) e `BASIC` incluído na EE; em DW, o ganho típico vem de compressão nas partições frias. Não misturar decisão de compressão com a decisão de chave — mas medir espaço agora (Passo 3) para a projeção.
- **Carga via EXCHANGE:** se o ETL carrega dados numa tabela de stage e troca com `EXCHANGE PARTITION`, o particionamento por intervalo alinha-se naturalmente a esse padrão. Confirmar com a equipa ETL e registrar no dossiê (não é detetável por SQL).

---

## 6. Template do dossiê (preencher com os logs)

```markdown
# Dossiê Fase 0 — Particionamento DW 19c
Data: ____  Autor: ____  Base: ____ (db_unique_name)  PDB: ____

## 1. Ambiente
- Versão/RU: ____  RAC: ____  Role/Data Guard: ____  Container: ____
- control_management_pack_access: ____  Feature usage (partitioning): ____
- Anexos: fase0_01_inventario_*.log

## 2. Tabelas candidatas (top 20)
| # | Owner | Tabela | GB | num_rows (last_analyzed) | IOT/Cluster? | Bitmap idx? | TS |
|---|---|---|---|---|---|---|---|
(classificação + observações por linha)

## 3. Workload
- Janela analisada: ____ dias  Retenção AWR: ____
- Top SQLs classificados: (tabela sql_id → tipo → tabelas tocadas → predicados-chave)
- Predicados por tabela candidata: (tabela → coluna → tipo: faixa/igualdade)
- Particionamento existente: (tabela → tipo → skew observado)
- Janelas de carga/consulta: ____
- STS: FASE0_DW_STS (N de stmts: ____)  Anexo: fase0_02_workload_*.log

## 4. Capacidade
- Espaço livre utilizável por tablespace relevante: ____
- UNDO: pico 24h ____ GB / teto ____ GB
- REDO: média diária ____ GB / FRA pct_usado ____
- Baseline de crescimento: 1ª captura ____ ; recapturas agendadas ____ / ____
- Janela RMAN real: ____  Anexo: fase0_03_capacidade_*.log

## 5. Decisões preliminares por tabela candidata
| Tabela | Cenário (A/B/C/D) | Chave candidata | Granularidade | Evidência (log/seção) | Riscos |
|---|---|---|---|---|---|

## 6. Riscos e exceções registadas
- Tabelas IOT/cluster: ____  MVs NEEDS_COMPILE: ____  Stats desatualizadas: ____
- Sem Diagnostics Pack? (Plano B aplicado?): ____

## 7. Checklist de aceitação da Fase 0
- [ ] Top 20 candidatas fechadas
- [ ] Predicados mapeados por candidata
- [ ] Gate de licenciamento registado
- [ ] Espaço/UNDO/REDO validados
- [ ] Baseline de crescimento em curso
- [ ] Dossiê revisto por 2ª pessoa (revisão cruzada: ____)
```

## 7. Erros comuns a evitar nesta fase

- Correr os scripts sem `SPOOL` (evidência perdida).
- Concluir a chave de particionamento olhando só para o tamanho da tabela — o tamanho diz **onde** particionar; os predicados dizem **como**.
- Executar o SQL Tuning Advisor (Tuning Pack) sem licença, por comodidade.
- Ignorar tabelas "médias" (50–200 GB) que crescem rápido (Passo 3.5) — o projeto não é só sobre as maiores de hoje.
- Recolher estatísticas ou fazer testes de DDL durante a Fase 0 e contaminar a linha de base.

## 8. Próximo passo (Fase 1)

Com o dossiê fechado: modelar tabela a tabela (cenário A–D), granularidade e número de partições, índices locais, e DDL de conversão — sempre validando o pruning com `EXPLAIN PLAN`/`DBMS_XPLAN` num ambiente de teste antes de qualquer passo em produção.
