REM ============================================================================
REM FASE 0 - PASSO 2b: PERFIL DAS COLUNAS DAS TABELAS CANDIDATAS
REM Base de dados Oracle 19c (DW) - Projeto de particionamento
REM ----------------------------------------------------------------------------
REM Fecha a lacuna entre o inventario (Passo 1) e o workload (Passo 2):
REM fornece os dados de COLUNA necessarios aos 6 testes de qualidade da
REM chave de particionamento:
REM   A. Catalogo de colunas: tipo, nulabilidade, distinct, histograma,
REM      frescura das estatisticas + proxi de imutabilidade (updates desde as
REM      ultimas estatisticas, via dba_tab_modifications)
REM   B. Perfil temporal: para cada coluna DATE/TIMESTAMP das candidatas:
REM      MIN, MAX, amplitude em meses, % de nulos, skew mensal (maior bucket)
REM   C. Skew de valores: top 5 valores com contagem, para colunas de
REM      igualdade (VARCHAR2/NUMBER de baixa/media cardinalidade)
REM
REM CUSTO: a seccao B faz 2 leituras completas da tabela POR coluna temporal
REM         (1 para min/max/count, 1 para o bucket mensal); a C faz 1 por
REM         coluna de igualdade. Para tabelas de 1-2 TB, conte minutos por
REM         coluna. Corre fora do pico de carga. Pode desligar partes:
REM           DEFINE medir_buckets = 0    (so min/max/count, sem bucket)
REM           DEFINE medir_top_valores = 0
REM
REM Execucao: sqlplus DBA. Ajuste &&num_tabelas ao numero real de candidatas.
REM ============================================================================

SET ECHO ON FEEDBACK ON LINESIZE 250 PAGESIZE 300 TRIMSPOOL ON SERVEROUTPUT ON SIZE UNLIMITED FORMAT WRAPPED

DEFINE num_tabelas = 15
DEFINE medir_buckets = 1
DEFINE medir_top_valores = 1

ALTER SESSION SET NLS_DATE_FORMAT = 'YYYY-MM-DD HH24:MI:SS';

COLUMN captured_at NEW_VALUE v_data NOPRINT
SELECT TO_CHAR(SYSDATE,'YYYYMMDD_HH24MI') captured_at FROM dual;

SPOOL fase0_02b_colunas_&&v_data..log

PROMPT ######################################################################
PROMPT # A. CATALOGO DE COLUNAS DAS TABELAS CANDIDATAS (dicionario - rapido)
PROMPT # num_distinct/histograma sao tao bons quanto as estatisticas:
PROMPT # confirme col_analyzed/tab_analyzed antes de confiar nos numeros.
PROMPT ######################################################################

WITH top_tab AS (
  SELECT owner, segment_name table_name
  FROM   dba_segments
  WHERE  segment_type = 'TABLE'
  AND    owner NOT IN ('SYS','SYSTEM','SYSAUX','OUTLN','AUDSYS','DBSNMP','XDB',
                       'WMSYS','MDSYS','ORDDATA','ORDSYS','CTXSYS','EXFSYS',
                       'OLAPSYS','LBACSYS','DVSYS','OJVMSYS','GSMADMIN_INTERNAL')
  AND    owner NOT LIKE 'APEX%'
  ORDER  BY bytes DESC
  FETCH FIRST &&num_tabelas ROWS ONLY)
SELECT c.owner, c.table_name, c.column_id, c.column_name, c.data_type,
       c.data_length, c.data_precision, c.data_scale, c.nullable,
       c.num_distinct, c.num_nulls, c.histogram,
       TO_CHAR(c.last_analyzed,'YYYY-MM-DD') col_analyzed,
       TO_CHAR(t.last_analyzed,'YYYY-MM-DD') tab_analyzed
FROM   dba_tab_columns c
JOIN   top_tab ON top_tab.owner = c.owner AND top_tab.table_name = c.table_name
JOIN   dba_tables t ON t.owner = c.owner AND t.table_name = c.table_name
WHERE  c.data_type NOT IN ('BLOB','CLOB','NCLOB','LONG','LONG RAW','BFILE')
ORDER  BY c.owner, c.table_name, c.column_id;

PROMPT ######################################################################
PROMPT # A.2 PROXI DE IMUTABILIDADE (tabela inteira, desde as ultimas stats)
PROMPT # updates > 0 significa que A TABELA teve updates; nao garante que a
PROMPT # coluna candidata foi tocada, mas e o alarme que obriga a confirmar
PROMPT # com a equipa de aplicacao antes de escolher a chave.
PROMPT ######################################################################

WITH top_tab AS (
  SELECT owner, segment_name table_name
  FROM   dba_segments
  WHERE  segment_type = 'TABLE'
  AND    owner NOT IN ('SYS','SYSTEM','SYSAUX','OUTLN','AUDSYS','DBSNMP','XDB',
                       'WMSYS','MDSYS','ORDDATA','ORDSYS','CTXSYS','EXFSYS',
                       'OLAPSYS','LBACSYS','DVSYS','OJVMSYS','GSMADMIN_INTERNAL')
  ORDER  BY bytes DESC
  FETCH FIRST &&num_tabelas ROWS ONLY)
SELECT m.table_owner, m.table_name, m.partition_name,
       m.inserts, m.updates, m.deletes, m.timestamp ultima_medicao
FROM   dba_tab_modifications m
JOIN   top_tab ON top_tab.owner = m.table_owner
              AND top_tab.table_name = m.table_name
ORDER  BY m.table_owner, m.table_name, m.partition_name;

PROMPT ######################################################################
PROMPT # B. PERFIL TEMPORAL DAS COLUNAS DATE/TIMESTAMP (leitura completa)
PROMPT # Interpretacao (os 6 testes da chave):
PROMPT #  - MESES vs retencao alvo: amplitude cobre o historico pretendido?
PROMPT #  - PCT_NULO: nulos em massa partem a chave (linhas sem data caem
PROMPT #    todas no mesmo extremo/MAXVALUE) - ALERTA se > 5%
PROMPT #  - PCT_BUCKET: % da tabela no maior mes. Skew > 30-40% indica
PROMPT #    granularidade temporal inutil ou dados historicos concentrados
PROMPT #  - MIN/MAX vs sysdate: dados futuros, truncados em 00:00 (data pura
PROMPT #    e boa candidata) vs horas espalhadas (considere TRUNC / virtual)
PROMPT ######################################################################

DECLARE
  CURSOR c_cols IS
    WITH top_tab AS (
      SELECT owner, segment_name table_name
      FROM   dba_segments
      WHERE  segment_type = 'TABLE'
      AND    owner NOT IN ('SYS','SYSTEM','SYSAUX','OUTLN','AUDSYS','DBSNMP','XDB',
                           'WMSYS','MDSYS','ORDDATA','ORDSYS','CTXSYS','EXFSYS',
                           'OLAPSYS','LBACSYS','DVSYS','OJVMSYS','GSMADMIN_INTERNAL')
      ORDER  BY bytes DESC
      FETCH FIRST &&num_tabelas ROWS ONLY)
    SELECT c.owner, c.table_name, c.column_name, c.data_type
    FROM   dba_tab_columns c
    JOIN   top_tab ON top_tab.owner = c.owner AND top_tab.table_name = c.table_name
    WHERE  c.data_type IN ('DATE','TIMESTAMP','TIMESTAMP WITH TIME ZONE',
                           'TIMESTAMP WITH LOCAL TIME ZONE')
    ORDER  BY c.owner, c.table_name, c.column_id;
  v_min        TIMESTAMP;
  v_max        TIMESTAMP;
  v_rows       NUMBER;
  v_not_null   NUMBER;
  v_top_bucket VARCHAR2(7);
  v_top_rows   NUMBER;
  v_span       NUMBER;
  v_stmt       VARCHAR2(4000);
  FUNCTION q(p_name VARCHAR2) RETURN VARCHAR2 IS
  BEGIN RETURN DBMS_ASSERT.SIMPLE_SQL_NAME(p_name); END;
  FUNCTION qsch(p_name VARCHAR2) RETURN VARCHAR2 IS
  BEGIN RETURN DBMS_ASSERT.SCHEMA_NAME(p_name); END;
BEGIN
  DBMS_OUTPUT.PUT_LINE('TABELA|COLUNA|TIPO|MIN|MAX|MESES|LINHAS|PCT_NULO|MAIOR_MES|PCT_NO_MAIOR_MES');
  FOR r IN c_cols LOOP
    v_stmt := 'SELECT MIN('||q(r.column_name)||'), MAX('||q(r.column_name)||'), COUNT(*), COUNT('||q(r.column_name)||')'
           || ' FROM '||qsch(r.owner)||'.'||q(r.table_name);
    EXECUTE IMMEDIATE v_stmt INTO v_min, v_max, v_rows, v_not_null;

    IF &&medir_buckets = 1 AND v_not_null > 0 THEN
      v_stmt := 'SELECT TO_CHAR('||q(r.column_name)||',''YYYY-MM''), COUNT(*)'
             || ' FROM '||qsch(r.owner)||'.'||q(r.table_name)
             || ' WHERE '||q(r.column_name)||' IS NOT NULL'
             || ' GROUP BY TO_CHAR('||q(r.column_name)||',''YYYY-MM'')'
             || ' ORDER BY COUNT(*) DESC FETCH FIRST 1 ROWS ONLY';
      BEGIN
        EXECUTE IMMEDIATE v_stmt INTO v_top_bucket, v_top_rows;
      EXCEPTION WHEN NO_DATA_FOUND THEN
        v_top_bucket := '-'; v_top_rows := 0;
      END;
    ELSE
      v_top_bucket := '-'; v_top_rows := 0;
    END IF;

    v_span := ROUND(MONTHS_BETWEEN(TRUNC(CAST(v_max AS DATE),'MM'),
                                   TRUNC(CAST(v_min AS DATE),'MM')));
    DBMS_OUTPUT.PUT_LINE(
      r.table_name ||'|'|| r.column_name ||'|'|| r.data_type ||'|'||
      TO_CHAR(v_min,'YYYY-MM-DD HH24:MI:SS') ||'|'||
      TO_CHAR(v_max,'YYYY-MM-DD HH24:MI:SS') ||'|'||
      v_span ||'|'|| v_rows ||'|'||
      TO_CHAR(ROUND((v_rows - v_not_null)/NULLIF(v_rows,0)*100,1),'990.0') ||'|'||
      v_top_bucket ||'|'||
      TO_CHAR(ROUND(v_top_rows/NULLIF(v_not_null,0)*100,1),'990.0'));
  END LOOP;
END;
/

PROMPT ######################################################################
PROMPT # C. SKEW DE COLUNAS DE IGUALDADE (top 5 valores por coluna)
PROMPT # So colunas com 2 a 2000 valores distintos segundo as estatisticas
PROMPT # (fora disso o histograma ou a cardinalidade ja respondem).
PROMPT # Lista/DEFAULT: dominos discretos estaveis = bons candidatos.
PROMPT # Hash: exige coluna QUASE UNICA - se a coluna tem < 100 distinct,
PROMPT # hash nela e escolha errada.
PROMPT ######################################################################

DECLARE
  CURSOR c_cols IS
    WITH top_tab AS (
      SELECT owner, segment_name table_name
      FROM   dba_segments
      WHERE  segment_type = 'TABLE'
      AND    owner NOT IN ('SYS','SYSTEM','SYSAUX','OUTLN','AUDSYS','DBSNMP','XDB',
                           'WMSYS','MDSYS','ORDDATA','ORDSYS','CTXSYS','EXFSYS',
                           'OLAPSYS','LBACSYS','DVSYS','OJVMSYS','GSMADMIN_INTERNAL')
      ORDER  BY bytes DESC
      FETCH FIRST &&num_tabelas ROWS ONLY)
    SELECT c.owner, c.table_name, c.column_name, c.data_type, c.num_distinct
    FROM   dba_tab_columns c
    JOIN   top_tab ON top_tab.owner = c.owner AND top_tab.table_name = c.table_name
    WHERE  c.data_type IN ('VARCHAR2','NVARCHAR2','CHAR','NUMBER','NCHAR')
    AND    c.num_distinct BETWEEN 2 AND 2000
    ORDER  BY c.owner, c.table_name, c.column_id;
  v_val  VARCHAR2(4000);
  v_cnt  NUMBER;
  v_tot  NUMBER;
  v_linha VARCHAR2(32767);
  v_stmt VARCHAR2(4000);
  FUNCTION q(p_name VARCHAR2) RETURN VARCHAR2 IS
  BEGIN RETURN DBMS_ASSERT.SIMPLE_SQL_NAME(p_name); END;
  FUNCTION qsch(p_name VARCHAR2) RETURN VARCHAR2 IS
  BEGIN RETURN DBMS_ASSERT.SCHEMA_NAME(p_name); END;
BEGIN
  FOR r IN c_cols LOOP
    v_stmt := 'SELECT COUNT(*) FROM '||qsch(r.owner)||'.'||q(r.table_name);
    EXECUTE IMMEDIATE v_stmt INTO v_tot;

    v_stmt := 'SELECT RTRIM(TO_CHAR('||q(r.column_name)||')), COUNT(*)'
           || ' FROM '||qsch(r.owner)||'.'||q(r.table_name)
           || ' GROUP BY '||q(r.column_name)
           || ' ORDER BY COUNT(*) DESC FETCH FIRST 5 ROWS ONLY';
    v_linha := r.table_name ||'|'|| r.column_name ||'|'|| r.data_type
            ||'|distinct='|| r.num_distinct ||'|linhas='|| v_tot ||' -> ';
    -- loop explicito com cursor dinamico
    DECLARE
      TYPE t_cur IS REF CURSOR;
      c t_cur;
    BEGIN
      OPEN c FOR v_stmt;
      LOOP
        FETCH c INTO v_val, v_cnt;
        EXIT WHEN c%NOTFOUND;
        v_linha := v_linha ||' ['||v_val||'='||v_cnt
                ||' ('||TO_CHAR(ROUND(v_cnt/NULLIF(v_tot,0)*100,1),'990.0')||'%)]';
      END LOOP;
      CLOSE c;
    END;
    DBMS_OUTPUT.PUT_LINE(v_linha);
  END LOOP;
END;
/

SPOOL OFF
PROMPT FIM DO PASSO 2b. Anexe o log ao dossiê (secção 3 do template).
