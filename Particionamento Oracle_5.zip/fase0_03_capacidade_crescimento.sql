REM ============================================================================
REM FASE 0 - PASSO 3: CAPACIDADE, CRESCIMENTO E JANELAS OPERACIONAIS
REM Base de dados Oracle 19c (DW, ~60 TB) - Projeto de particionamento
REM ----------------------------------------------------------------------------
REM Objetivo: documentar com evidencia:
REM   3.1 Espaco por tablespace (incl. autoextend e ASM)
REM   3.2 UNDO: pico recente (a conversao online gera UNDO pesado)
REM   3.3 REDO/arquivamento: volume diario (afeta janela e espaco de FRA)
REM   3.4 FRA (fast recovery area) - pressao durante conversao
REM   3.5 Baseline de crescimento (tabela de snapshot + query de diff)
REM   3.6 TEMP (sort/hash joins da DW)
REM   3.7 Backup recente (duracao/janela do RMAN)
REM
REM Execucao: sqlplus DBA. Parte 3.5 cria TABELAS - executar apenas com
REM           autorizacao e num schema de documentacao proprio (sugestao:
REM           criar o utilizador DOSSIE_FASE0). Nada aqui toca em dados de
REM           negocio.
REM ============================================================================

SET ECHO ON FEEDBACK ON LINESIZE 250 PAGESIZE 300 TRIMSPOOL ON SERVEROUTPUT ON SIZE UNLIMITED

ALTER SESSION SET NLS_DATE_FORMAT = 'YYYY-MM-DD HH24:MI:SS';

COLUMN captured_at NEW_VALUE v_data NOPRINT
SELECT TO_CHAR(SYSDATE,'YYYYMMDD_HH24MI') captured_at FROM dual;

SPOOL fase0_03_capacidade_&&v_data..log

PROMPT ######################################################################
PROMPT # 3.1 ESPACO POR TABLESPACE (com teto de autoextend)
PROMPT # >>> Evidencia para: "cabem os novos segmentos da conversao?" <<<
PROMPT # Regra de bolso para a Fase 1: espaco livre utilizavel >= 1x a maior
PROMPT # tabela candidata (a conversao cria NOVOS segmentos; so libera os
PROMPT # antigos no fim, se nao reutilizar os mesmos tablespaces).
PROMPT ######################################################################

WITH f AS (
  SELECT tablespace_name, SUM(bytes) free_bytes
  FROM   dba_free_space GROUP BY tablespace_name)
SELECT df.tablespace_name,
       ROUND(SUM(df.bytes)/POWER(1024,3),1) alloc_gb,
       ROUND(NVL(f.free_bytes,0)/POWER(1024,3),1) free_gb,
       ROUND((SUM(df.bytes)-NVL(f.free_bytes,0))/POWER(1024,3),1) used_gb,
       ROUND(SUM(CASE WHEN df.autoextensible='YES' THEN df.maxbytes
                      ELSE df.bytes END)/POWER(1024,3),1) teto_autoextend_gb,
       ROUND(NVL(f.free_bytes,0)/SUM(df.bytes)*100,1) pct_livre
FROM   dba_data_files df
LEFT JOIN f ON f.tablespace_name = df.tablespace_name
GROUP  BY df.tablespace_name, f.free_bytes
ORDER  BY used_gb DESC;

SELECT tablespace_name,
       ROUND(SUM(bytes)/POWER(1024,3),1) alloc_gb
FROM   dba_temp_files GROUP BY tablespace_name ORDER BY alloc_gb DESC;

-- Se nao for ASM / sem acesso: ignore ORA-00942 ou erro de privilegio.
SELECT name, state, type,
       ROUND(total_mb/1024,1) total_gb, ROUND(free_mb/1024,1) free_gb,
       ROUND((total_mb-free_mb)/total_mb*100,1) pct_usado
FROM   v$asm_diskgroup ORDER BY total_gb DESC;

PROMPT ######################################################################
PROMPT # 3.2 UNDO - pico das ultimas 24h (v$undostat, janela aprox. 7 dias)
PROMPT # A conversao online (MODIFY PARTITION BY ONLINE) e as cargas DW
PROMPT # competem pelo UNDO: registrar o pico como referencia de teto.
PROMPT ######################################################################

SELECT ROUND(MAX(u.undoblks) * t.block_size / POWER(1024,3), 2) pico_undo_gb_24h,
       ROUND(MAX(u.maxquerylen)/60,1) maior_query_min,
       MAX(u.tuned_undoretention) tuned_retention_s
FROM   v$undostat u
CROSS JOIN (SELECT block_size FROM dba_tablespaces
            WHERE tablespace_name =
                  (SELECT UPPER(value) FROM v$parameter
                   WHERE name = 'undo_tablespace')) t
WHERE  u.begin_time > SYSDATE - 1;

SELECT tablespace_name,
       ROUND(SUM(bytes)/POWER(1024,3),1) undo_alloc_gb,
       ROUND(SUM(CASE WHEN autoextensible='YES' THEN maxbytes ELSE bytes END)
             /POWER(1024,3),1) undo_teto_gb
FROM   dba_data_files
WHERE  tablespace_name = (SELECT UPPER(value) FROM v$parameter
                          WHERE name = 'undo_tablespace')
GROUP  BY tablespace_name;

PROMPT ######################################################################
PROMPT # 3.3 REDO - volume diario arquivado (14 dias)
PROMPT # Conversao e rebuild de indices disparam REDO; cruzar com a FRA (3.4)
PROMPT # e com a janela de backup de archivelogs.
PROMPT ######################################################################

SELECT TRUNC(completion_time) dia,
       COUNT(*) archivelogs,
       ROUND(SUM(blocks*block_size)/POWER(1024,3),1) gb_redo
FROM   v$archived_log
WHERE  completion_time > SYSDATE - 14
GROUP  BY TRUNC(completion_time)
ORDER  BY dia DESC;

SELECT COUNT(*) grupos, SUM(bytes)/POWER(1024,2) redo_mb_total
FROM   v$log;

SELECT l.thread#, l.group#, l.members, ROUND(l.bytes/1048576) mb,
       l.status, lf.member
FROM   v$log l JOIN v$logfile lf USING (group#)
ORDER  BY l.thread#, l.group#;

PROMPT ######################################################################
PROMPT # 3.4 FAST RECOVERY AREA - espaco e pressao
PROMPT ######################################################################

SELECT name,
       ROUND(space_limit/POWER(1024,3),1) fra_limite_gb,
       ROUND(space_used/POWER(1024,3),1) fra_usado_gb,
       ROUND(space_used/space_limit*100,1) pct_usado,
       number_of_files ficheiros
FROM   v$recovery_file_dest;

SELECT file_type,
       ROUND(percent_space_used,1) pct_espaco,
       ROUND(percent_space_reclaimable,1) pct_recuperavel,
       number_of_files
FROM   v$recovery_area_usage
ORDER  BY percent_space_used DESC;

PROMPT ######################################################################
PROMPT # 3.5 BASELINE DE CRESCIMENTO (cria tabelas - executar 1 vez)
PROMPT # Reexecutar a query de DIFF passado 7/14/30 dias mede a taxa de
PROMPT # crescimento real por segmento (GB/dia) - entrada da modelagem.
PROMPT ######################################################################

-- Sugestao: criar previamente um utilizador de documentacao
--   CREATE USER dossie_fase0 IDENTIFIED BY ...;  (e grantar CREATE TABLE)
--   Ajuste o owner conforme o vosso padrao.

CREATE TABLE dossie_fase0.seg_baseline_202610 AS
SELECT SYSDATE captured_at, owner, segment_name, partition_name,
       segment_type, tablespace_name, bytes
FROM   dba_segments
WHERE  owner NOT IN ('SYS','SYSTEM','SYSAUX','OUTLN','AUDSYS','DBSNMP','XDB',
                     'WMSYS','MDSYS','ORDDATA','ORDSYS','CTXSYS','EXFSYS',
                     'OLAPSYS','LBACSYS','DVSYS','OJVMSYS','GSMADMIN_INTERNAL')
AND    owner NOT LIKE 'APEX%';

-- Datafiles baseline (para detetar autoextend consumido)
CREATE TABLE dossie_fase0.df_baseline_202610 AS
SELECT SYSDATE captured_at, tablespace_name, file_name, bytes, maxbytes,
       autoextensible FROM dba_data_files;

-- DIFF (executar na 2a captura, trocando o nome da tabela nova):
--   crescimento_gb = (bytes agora - bytes baseline) / 2^30 ; dividir pelos
--   dias decorridos para obter GB/dia e projetar 12 meses.
-- Exemplo (descomentar e adaptar na 2a passagem):
-- SELECT b.owner, b.segment_name, b.partition_name,
--        ROUND((s.bytes-b.bytes)/POWER(1024,3),2) cresc_gb,
--        ROUND((s.bytes-b.bytes)/POWER(1024,3)/
--              (SYSDATE-b.captured_at),3) gb_por_dia
-- FROM   dossie_fase0.seg_baseline_202610 b
-- JOIN   (SELECT owner, segment_name, partition_name, bytes
--         FROM dba_segments WHERE owner NOT IN (...)) s
--   ON   s.owner=b.owner AND s.segment_name=b.segment_name
--   AND  NVL(s.partition_name,'-')=NVL(b.partition_name,'-')
-- ORDER  BY cresc_gb DESC FETCH FIRST 50 ROWS ONLY;

PROMPT ######################################################################
PROMPT # 3.6 TEMP - espaco e pico de sort/hash da DW
PROMPT ######################################################################

SELECT tablespace_name,
       ROUND(tablespace_size/POWER(1024,3),1) total_gb,
       ROUND(free_space/POWER(1024,3),1)  free_gb
FROM   dba_temp_free_space;

SELECT username, session_addr, sql_id,
       ROUND(blocks * t.block_size / POWER(1024,3),2) gb_atual_temp
FROM   v$sort_segment s
CROSS JOIN (SELECT block_size FROM dba_tablespaces
            WHERE contents='TEMPORARY' AND ROWNUM=1) t
WHERE  ROWNUM <= 20;

PROMPT ######################################################################
PROMPT # 3.7 BACKUP RMAN - janelas recentes (cruzar com 3.3/3.4)
PROMPT ######################################################################

SELECT operation, status,
       COUNT(*) execucoes,
       MIN(start_time) primeira, MAX(end_time) ultima,
       ROUND(SUM((end_time-start_time)*24*60),1) minutos_totais
FROM   v$rman_status
WHERE  start_time > SYSDATE - 14
AND    operation IN ('BACKUP','ARCHIVELOG BACKUP','VALIDATE')
GROUP  BY operation, status
ORDER  BY operation, status;

SPOOL OFF
PROMPT FIM DO PASSO 3. Guarde o log; repita a baseline em 7/14/30 dias.
