REM ============================================================================
REM FASE 0 - PASSO 2: PERFIL DE CARGA DE TRABALHO (WORKLOAD) DA DW
REM Base de dados Oracle 19c - Projeto de particionamento
REM ----------------------------------------------------------------------------
REM Objetivo: identificar, com evidencia historica (AWR):
REM   2.1 Gate de licenciamento: Diagnostics Pack disponivel/licenciado?
REM   2.2 Janela temporal dos snapshots AWR disponiveis
REM   2.3 Top SQLs por tempo decorrido / leitura fisica
REM   2.4 Texto e planos dos SQLs topo (PREDICADOS = futura chave de particao)
REM   2.5 Forma como cada tabela grande e acedida (FULL vs INDEX, particoes)
REM   2.6 Quantos SQLs distintos tocam cada tabela grande (criticidade)
REM   2.7 Perfil temporal (janelas de carga/consulta da DW)
REM   2.8 Captura de SQL Tuning Set (evidencia reutilizavel na Fase 1/2)
REM
REM PLANO B (sem Diagnostics Pack): ver seccao no fim do ficheiro.
REM
REM Execucao: sqlplus DBA. Ajuste &&dias (padrao 7) consoante a retencao AWR.
REM NOTA: em DW o ideal e cobrir um ciclo completo de carga E de consulta
REM       (ex.: 7 a 14 dias). O retention AWR padrao e 8 dias.
REM ============================================================================

SET ECHO ON FEEDBACK ON LINESIZE 250 PAGESIZE 300 TRIMSPOOL ON SERVEROUTPUT ON SIZE UNLIMITED

DEFINE dias = 7

ALTER SESSION SET NLS_DATE_FORMAT = 'YYYY-MM-DD HH24:MI:SS';

COLUMN captured_at NEW_VALUE v_data NOPRINT
SELECT TO_CHAR(SYSDATE,'YYYYMMDD_HH24MI') captured_at FROM dual;

SPOOL fase0_02_workload_&&v_data..log

PROMPT ######################################################################
PROMPT # 2.1 GATE: DIAGNOSTICS PACK (AWR/ASH)
PROMPT ######################################################################

-- Se o valor for NONE, as vistas DBA_HIST_* estao bloqueadas/a uso delas exige
-- licenca Diagnostics Pack: pare e use o PLANO B no fim deste ficheiro.
SELECT value control_management_pack_access
FROM   v$parameter WHERE name = 'control_management_pack_access';

SELECT name, currently_used, detected_usages
FROM   dba_feature_usage_statistics
WHERE  LOWER(name) LIKE '%workload repository%'
   OR  LOWER(name) LIKE '%active session history%';

PROMPT ######################################################################
PROMPT # 2.2 JANELA TEMPORAL DOS SNAPSHOTS AWR
PROMPT ######################################################################

SELECT MIN(begin_interval_time) janela_inicio,
       MAX(end_interval_time) janela_fim,
       COUNT(*) snapshots,
       ROUND(AVG(EXTRACT(SECOND FROM (end_interval_time - begin_interval_time))/60 +
                 EXTRACT(MINUTE FROM (end_interval_time - begin_interval_time)) +
                 EXTRACT(HOUR   FROM (end_interval_time - begin_interval_time))*60),1) intervalo_medio_min
FROM   dba_hist_snapshot
WHERE  begin_interval_time > SYSDATE - &&dias;

-- Se a janela vier vazia/menor que &&dias: retencao AWR insuficiente.
-- Para alargar (exige Diagnostics Pack):
--   EXEC dbms_workload_repository.modify_snapshot_settings(retention => 20160, interval => 60);

PROMPT ######################################################################
PROMPT # 2.3 TOP 40 SQLs POR TEMPO (ultimos &&dias dias)
PROMPT ######################################################################

SELECT st.sql_id, st.plan_hash_value,
       ROUND(SUM(st.elapsed_time_delta)/1e6/60,1)      minutos,
       SUM(st.executions_delta)                        execucoes,
       ROUND(SUM(st.disk_reads_delta)/
             NULLIF(SUM(st.executions_delta),0))        reads_por_exec,
       ROUND(SUM(st.rows_processed_delta)/
             NULLIF(SUM(st.executions_delta),0))        linhas_por_exec,
       ROUND(SUM(st.physical_read_bytes_delta)/POWER(1024,3),1) gb_lidos_fisicos
FROM   dba_hist_sqlstat st
JOIN   dba_hist_snapshot sn
       ON  sn.snap_id = st.snap_id
       AND sn.dbid = st.dbid
       AND sn.instance_number = st.instance_number
WHERE  sn.begin_interval_time > SYSDATE - &&dias
GROUP  BY st.sql_id, st.plan_hash_value
ORDER  BY minutos DESC
FETCH FIRST 40 ROWS ONLY;

PROMPT ######################################################################
PROMPT # 2.3b TEXTO DOS TOP 20 SQLs (para classificacao manual:
PROMPT      relatorio? carga ETL? job noturno? manter comentario no dossie)
PROMPT ######################################################################

WITH top_sql AS (
  SELECT st.sql_id
  FROM   dba_hist_sqlstat st
  JOIN   dba_hist_snapshot sn
         ON sn.snap_id = st.snap_id AND sn.dbid = st.dbid
         AND sn.instance_number = st.instance_number
  WHERE  sn.begin_interval_time > SYSDATE - &&dias
  GROUP  BY st.sql_id
  ORDER  BY SUM(st.elapsed_time_delta) DESC
  FETCH FIRST 20 ROWS ONLY)
SELECT t.sql_id, DBMS_LOB.SUBSTR(t.sql_text,4000) sql_text
FROM   dba_hist_sqltext t
JOIN   top_sql USING (sql_id)
ORDER  BY t.sql_id;

PROMPT ######################################################################
PROMPT # 2.4 PLANOS E PREDICADOS DOS TOP 20 SQLs
PROMPT # >>> Esta e a evidencia mais importante da Fase 0 <<<
PROMPT # Colunas ACCESS_PREDICATES / FILTER_PREDICATES revelam por que colunas
PROMPT # os dados sao filtrados = candidatas a chave de particionamento.
PROMPT # Procure tambem OPTIONS com 'PARTITION RANGE/LIST ...': se aparecer
PROMPT # 'PARTITION RANGE ALL' em SQL critico, ha particionamento existente
PROMPT # sem pruning (ALERTA).
PROMPT ######################################################################

WITH top_sql AS (
  SELECT st.sql_id
  FROM   dba_hist_sqlstat st
  JOIN   dba_hist_snapshot sn
         ON sn.snap_id = st.snap_id AND sn.dbid = st.dbid
         AND sn.instance_number = st.instance_number
  WHERE  sn.begin_interval_time > SYSDATE - &&dias
  GROUP  BY st.sql_id
  ORDER  BY SUM(st.elapsed_time_delta) DESC
  FETCH FIRST 20 ROWS ONLY)
SELECT p.sql_id, p.plan_hash_value, p.id, p.parent_id,
       p.operation, p.options, p.object_owner, p.object_name, p.object_type,
       p.access_predicates, p.filter_predicates
FROM   dba_hist_sql_plan p
JOIN   top_sql USING (sql_id)
ORDER  BY p.sql_id, p.plan_hash_value, p.id;

PROMPT ######################################################################
PROMPT # 2.5 COMO CADA TABELA GRANDE E ACEDIDA (FULL SCAN vs INDEX ...)
PROMPT ######################################################################

WITH top_tab AS (
  SELECT owner, segment_name table_name
  FROM   dba_segments
  WHERE  segment_type = 'TABLE'
  AND    owner NOT IN ('SYS','SYSTEM','SYSAUX','OUTLN','AUDSYS','DBSNMP','XDB',
                       'WMSYS','MDSYS','ORDDATA','ORDSYS','CTXSYS','EXFSYS',
                       'OLAPSYS','LBACSYS','DVSYS','OJVMSYS','GSMADMIN_INTERNAL')
  ORDER  BY bytes DESC
  FETCH FIRST 25 ROWS ONLY)
SELECT t.owner, t.table_name, p.operation, p.options,
       COUNT(DISTINCT p.sql_id) sqls_distintos
FROM   top_tab t
JOIN   dba_hist_sql_plan p
       ON p.object_owner = t.owner AND p.object_name = t.table_name
WHERE  p.sql_id IN (SELECT sql_id FROM dba_hist_sqlstat)
GROUP  BY t.owner, t.table_name, p.operation, p.options
ORDER  BY t.owner, t.table_name, sqls_distintos DESC;

PROMPT ######################################################################
PROMPT # 2.6 CRITICIDADE: N de SQLs DISTINTOS QUE TOCAM CADA TABELA GRANDE
PROMPT ######################################################################

WITH top_tab AS (
  SELECT owner, segment_name table_name
  FROM   dba_segments
  WHERE  segment_type = 'TABLE'
  AND    owner NOT IN ('SYS','SYSTEM','SYSAUX','OUTLN','AUDSYS','DBSNMP','XDB',
                       'WMSYS','MDSYS','ORDDATA','ORDSYS','CTXSYS','EXFSYS',
                       'OLAPSYS','LBACSYS','DVSYS','OJVMSYS','GSMADMIN_INTERNAL')
  ORDER  BY bytes DESC
  FETCH FIRST 25 ROWS ONLY)
SELECT t.owner, t.table_name,
       COUNT(DISTINCT p.sql_id)        sqls_distintos,
       COUNT(DISTINCT p.plan_hash_value) planos_distintos
FROM   top_tab t
JOIN   dba_hist_sql_plan p
       ON p.object_owner = t.owner AND p.object_name = t.table_name
GROUP  BY t.owner, t.table_name
ORDER  BY sqls_distintos DESC;

PROMPT ######################################################################
PROMPT # 2.7 PERFIL TEMPORAL (janelas de carga vs consulta da DW)
PROMPT ######################################################################

SELECT TO_CHAR(sample_time,'DY HH24') slot,
       COUNT(*) amostras_ash
FROM   dba_hist_active_sess_history
WHERE  sample_time > SYSDATE - &&dias
GROUP  BY TO_CHAR(sample_time,'DY HH24')
ORDER  BY 1;

SELECT event, COUNT(*) amostras
FROM   dba_hist_active_sess_history
WHERE  sample_time > SYSDATE - &&dias
AND    session_type = 'FOREGROUND'
GROUP  BY event
ORDER  BY amostras DESC
FETCH FIRST 15 ROWS ONLY;

PROMPT ######################################################################
PROMPT # 2.8 SQL TUNING SET (evidencia reutilizavel nas Fases 1 e 2)
PROMPT # Guarda o workload num objeto consultavel depois (DBMS_SQLTUNE).
PROMPT # Criar/carregar um STS nao exige Tuning Pack; JA EXECUTAR o
PROMPT # SQL Tuning Advisor / SQL Access Advisor exige Tuning Pack licenciado.
PROMPT ######################################################################

BEGIN
  dbms_sqltune.create_sqlset(
    sqlset_name => 'FASE0_DW_STS',
    description => 'Fase 0 - workload DW - evidencia para modelagem de particionamento');
END;
/

DECLARE
  cur dbms_sqltune.sqlset_cursor;
BEGIN
  OPEN cur FOR
    SELECT VALUE(x)
    FROM   TABLE(dbms_sqltune.select_workload_repository(
             begin_snap     => (SELECT MAX(snap_id)-100 FROM dba_hist_snapshot),
             end_snap       => (SELECT MAX(snap_id)     FROM dba_hist_snapshot),
             basic_filter   => 'parsing_schema_name NOT IN (''SYS'',''SYSTEM'')',
             result_limit   => 1000,
             attribute_list => 'TYPICAL')) x;
  dbms_sqltune.load_sqlset(sqlset_name => 'FASE0_DW_STS', populate_cursor => cur);
  CLOSE cur;
END;
/

SELECT COUNT(*) stmts_no_sts,
       ROUND(SUM(elapsed_time)/1e6/60,1) minutos_totais
FROM   TABLE(dbms_sqltune.select_sqlset('FASE0_DW_STS'));

PROMPT ######################################################################
PROMPT # PLANO B - SE NAO HOUVER DIAGNOSTICS PACK LICENCIADO
PROMPT ######################################################################
PROMPT # 1) Nao execute as seccoes 2.3 a 2.8 (usam DBA_HIST_*).
PROMPT # 2) Capture snapshots proprios, repetindo a cada 6-24h durante N dias,
PROMPT #    em horario de ponta de carga E de consulta:

-- CAPTURA 1: cache SQL atual (instantaneo)
CREATE TABLE fase0_sql_snap AS
SELECT SYSDATE captured_at, sql_id, plan_hash_value, executions,
       elapsed_time, disk_reads, rows_processed,
       DBMS_LOB.SUBSTR(sql_text,4000) sql_text
FROM   v$sql
WHERE  parsing_schema_name NOT IN ('SYS','SYSTEM');

-- CAPTURA 2: para diff de crescimento, use as tabelas de baseline do
--    fase0_03_capacidade_crescimento.sql (seccao 3.5).

-- CAPTURA 3: planos do cache atual com predicados
CREATE TABLE fase0_plan_snap AS
SELECT SYSDATE captured_at, sql_id, plan_hash_value, id, parent_id,
       operation, options, object_owner, object_name, object_type,
       access_predicates, filter_predicates
FROM   v$sql_plan
WHERE  sql_id IN (SELECT sql_id FROM v$sql
                  WHERE parsing_schema_name NOT IN ('SYS','SYSTEM'));

-- Para analisar depois: diff entre capturas (execucoes/linhas por SQL) e
-- frequencia de colunas em filter/access_predicates (analise textual).

SPOOL OFF
PROMPT FIM DO PASSO 2. Guarde o log e o ficheiro .log do STS como evidencia.
