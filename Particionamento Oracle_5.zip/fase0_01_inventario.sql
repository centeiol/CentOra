REM ============================================================================
REM FASE 0 - PASSO 1: INVENTARIO GERAL DO AMBIENTE
REM Base de dados Oracle 19c (DW, ~60 TB) - Projeto de particionamento
REM ----------------------------------------------------------------------------
REM Objetivo: produzir EVIDENCIA documentada de:
REM   1.1 Identificacao do ambiente (versao, RAC, PDB, role)
REM   1.2 Opcoes instaladas e licenciamento relevante (Partitioning, packs)
REM   1.3 Tablespaces (tipo, espaco livre, autoextend)
REM   1.4 Top segmentos (tabelas, particoes, indices, LOBs)
REM   1.5 Particionamento ja existente (incl. skew de tamanho)
REM   1.6 Materialized views (refresh, compilacao, tamanho)
REM   1.7 Compressao ja em uso
REM   1.8 Tabelas IOT / cluster / paralelismo declarado
REM
REM Execucao: sqlplus como utilizador com privilegios de leitura do dicionario
REM           (DBA ou SELECT_CATALOG_ROLE). Executar na PDB onde esta a DW.
REM           Manter o SPOOL ativo: o ficheiro .log e a evidencia do dossie.
REM
REM NOTA: este script nao altera NADA na base de dados (so leitura, exceto
REM       nada). Pode correr em horario de pico, mas recomenda-se fora da
REM       janela de carga da DW.
REM ============================================================================

SET ECHO ON FEEDBACK ON LINESIZE 250 PAGESIZE 300 TRIMSPOOL ON SERVEROUTPUT ON SIZE UNLIMITED

ALTER SESSION SET NLS_DATE_FORMAT = 'YYYY-MM-DD HH24:MI:SS';
ALTER SESSION SET NLS_TIMESTAMP_FORMAT = 'YYYY-MM-DD HH24:MI:SS';

COLUMN captured_at NEW_VALUE v_data NOPRINT
SELECT TO_CHAR(SYSDATE,'YYYYMMDD_HH24MI') captured_at FROM dual;

SPOOL fase0_01_inventario_&&v_data..log

PROMPT ######################################################################
PROMPT # 1.1 IDENTIFICACAO DO AMBIENTE
PROMPT ######################################################################

SELECT SYSDATE momento_da_captura FROM dual;

SELECT name, db_unique_name, database_role, open_mode, platform_name, log_mode, created
FROM   v$database;

SELECT banner AS versao_completa FROM v$version;

SELECT instance_name, host_name, status, startup_time, edition
FROM   v$instance;

-- RAC?
SELECT inst_id, instance_name, host_name, status FROM gv$instance ORDER BY inst_id;

-- Multitenant? Em que container estamos?
SELECT con_id, name, open_mode FROM v$pdbs ORDER BY con_id;
SELECT sys_context('USERENV','CON_NAME') container_actual FROM dual;

-- Standby/Data Guard ativo? (impacta estrategia de conversao online)
SELECT dest_id, status, database_mode, recovery_mode FROM v$archive_dest_status WHERE status <> 'INACTIVE';

PROMPT ######################################################################
PROMPT # 1.2 OPCOES E LICENCIAMENTO
PROMPT ######################################################################

-- Opcoes instaladas no binario (TRUE = disponivel no software)
SELECT parameter, value
FROM   v$option
WHERE  UPPER(parameter) IN ('PARTITIONING','REAL APPLICATION CLUSTERS',
                            'ADVANCED COMPRESSION','OLAP','ADVANCED ANALYTICS',
                            'LABEL SECURITY','DATABASE VAULT','IN-MEMORY COLUMN STORE')
ORDER BY parameter;

-- Packs: o parametro revela se a funcionalidade esta ativa no servidor.
-- ATENCAO: valor ativo IMPLICA a necessidade de licenca Diagnostics/Tuning Pack
-- (ver oracle.com - Database Licensing Information User Manual, 19c).
SELECT name, value
FROM   v$parameter
WHERE  name IN ('control_management_pack_access','statistics_level');

-- Historico de uso detetado pelo proprio Oracle (auditoria interna)
SELECT name, version, detected_usages, total_samples, currently_used,
       first_usage_date, last_usage_date
FROM   dba_feature_usage_statistics
WHERE  LOWER(name) LIKE '%partition%'
   OR  LOWER(name) LIKE '%workload repository%'
   OR  LOWER(name) LIKE '%active session history%'
   OR  LOWER(name) LIKE '%sql monitoring%'
   OR  LOWER(name) LIKE '%sql tuning%'
   OR  LOWER(name) LIKE '%segment advisor%'
   OR  LOWER(name) LIKE '%compression%'
   OR  LOWER(name) LIKE '%data guard%'
ORDER BY name;

PROMPT ######################################################################
PROMPT # 1.3 TABLESPACES
PROMPT ######################################################################

WITH f AS (
  SELECT tablespace_name, SUM(bytes) free_bytes
  FROM   dba_free_space
  GROUP  BY tablespace_name)
SELECT df.tablespace_name,
       t.bigfile, t.extent_management, t.segment_space_management, t.status,
       ROUND(SUM(df.bytes)/POWER(1024,3),1)        alloc_gb,
       ROUND(NVL(f.free_bytes,0)/POWER(1024,3),1)  free_gb,
       ROUND((SUM(df.bytes)-NVL(f.free_bytes,0))/POWER(1024,3),1) used_gb,
       ROUND(SUM(CASE WHEN df.autoextensible='YES' THEN df.maxbytes ELSE df.bytes END)/POWER(1024,3),1) max_autoextend_gb
FROM   dba_data_files df
JOIN   dba_tablespaces t ON t.tablespace_name = df.tablespace_name
LEFT JOIN f ON f.tablespace_name = df.tablespace_name
GROUP  BY df.tablespace_name, t.bigfile, t.extent_management,
          t.segment_space_management, t.status, f.free_bytes
ORDER  BY alloc_gb DESC;

-- Temporarios
SELECT tablespace_name, ROUND(SUM(bytes)/POWER(1024,3),1) alloc_gb
FROM   dba_temp_files GROUP BY tablespace_name ORDER BY alloc_gb DESC;

-- Se a base nao estiver em ASM, o erro ORA-00942 abaixo e esperado: ignore.
SELECT name, state, type,
       ROUND(total_mb/1024,1) total_gb,
       ROUND(free_mb/1024,1)  free_gb,
       ROUND((total_mb-free_mb)/total_mb*100,1) pct_usado
FROM   v$asm_diskgroup ORDER BY total_gb DESC;

PROMPT ######################################################################
PROMPT # 1.4 TOP 60 SEGMENTOS (tabelas, particoes, indices, LOBs)
PROMPT ######################################################################

SELECT owner, segment_name, NVL(partition_name,'-') partition_name,
       segment_type, ROUND(bytes/POWER(1024,3),2) gb, tablespace_name
FROM   dba_segments
WHERE  owner NOT IN ('SYS','SYSTEM','SYSAUX','OUTLN','AUDSYS','DBSNMP','XDB',
                     'WMSYS','MDSYS','ORDDATA','ORDSYS','CTXSYS','EXFSYS',
                     'OLAPSYS','LBACSYS','DVSYS','OJVMSYS','GSMADMIN_INTERNAL')
AND    owner NOT LIKE 'APEX%'
ORDER  BY bytes DESC
FETCH FIRST 60 ROWS ONLY;

PROMPT ######################################################################
PROMPT # 1.4b TOP 50 TABELAS (tamanho fisico vs estimativa de linhas)
PROMPT ATENCAo: num_rows vem das ultimas estatisticas - ver last_analyzed.
PROMPT ######################################################################

SELECT t.owner, t.table_name, t.num_rows,
       TO_CHAR(t.last_analyzed,'YYYY-MM-DD HH24:MI') last_analyzed,
       ROUND(SUM(s.bytes)/POWER(1024,3),2) gb
FROM   dba_tables t
JOIN   dba_segments s ON s.owner = t.owner AND s.segment_name = t.table_name
       AND s.segment_type = 'TABLE'
WHERE  t.owner NOT IN ('SYS','SYSTEM','SYSAUX','OUTLN','AUDSYS','DBSNMP','XDB',
                       'WMSYS','MDSYS','ORDDATA','ORDSYS','CTXSYS','EXFSYS',
                       'OLAPSYS','LBACSYS','DVSYS','OJVMSYS','GSMADMIN_INTERNAL')
AND    t.owner NOT LIKE 'APEX%'
GROUP  BY t.owner, t.table_name, t.num_rows, t.last_analyzed
ORDER  BY gb DESC
FETCH FIRST 50 ROWS ONLY;

PROMPT ######################################################################
PROMPT # 1.4c TOP 50 INDICES (inclui particoes de indice)
PROMPT ######################################################################

SELECT owner, segment_name, NVL(partition_name,'-') partition_name,
       segment_type, ROUND(SUM(bytes)/POWER(1024,3),2) gb, tablespace_name
FROM   dba_segments
WHERE  segment_type IN ('INDEX','INDEX PARTITION','INDEX SUBPARTITION','IOT INDEX','LOBINDEX')
AND    owner NOT IN ('SYS','SYSTEM','SYSAUX','OUTLN','AUDSYS','DBSNMP','XDB',
                     'WMSYS','MDSYS','ORDDATA','ORDSYS','CTXSYS','EXFSYS',
                     'OLAPSYS','LBACSYS','DVSYS','OJVMSYS','GSMADMIN_INTERNAL')
AND    owner NOT LIKE 'APEX%'
GROUP  BY owner, segment_name, partition_name, segment_type, tablespace_name
ORDER  BY gb DESC
FETCH FIRST 50 ROWS ONLY;

PROMPT ######################################################################
PROMPT # 1.5 PARTICIONAMENTO JA EXISTENTE
PROMPT ######################################################################

SELECT p.owner, p.table_name, p.partitioning_type, p.subpartitioning_type,
       p.partition_count, p.def_tablespace_name,
       t.num_rows, TO_CHAR(t.last_analyzed,'YYYY-MM-DD') last_analyzed
FROM   dba_part_tables p
JOIN   dba_tables t ON t.owner = p.owner AND t.table_name = p.table_name
WHERE  p.owner NOT IN ('SYS','SYSTEM','SYSAUX','OUTLN','AUDSYS','DBSNMP','XDB',
                       'WMSYS','MDSYS','ORDDATA','ORDSYS','CTXSYS','EXFSYS',
                       'OLAPSYS','LBACSYS','DVSYS','OJVMSYS','GSMADMIN_INTERNAL')
ORDER  BY p.partition_count DESC
FETCH FIRST 60 ROWS ONLY;

-- Skew das 20 maiores tabelas particionadas: tamanho por particao.
-- Particoes com tamanho muito discrepante das restantes sao ALERTA de chave
-- de particionamento mal escolhida ou carga desequilibrada.
SELECT s.table_owner, s.table_name, s.partition_name, s.segment_type,
       ROUND(SUM(s.bytes)/POWER(1024,3),2) gb
FROM   dba_segments s
WHERE  s.segment_type IN ('TABLE PARTITION','TABLE SUBPARTITION')
AND    (s.table_owner, s.table_name) IN (
         SELECT owner, segment_name
         FROM   dba_segments
         WHERE  segment_type = 'TABLE PARTITION'
         GROUP  BY owner, segment_name
         ORDER  BY SUM(bytes) DESC
         FETCH FIRST 20 ROWS ONLY)
GROUP  BY s.table_owner, s.table_name, s.partition_name, s.segment_type
ORDER  BY s.table_owner, s.table_name, gb DESC
FETCH FIRST 300 ROWS ONLY;

PROMPT ######################################################################
PROMPT # 1.6 MATERIALIZED VIEWS (tipicas de DW: refresh, estado, tamanho)
PROMPT ######################################################################

SELECT m.owner, m.mview_name, m.refresh_method, m.refresh_mode, m.refresh_on,
       m.last_refresh_date, m.compile_state,
       ROUND(SUM(s.bytes)/POWER(1024,3),2) gb
FROM   dba_mviews m
JOIN   dba_segments s ON s.owner = m.owner AND s.segment_name = m.mview_name
GROUP  BY m.owner, m.mview_name, m.refresh_method, m.refresh_mode, m.refresh_on,
          m.last_refresh_date, m.compile_state
ORDER  BY gb DESC
FETCH FIRST 40 ROWS ONLY;

PROMPT ######################################################################
PROMPT # 1.7 COMPRESSAO JA EM USO
PROMPT ######################################################################

SELECT owner, segment_type, compression, compress_for,
       COUNT(*) segmentos, ROUND(SUM(bytes)/POWER(1024,3),1) gb
FROM   dba_segments
WHERE  compression <> 'DISABLED'
AND    owner NOT IN ('SYS','SYSTEM','SYSAUX','OUTLN','AUDSYS','DBSNMP','XDB',
                     'WMSYS','MDSYS','ORDDATA','ORDSYS','CTXSYS','EXFSYS',
                     'OLAPSYS','LBACSYS','DVSYS','OJVMSYS','GSMADMIN_INTERNAL')
GROUP  BY owner, segment_type, compression, compress_for
ORDER  BY gb DESC;

PROMPT ######################################################################
PROMPT # 1.8 TABELAS IOT / CLUSTER / GRAU DE PARALELISMO DECLARADO
PROMPT (restricoes a MODIFY PARTITION BY ONLINE e custo de conversao)
PROMPT ######################################################################

SELECT owner, table_name, degree, instances, iot_type, cluster_name,
       partitioned, compression, compress_for
FROM   dba_tables
WHERE  owner NOT IN ('SYS','SYSTEM','SYSAUX','OUTLN','AUDSYS','DBSNMP','XDB',
                     'WMSYS','MDSYS','ORDDATA','ORDSYS','CTXSYS','EXFSYS',
                     'OLAPSYS','LBACSYS','DVSYS','OJVMSYS','GSMADMIN_INTERNAL')
AND    owner NOT LIKE 'APEX%'
AND   (degree NOT IN ('1','0') OR instances NOT IN ('1','0')
       OR iot_type IS NOT NULL OR cluster_name IS NOT NULL)
ORDER  BY owner, table_name;

PROMPT ######################################################################
PROMPT # 1.9 LOBS GRANDES (fora das tabelas "normais")
PROMPT ######################################################################

SELECT owner, segment_name tabela, partition_name, segment_type,
       ROUND(bytes/POWER(1024,3),2) gb
FROM   dba_segments
WHERE  segment_type IN ('LOBSEGMENT','LOB PARTITION')
AND    owner NOT IN ('SYS','SYSTEM','SYSAUX','OUTLN','AUDSYS','DBSNMP','XDB',
                     'WMSYS','MDSYS','ORDDATA','ORDSYS','CTXSYS','EXFSYS',
                     'OLAPSYS','LBACSYS','DVSYS','OJVMSYS','GSMADMIN_INTERNAL')
ORDER  BY bytes DESC
FETCH FIRST 30 ROWS ONLY;

SPOOL OFF
PROMPT FIM DO PASSO 1. Guarde o ficheiro de log como evidencia do dossie.
