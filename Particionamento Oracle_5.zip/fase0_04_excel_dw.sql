REM ============================================================================
REM FASE 0 - PASSO 4: CONSOLIDACAO DA EVIDENCIA EM TABELAS-MASTRO + CSV (EXCEL)
REM Base de dados Oracle 19c (DW) - Projeto de particionamento
REM ----------------------------------------------------------------------------
REM Objetivo: conjugar toda a informacao dispersa dos Passos 1, 2 e 2b em
REM TABELAS (dossie_fase0.*), e exportar 3 CSV prontos a abrir no Excel
REM (delimitador ';' - Excel PT). Cada CSV = uma TAB da folha.
REM
REM   TAB1 tab1_candidatas.csv  <- master_candidatas (1 linha por tabela)
REM   TAB2 tab2_colunas.csv     <- master_colunas + perfil temporal + top1
REM                                valor (1 linha por coluna - o maximo de
REM                                informacao conjugada por coluna)
REM   TAB3 tab3_top_valores.csv <- prof_top_valores (top 5 por coluna discreta)
REM
REM Alternativa sem CSV: com as tabelas-mastro criadas, no SQL Developer basta
REM SELECT * FROM dossie_fase0.master_candidatas -> botao direito -> Export ->
REM xlsx. O CSV e o caminho "puro sqlplus".
REM
REM ESTRUTURA CRIADA (todas em dossie_fase0):
REM   master_candidatas : identificacao, tamanho, stats, imutabilidade (proxy),
REM                       particionamento existente, bitmaps, MVs, workload AWR
REM   pred_cols         : colunas extraidas dos predicados AWR (heuristica)
REM   master_colunas    : catalogo de colunas + flags (temporal? em predicados?)
REM   prof_temporal     : min/max/amplitude/nulos/skew mensal por coluna DATE
REM   prof_top_valores  : top 5 valores por coluna de igualdade
REM
REM GATE DE LICENCIAMENTO: colunas AWR so sao preenchidas se
REM control_management_pack_access contiver DIAGNOSTIC. Sem pack, o script
REM corre na mesma e essas colunas ficam a NULL/'NAO' (nunca falha).
REM
REM CUSTO: a construcao de prof_temporal le cada tabela candidata 2x por
REM coluna temporal; prof_top_valores 1x por coluna discreta. Fora do pico.
REM
REM Execucao: sqlplus como DBA (ou owner do schema dossie_fase0).
REM Pre-requisito (uma vez): criar o schema de documentacao:
REM   CREATE USER dossie_fase0 IDENTIFIED BY <senha>
REM     DEFAULT TABLESPACE <ts> QUOTA UNLIMITED ON <ts>;
REM   GRANT CREATE SESSION, CREATE TABLE TO dossie_fase0;
REM ============================================================================

SET ECHO ON FEEDBACK ON LINESIZE 400 PAGESIZE 500 TRIMSPOOL ON SERVEROUTPUT ON SIZE UNLIMITED

DEFINE num_tabelas = 15
DEFINE medir_buckets = 1
DEFINE medir_top_valores = 1

ALTER SESSION SET NLS_DATE_FORMAT = 'YYYY-MM-DD HH24:MI:SS';
ALTER SESSION SET NLS_NUMERIC_CHARACTERS = '.,';

COLUMN captured_at NEW_VALUE v_data NOPRINT
SELECT TO_CHAR(SYSDATE,'YYYYMMDD_HH24MI') captured_at FROM dual;

SPOOL fase0_04_excel_&&v_data..log

PROMPT ######################################################################
PROMPT # 1. TABELA-MASTRO DAS CANDIDATAS (uma linha por tabela)
PROMPT ######################################################################

DROP TABLE dossie_fase0.master_candidatas PURGE;
CREATE TABLE dossie_fase0.master_candidatas AS
WITH top_tab AS (
  SELECT s.owner, s.segment_name table_name, ROUND(s.bytes/POWER(1024,3),2) gb
  FROM   dba_segments s
  WHERE  s.segment_type = 'TABLE'
  AND    s.owner NOT IN ('SYS','SYSTEM','SYSAUX','OUTLN','AUDSYS','DBSNMP','XDB',
                         'WMSYS','MDSYS','ORDDATA','ORDSYS','CTXSYS','EXFSYS',
                         'OLAPSYS','LBACSYS','DVSYS','OJVMSYS','GSMADMIN_INTERNAL')
  AND    s.owner NOT LIKE 'APEX%'
  ORDER  BY s.bytes DESC
  FETCH FIRST &&num_tabelas ROWS ONLY)
SELECT tt.owner,
       tt.table_name tabela,
       tt.gb,
       t.num_rows,
       TO_CHAR(t.last_analyzed,'YYYY-MM-DD HH24:MI') stats_em,
       t.degree      grau_paralelo,
       t.iot_type    iot,
       t.cluster_name em_cluster,
       t.compression,
       t.compress_for,
       t.tablespace_name tablespace,
       m.inserts inserts_desde_stats,
       m.updates updates_desde_stats,
       m.deletes deletes_desde_stats,
       m.timestamp mods_medidos_em,
       pt.partitioning_type   particao_tipo,
       pt.subpartitioning_type subparticao_tipo,
       pt.partition_count     n_particoes,
       (SELECT ROUND(MAX(s2.bytes)/POWER(1024,3),2)
          FROM dba_segments s2
         WHERE s2.owner = tt.owner AND s2.segment_name = tt.table_name
           AND s2.segment_type IN ('TABLE PARTITION','TABLE SUBPARTITION')) maior_particao_gb,
       (SELECT COUNT(*) FROM dba_indexes i
         WHERE i.owner = tt.owner AND i.table_name = tt.table_name
           AND i.index_type = 'BITMAP') bitmap_indexes,
       (SELECT COUNT(*) FROM dba_mviews mv
         WHERE mv.owner = tt.owner AND mv.mview_name = tt.table_name) e_mview,
       (SELECT COUNT(*) FROM dba_mview_detail_relations d
         WHERE d.detailobj_owner = tt.owner
           AND d.detailobj_name  = tt.table_name) mviews_dependem,
       CAST(NULL AS NUMBER)        sqls_distintos_awr,
       CAST(NULL AS VARCHAR2(4000)) colunas_em_predicados,
       CAST(NULL AS VARCHAR2(4000)) acessos_awr
FROM   top_tab tt
JOIN   dba_tables t ON t.owner = tt.owner AND t.table_name = tt.table_name
LEFT JOIN dba_tab_modifications m
       ON m.table_owner = tt.owner AND m.table_name = tt.table_name
      AND m.partition_name IS NULL
LEFT JOIN dba_part_tables pt
       ON pt.owner = tt.owner AND pt.table_name = tt.table_name;

-- Nota: se ORA-00904 em dba_mview_detail_relations, remover so esse subselect
-- (a vista existe na 19c; e o detalhe PCT sera avaliado na Fase 1 com
-- DBMS_MVIEW.EXPLAIN_MVIEW).

PROMPT ######################################################################
PROMPT # 2. PREDICADOS AWR -> COLUNAS (heuristica: pega identificadores
PROMPT #    qualificados "ALIAS"."COLUNA" nos access/filter predicates)
PROMPT ######################################################################

DROP TABLE dossie_fase0.pred_cols PURGE;
CREATE TABLE dossie_fase0.pred_cols (
  object_owner     VARCHAR2(128),
  object_name      VARCHAR2(128),
  coluna_predicado VARCHAR2(128));

DECLARE
  v_pack VARCHAR2(30);
BEGIN
  SELECT value INTO v_pack FROM v$parameter WHERE name='control_management_pack_access';
  IF UPPER(v_pack) LIKE 'DIAGNOSTIC%' THEN
    EXECUTE IMMEDIATE q'{
      INSERT INTO dossie_fase0.pred_cols
      SELECT DISTINCT p.object_owner, p.object_name,
             REGEXP_SUBSTR(p.pred, '"[^"]+"\."([^"]+)"', 1, l.lvl, NULL, 1)
      FROM (
        SELECT object_owner, object_name,
               NVL(filter_predicates,' ')||' '||NVL(access_predicates,' ') pred
        FROM   dba_hist_sql_plan
        WHERE  filter_predicates IS NOT NULL
           OR  access_predicates IS NOT NULL
      ) p,
      LATERAL (SELECT LEVEL lvl FROM dual
               CONNECT BY LEVEL <= REGEXP_COUNT(p.pred,'"[^"]+"\."[^"]+"')) l
      WHERE REGEXP_SUBSTR(p.pred,'"[^"]+"\."([^"]+)"',1,l.lvl,NULL,1) IS NOT NULL
    }';
    COMMIT;
  ELSE
    DBMS_OUTPUT.PUT_LINE('> Diagnostics Pack indisponivel: pred_cols fica vazia;');
    DBMS_OUTPUT.PUT_LINE('> colunas_em_predicados / em_predicados ficam a NAO.');
  END IF;
END;
/

-- Preencher as colunas AWR da master (so com pack licenciado)
DECLARE
  v_pack VARCHAR2(30);
BEGIN
  SELECT value INTO v_pack FROM v$parameter WHERE name='control_management_pack_access';
  IF UPPER(v_pack) LIKE 'DIAGNOSTIC%' THEN
    EXECUTE IMMEDIATE q'{
      UPDATE dossie_fase0.master_candidatas mc
      SET (sqls_distintos_awr, colunas_em_predicados) = (
        SELECT (SELECT COUNT(DISTINCT p.sql_id)
                  FROM dba_hist_sql_plan p
                 WHERE p.object_owner = mc.owner AND p.object_name = mc.tabela),
               (SELECT LISTAGG(pc.coluna_predicado,', ') WITHIN GROUP (ORDER BY pc.coluna_predicado)
                  FROM dossie_fase0.pred_cols pc
                 WHERE pc.object_owner = mc.owner AND pc.object_name = mc.tabela)
        FROM dual)
    }';
    EXECUTE IMMEDIATE q'{
      UPDATE dossie_fase0.master_candidatas mc
      SET acessos_awr = (
        SELECT LISTAGG(op,', ') WITHIN GROUP (ORDER BY op)
          FROM (SELECT DISTINCT p.operation||' '||p.options op
                  FROM dba_hist_sql_plan p
                 WHERE p.object_owner = mc.owner AND p.object_name = mc.tabela
                   AND p.operation LIKE 'TABLE ACCESS%'))
    }';
    COMMIT;
  END IF;
END;
/

PROMPT ######################################################################
PROMPT # 3. TABELA-MASTRO DE COLUNAS (uma linha por coluna das candidatas)
PROMPT ######################################################################

DROP TABLE dossie_fase0.master_colunas PURGE;
CREATE TABLE dossie_fase0.master_colunas AS
WITH top_tab AS (
  SELECT s.owner, s.segment_name table_name
  FROM   dba_segments s
  WHERE  s.segment_type = 'TABLE'
  AND    s.owner NOT IN ('SYS','SYSTEM','SYSAUX','OUTLN','AUDSYS','DBSNMP','XDB',
                         'WMSYS','MDSYS','ORDDATA','ORDSYS','CTXSYS','EXFSYS',
                         'OLAPSYS','LBACSYS','DVSYS','OJVMSYS','GSMADMIN_INTERNAL')
  AND    s.owner NOT LIKE 'APEX%'
  ORDER  BY s.bytes DESC
  FETCH FIRST &&num_tabelas ROWS ONLY)
SELECT c.owner,
       c.table_name tabela,
       c.column_id  posicao,
       c.column_name coluna,
       c.data_type  tipo,
       c.nullable   nulo,
       c.num_distinct,
       c.num_nulls,
       c.histogram,
       TO_CHAR(c.last_analyzed,'YYYY-MM-DD') stats_em,
       CASE WHEN c.data_type IN ('DATE','TIMESTAMP','TIMESTAMP WITH TIME ZONE',
                                 'TIMESTAMP WITH LOCAL TIME ZONE')
            THEN 'SIM' ELSE 'NAO' END e_temporal,
       CASE WHEN pc.coluna_predicado IS NOT NULL THEN 'SIM' ELSE 'NAO' END em_predicados
FROM   dba_tab_columns c
JOIN   top_tab ON top_tab.owner = c.owner AND top_tab.table_name = c.table_name
LEFT JOIN dossie_fase0.pred_cols pc
       ON pc.object_owner = c.owner
      AND pc.object_name  = c.table_name
      AND UPPER(pc.coluna_predicado) = c.column_name;

PROMPT ######################################################################
PROMPT # 4. PERFIL TEMPORAL (leituras completas - custo!)
PROMPT # min/max/amplitude/nulos/skew mensal por coluna DATE/TIMESTAMP
PROMPT ######################################################################

DROP TABLE dossie_fase0.prof_temporal PURGE;
CREATE TABLE dossie_fase0.prof_temporal (
  owner          VARCHAR2(128),
  tabela         VARCHAR2(128),
  coluna         VARCHAR2(128),
  tipo           VARCHAR2(44),
  min_val        VARCHAR2(20),
  max_val        VARCHAR2(20),
  meses          NUMBER,
  linhas         NUMBER,
  pct_nulo       NUMBER(6,2),
  maior_mes      VARCHAR2(7),
  pct_maior_mes  NUMBER(6,2),
  medido_em      DATE DEFAULT SYSDATE);

DECLARE
  CURSOR c_cols IS
    SELECT c.owner, c.table_name, c.column_name, c.data_type
    FROM   dba_tab_columns c
    JOIN   dossie_fase0.master_candidatas mc
           ON mc.owner = c.owner AND mc.tabela = c.table_name
    WHERE  c.data_type IN ('DATE','TIMESTAMP','TIMESTAMP WITH TIME ZONE',
                           'TIMESTAMP WITH LOCAL TIME ZONE')
    ORDER  BY c.owner, c.table_name, c.column_id;
  v_min        TIMESTAMP;
  v_max        TIMESTAMP;
  v_rows       NUMBER;
  v_not_null   NUMBER;
  v_top_bucket VARCHAR2(7);
  v_top_rows   NUMBER;
  v_span       NUMBER;
  v_stmt       VARCHAR2(4000);
  FUNCTION q(p_name VARCHAR2) RETURN VARCHAR2 IS
  BEGIN RETURN DBMS_ASSERT.SIMPLE_SQL_NAME(p_name); END;
  FUNCTION qsch(p_name VARCHAR2) RETURN VARCHAR2 IS
  BEGIN RETURN DBMS_ASSERT.SCHEMA_NAME(p_name); END;
BEGIN
  FOR r IN c_cols LOOP
    v_stmt := 'SELECT MIN('||q(r.column_name)||'), MAX('||q(r.column_name)||'), COUNT(*), COUNT('||q(r.column_name)||')'
           || ' FROM '||qsch(r.owner)||'.'||q(r.table_name);
    EXECUTE IMMEDIATE v_stmt INTO v_min, v_max, v_rows, v_not_null;

    IF &&medir_buckets = 1 AND v_not_null > 0 THEN
      v_stmt := 'SELECT TO_CHAR('||q(r.column_name)||',''YYYY-MM''), COUNT(*)'
             || ' FROM '||qsch(r.owner)||'.'||q(r.table_name)
             || ' WHERE '||q(r.column_name)||' IS NOT NULL'
             || ' GROUP BY TO_CHAR('||q(r.column_name)||',''YYYY-MM'')'
             || ' ORDER BY COUNT(*) DESC FETCH FIRST 1 ROWS ONLY';
      BEGIN
        EXECUTE IMMEDIATE v_stmt INTO v_top_bucket, v_top_rows;
      EXCEPTION WHEN NO_DATA_FOUND THEN
        v_top_bucket := '-'; v_top_rows := 0;
      END;
    ELSE
      v_top_bucket := '-'; v_top_rows := 0;
    END IF;

    v_span := ROUND(MONTHS_BETWEEN(TRUNC(CAST(v_max AS DATE),'MM'),
                                   TRUNC(CAST(v_min AS DATE),'MM')));
    INSERT INTO dossie_fase0.prof_temporal
      (owner, tabela, coluna, tipo, min_val, max_val, meses, linhas,
       pct_nulo, maior_mes, pct_maior_mes, medido_em)
    VALUES
      (r.owner, r.table_name, r.column_name, r.data_type,
       TO_CHAR(v_min,'YYYY-MM-DD HH24:MI:SS'),
       TO_CHAR(v_max,'YYYY-MM-DD HH24:MI:SS'),
       v_span, v_rows,
       ROUND((v_rows - v_not_null)/NULLIF(v_rows,0)*100,2),
       v_top_bucket,
       ROUND(v_top_rows/NULLIF(v_not_null,0)*100,2),
       SYSDATE);
  END LOOP;
  COMMIT;
END;
/

PROMPT ######################################################################
PROMPT # 5. TOP 5 VALORES POR COLUNA DE IGUALDADE (leituras completas)
PROMPT ######################################################################

DROP TABLE dossie_fase0.prof_top_valores PURGE;
CREATE TABLE dossie_fase0.prof_top_valores (
  owner        VARCHAR2(128),
  tabela       VARCHAR2(128),
  coluna       VARCHAR2(128),
  posicao      NUMBER,
  valor        VARCHAR2(4000),
  contagem     NUMBER,
  pct_do_total NUMBER(6,2),
  medido_em    DATE DEFAULT SYSDATE);

DECLARE
  CURSOR c_cols IS
    SELECT c.owner, c.table_name, c.column_name, c.num_distinct
    FROM   dba_tab_columns c
    JOIN   dossie_fase0.master_candidatas mc
           ON mc.owner = c.owner AND mc.tabela = c.table_name
    WHERE  c.data_type IN ('VARCHAR2','NVARCHAR2','CHAR','NCHAR','NUMBER')
    AND    c.num_distinct BETWEEN 2 AND 2000
    ORDER  BY c.owner, c.table_name, c.column_id;
  v_val   VARCHAR2(4000);
  v_cnt   NUMBER;
  v_tot   NUMBER;
  v_rank  NUMBER;
  v_stmt  VARCHAR2(4000);
  FUNCTION q(p_name VARCHAR2) RETURN VARCHAR2 IS
  BEGIN RETURN DBMS_ASSERT.SIMPLE_SQL_NAME(p_name); END;
  FUNCTION qsch(p_name VARCHAR2) RETURN VARCHAR2 IS
  BEGIN RETURN DBMS_ASSERT.SCHEMA_NAME(p_name); END;
BEGIN
  IF &&medir_top_valores = 1 THEN
    FOR r IN c_cols LOOP
      v_stmt := 'SELECT COUNT(*) FROM '||qsch(r.owner)||'.'||q(r.table_name);
      EXECUTE IMMEDIATE v_stmt INTO v_tot;

      v_stmt := 'SELECT RTRIM(TO_CHAR('||q(r.column_name)||')), COUNT(*)'
             || ' FROM '||qsch(r.owner)||'.'||q(r.table_name)
             || ' GROUP BY '||q(r.column_name)
             || ' ORDER BY COUNT(*) DESC FETCH FIRST 5 ROWS ONLY';
      v_rank := 0;
      DECLARE
        TYPE t_cur IS REF CURSOR;
        c t_cur;
      BEGIN
        OPEN c FOR v_stmt;
        LOOP
          FETCH c INTO v_val, v_cnt;
          EXIT WHEN c%NOTFOUND;
          v_rank := v_rank + 1;
          INSERT INTO dossie_fase0.prof_top_valores
            (owner, tabela, coluna, posicao, valor, contagem, pct_do_total, medido_em)
          VALUES
            (r.owner, r.table_name, r.column_name, v_rank, v_val, v_cnt,
             ROUND(v_cnt/NULLIF(v_tot,0)*100,2), SYSDATE);
        END LOOP;
        CLOSE c;
      END;
    END LOOP;
    COMMIT;
  ELSE
    DBMS_OUTPUT.PUT_LINE('> medir_top_valores=0: prof_top_valores ficou vazia.');
  END IF;
END;
/

PROMPT ######################################################################
PROMPT # 6. EXPORTACAO CSV (3 ficheiros = 3 tabs do Excel)
PROMPT # Delimitador ';' para abrir direto no Excel PT.
PROMPT # Cada bloco: liga CSV -> SPOOL -> SELECT -> SPOOL OFF -> desliga.
PROMPT ######################################################################

SET FEEDBACK OFF

SET MARKUP CSV ON DELIMITER ';' QUOTE ON
SPOOL tab1_candidatas_&&v_data..csv
SELECT * FROM dossie_fase0.master_candidatas ORDER BY gb DESC;
SPOOL OFF
SET MARKUP CSV OFF

SET MARKUP CSV ON DELIMITER ';' QUOTE ON
SPOOL tab2_colunas_&&v_data..csv
SELECT mc.owner, mc.tabela, mc.coluna, mc.posicao, mc.tipo, mc.nulo,
       mc.num_distinct, mc.num_nulls, mc.histogram, mc.stats_em,
       mc.e_temporal, mc.em_predicados,
       pt.min_val, pt.max_val, pt.meses, pt.linhas, pt.pct_nulo,
       pt.maior_mes, pt.pct_maior_mes,
       tv.valor top1_valor, tv.pct_do_total top1_pct
FROM   dossie_fase0.master_colunas mc
LEFT JOIN dossie_fase0.prof_temporal pt
       ON pt.owner = mc.owner AND pt.tabela = mc.tabela AND pt.coluna = mc.coluna
LEFT JOIN dossie_fase0.prof_top_valores tv
       ON tv.owner = mc.owner AND tv.tabela = mc.tabela AND tv.coluna = mc.coluna
      AND tv.posicao = 1
ORDER  BY mc.owner, mc.tabela, mc.posicao;
SPOOL OFF
SET MARKUP CSV OFF

SET MARKUP CSV ON DELIMITER ';' QUOTE ON
SPOOL tab3_top_valores_&&v_data..csv
SELECT * FROM dossie_fase0.prof_top_valores
ORDER  BY owner, tabela, coluna, posicao;
SPOOL OFF
SET MARKUP CSV OFF

SET FEEDBACK ON
SET MARKUP CSV OFF

PROMPT ######################################################################
PROMPT # FIM. Ficheiros produzidos:
PROMPT #   tab1_candidatas_&&v_data..csv   (1 linha por tabela candidata)
PROMPT #   tab2_colunas_&&v_data..csv     (1 linha por coluna - TAB conjugada)
PROMPT #   tab3_top_valores_&&v_data..csv (top 5 valores - detalhe)
PROMPT #
PROMPT # Como usar no Excel:
PROMPT #   1. Abrir cada CSV no Excel (dados ja caem em colunas, ';' PT).
PROMPT #   2. Ou: copiar cada CSV para uma TAB da folha-mestra
PROMPT #      (Fase0_Template.xlsx tem as tabs e cabecalhos ja alinhados).
PROMPT #   3. Formato alternativo: SQL Developer -> SELECT nas tabelas
PROMPT #      dossie_fase0.* -> Export -> xlsx (fica com formatos).
PROMPT #
PROMPT # Tabelas persistentes (reutilizaveis na Fase 1/2):
PROMPT #   dossie_fase0.master_candidatas / master_colunas /
PROMPT #   prof_temporal / prof_top_valores / pred_cols
PROMPT ######################################################################

SPOOL OFF
