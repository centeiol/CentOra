REM ============================================================================
REM PHASE 0 - STEP 3: CAPACITY, GROWTH AND OPERATIONAL WINDOWS
REM Oracle 19c DW (~60 TB) - Partitioning project
REM ----------------------------------------------------------------------------
REM Purpose: document with evidence:
REM   3.1 Space per tablespace (including autoextend and ASM)
REM   3.2 UNDO: recent peak (online conversion generates heavy UNDO)
REM   3.3 REDO/archiving: daily volume (affects window and FRA space)
REM   3.4 FRA (fast recovery area) - pressure during conversion
REM   3.5 Growth baseline (snapshot table + diff query)
REM   3.6 TEMP (DW sort/hash joins)
REM   3.7 Recent backup (RMAN duration/window)
REM
REM Run: sqlplus DBA. Section 3.5 creates TABLES - run only with
REM      authorization and in a dedicated documentation schema (suggestion:
REM      create the user FASE0_EVIDENCE). Never touches business data.
REM ============================================================================

SET ECHO ON FEEDBACK ON LINESIZE 250 PAGESIZE 300 TRIMSPOOL ON SERVEROUTPUT ON SIZE UNLIMITED

ALTER SESSION SET NLS_DATE_FORMAT = 'YYYY-MM-DD HH24:MI:SS';

COLUMN captured_at NEW_VALUE v_dt NOPRINT
SELECT TO_CHAR(SYSDATE,'YYYYMMDD_HH24MI') captured_at FROM dual;

SPOOL phase0_03_capacity_&&v_dt..log

PROMPT ######################################################################
PROMPT # 3.1 SPACE PER TABLESPACE (with autoextend ceiling)
PROMPT # >>> Evidence for: "will the new conversion segments fit?" <<<
PROMPT # Rule of thumb for Phase 1: usable free space >= 1x the largest
PROMPT # candidate table (the conversion creates NEW segments; the old ones
PROMPT # are only released at the end, if not reusing the same tablespaces).
PROMPT ######################################################################

WITH f AS (
  SELECT tablespace_name, SUM(bytes) free_bytes
  FROM   dba_free_space GROUP BY tablespace_name)
SELECT df.tablespace_name,
       ROUND(SUM(df.bytes)/POWER(1024,3),1) alloc_gb,
       ROUND(NVL(f.free_bytes,0)/POWER(1024,3),1) free_gb,
       ROUND((SUM(df.bytes)-NVL(f.free_bytes,0))/POWER(1024,3),1) used_gb,
       ROUND(SUM(CASE WHEN df.autoextensible='YES' THEN df.maxbytes
                      ELSE df.bytes END)/POWER(1024,3),1) autoextend_ceiling_gb,
       ROUND(NVL(f.free_bytes,0)/SUM(df.bytes)*100,1) pct_free
FROM   dba_data_files df
LEFT JOIN f ON f.tablespace_name = df.tablespace_name
GROUP  BY df.tablespace_name, f.free_bytes
ORDER  BY used_gb DESC;

SELECT tablespace_name,
       ROUND(SUM(bytes)/POWER(1024,3),1) alloc_gb
FROM   dba_temp_files GROUP BY tablespace_name ORDER BY alloc_gb DESC;

-- If not ASM / no access: ignore ORA-00942 or privilege error.
SELECT name, state, type,
       ROUND(total_mb/1024,1) total_gb, ROUND(free_mb/1024,1) free_gb,
       ROUND((total_mb-free_mb)/total_mb*100,1) pct_used
FROM   v$asm_diskgroup ORDER BY total_gb DESC;

PROMPT ######################################################################
PROMPT # 3.2 UNDO - peak of the last 24h (v$undostat, ~7 day window)
PROMPT # Online conversion (MODIFY PARTITION BY ONLINE) and DW loads compete
PROMPT # for UNDO: record the peak as the reference ceiling.
PROMPT ######################################################################

SELECT ROUND(MAX(u.undoblks) * t.block_size / POWER(1024,3), 2) peak_undo_gb_24h,
       ROUND(MAX(u.maxquerylen)/60,1) longest_query_min,
       MAX(u.tuned_undoretention) tuned_retention_s
FROM   v$undostat u
CROSS JOIN (SELECT block_size FROM dba_tablespaces
            WHERE tablespace_name =
                  (SELECT UPPER(value) FROM v$parameter
                   WHERE name = 'undo_tablespace')) t
WHERE  u.begin_time > SYSDATE - 1;

SELECT tablespace_name,
       ROUND(SUM(bytes)/POWER(1024,3),1) undo_alloc_gb,
       ROUND(SUM(CASE WHEN autoextensible='YES' THEN maxbytes ELSE bytes END)
             /POWER(1024,3),1) undo_ceiling_gb
FROM   dba_data_files
WHERE  tablespace_name = (SELECT UPPER(value) FROM v$parameter
                          WHERE name = 'undo_tablespace')
GROUP  BY tablespace_name;

PROMPT ######################################################################
PROMPT # 3.3 REDO - daily archived volume (14 days)
PROMPT # Conversion and index rebuilds spike REDO; cross-check with the FRA
PROMPT # (3.4) and the archivelog backup window.
PROMPT ######################################################################

SELECT TRUNC(completion_time) day,
       COUNT(*) archivelogs,
       ROUND(SUM(blocks*block_size)/POWER(1024,3),1) gb_redo
FROM   v$archived_log
WHERE  completion_time > SYSDATE - 14
GROUP  BY TRUNC(completion_time)
ORDER  BY day DESC;

SELECT COUNT(*) groups, SUM(bytes)/POWER(1024,2) redo_mb_total
FROM   v$log;

SELECT l.thread#, l.group#, l.members, ROUND(l.bytes/1048576) mb,
       l.status, lf.member
FROM   v$log l JOIN v$logfile lf USING (group#)
ORDER  BY l.thread#, l.group#;

PROMPT ######################################################################
PROMPT # 3.4 FAST RECOVERY AREA - space and pressure
PROMPT ######################################################################

SELECT name,
       ROUND(space_limit/POWER(1024,3),1) fra_limit_gb,
       ROUND(space_used/POWER(1024,3),1) fra_used_gb,
       ROUND(space_used/space_limit*100,1) pct_used,
       number_of_files files
FROM   v$recovery_file_dest;

SELECT file_type,
       ROUND(percent_space_used,1) pct_space,
       ROUND(percent_space_reclaimable,1) pct_reclaimable,
       number_of_files
FROM   v$recovery_area_usage
ORDER  BY percent_space_used DESC;

PROMPT ######################################################################
PROMPT # 3.5 GROWTH BASELINE (creates tables - run once)
PROMPT # Re-running the DIFF query after 7/14/30 days measures the real
PROMPT # growth rate per segment (GB/day) - a Phase 1 modeling input.
PROMPT ######################################################################

-- Suggestion: create a dedicated documentation user first
--   CREATE USER fase0_evidence IDENTIFIED BY ...;  (and grant CREATE TABLE)
--   Adjust the owner to your standard.

CREATE TABLE fase0_evidence.seg_baseline_202610 AS
SELECT SYSDATE captured_at, owner, segment_name, partition_name,
       segment_type, tablespace_name, bytes
FROM   dba_segments
WHERE  owner NOT IN ('SYS','SYSTEM','SYSAUX','OUTLN','AUDSYS','DBSNMP','XDB',
                     'WMSYS','MDSYS','ORDDATA','ORDSYS','CTXSYS','EXFSYS',
                     'OLAPSYS','LBACSYS','DVSYS','OJVMSYS','GSMADMIN_INTERNAL')
AND    owner NOT LIKE 'APEX%';

-- Datafiles baseline (to detect consumed autoextend)
CREATE TABLE fase0_evidence.df_baseline_202610 AS
SELECT SYSDATE captured_at, tablespace_name, file_name, bytes, maxbytes,
       autoextensible FROM dba_data_files;

-- DIFF (run on the 2nd capture, replacing the new table name):
--   growth_gb = (bytes now - baseline bytes) / 2^30 ; divide by elapsed
--   days to get GB/day and project 12 months.
-- Example (uncomment and adapt on the 2nd pass):
-- SELECT b.owner, b.segment_name, b.partition_name,
--        ROUND((s.bytes-b.bytes)/POWER(1024,3),2) growth_gb,
--        ROUND((s.bytes-b.bytes)/POWER(1024,3)/
--              (SYSDATE-b.captured_at),3) gb_per_day
-- FROM   fase0_evidence.seg_baseline_202610 b
-- JOIN   (SELECT owner, segment_name, partition_name, bytes
--         FROM dba_segments WHERE owner NOT IN (...)) s
--   ON   s.owner=b.owner AND s.segment_name=b.segment_name
--   AND  NVL(s.partition_name,'-')=NVL(b.partition_name,'-')
-- ORDER  BY growth_gb DESC FETCH FIRST 50 ROWS ONLY;

PROMPT ######################################################################
PROMPT # 3.6 TEMP - space and DW sort/hash peak
PROMPT ######################################################################

SELECT tablespace_name,
       ROUND(tablespace_size/POWER(1024,3),1) total_gb,
       ROUND(free_space/POWER(1024,3),1)  free_gb
FROM   dba_temp_free_space;

SELECT username, session_addr, sql_id,
       ROUND(blocks * t.block_size / POWER(1024,3),2) gb_temp_current
FROM   v$sort_segment s
CROSS JOIN (SELECT block_size FROM dba_tablespaces
            WHERE contents='TEMPORARY' AND ROWNUM=1) t
WHERE  ROWNUM <= 20;

PROMPT ######################################################################
PROMPT # 3.7 RMAN BACKUP - recent windows (cross-check with 3.3/3.4)
PROMPT ######################################################################

SELECT operation, status,
       COUNT(*) executions,
       MIN(start_time) first_run, MAX(end_time) last_run,
       ROUND(SUM((end_time-start_time)*24*60),1) total_minutes
FROM   v$rman_status
WHERE  start_time > SYSDATE - 14
AND    operation IN ('BACKUP','ARCHIVELOG BACKUP','VALIDATE')
GROUP  BY operation, status
ORDER  BY operation, status;

SPOOL OFF
PROMPT END OF STEP 3. Keep the log; repeat the baseline at 7/14/30 days.
