REM ============================================================================
REM PHASE 0 - STEP 4: CONSOLIDATE ALL EVIDENCE INTO MASTER TABLES + CSV (EXCEL)
REM Oracle 19c DW - Partitioning project
REM ----------------------------------------------------------------------------
REM Purpose: join all the evidence scattered across Steps 1, 2 and 2b into
REM TABLES (fase0_evidence.*), and export 3 CSVs ready to open in Excel
REM (';' delimiter). Each CSV = one worksheet tab.
REM
REM   TAB1 tab1_candidates_<dt>.csv <- master_candidates (1 row per table)
REM   TAB2 tab2_columns_<dt>.csv   <- master_columns + time profile + top1
REM                                    value (1 row per column - the most
REM                                    consolidated information per column)
REM   TAB3 tab3_top_values_<dt>.csv<- prof_top_values (top 5 per discrete col)
REM
REM Alternative without CSV: with the master tables created, SQL Developer
REM does SELECT * FROM fase0_evidence.master_candidates -> right-click ->
REM Export -> xlsx. The CSV is the "pure sqlplus" path.
REM
REM STRUCTURE CREATED (all in fase0_evidence):
REM   master_candidates : identification, size, stats, immutability (proxy),
REM                       existing partitioning, bitmaps, MVs, AWR workload
REM   pred_cols         : columns extracted from AWR predicates (heuristic)
REM   master_columns    : column catalog + flags (temporal? in predicates?)
REM   prof_time         : min/max/span/nulls/monthly skew per DATE column
REM   prof_top_values   : top 5 values per equality column
REM
REM LICENSING GATE: AWR columns are only populated if
REM control_management_pack_access contains DIAGNOSTIC. Without the pack the
REM script still runs and those columns stay NULL/'NO' (it never fails).
REM
REM COST: prof_time reads each candidate table 2x per temporal column;
REM prof_top_values 1x per discrete column. Run off-peak.
REM
REM Run: sqlplus as DBA (or owner of the fase0_evidence schema).
REM Prerequisite (once): create the documentation schema:
REM   CREATE USER fase0_evidence IDENTIFIED BY <pwd>
REM     DEFAULT TABLESPACE <ts> QUOTA UNLIMITED ON <ts>;
REM   GRANT CREATE SESSION, CREATE TABLE TO fase0_evidence;
REM ============================================================================

SET ECHO ON FEEDBACK ON LINESIZE 400 PAGESIZE 500 TRIMSPOOL ON SERVEROUTPUT ON SIZE UNLIMITED

DEFINE num_tables = 15
DEFINE measure_buckets = 1
DEFINE measure_top_values = 1

ALTER SESSION SET NLS_DATE_FORMAT = 'YYYY-MM-DD HH24:MI:SS';
ALTER SESSION SET NLS_NUMERIC_CHARACTERS = '.,';

COLUMN captured_at NEW_VALUE v_dt NOPRINT
SELECT TO_CHAR(SYSDATE,'YYYYMMDD_HH24MI') captured_at FROM dual;

SPOOL phase0_04_excel_&&v_dt..log

PROMPT ######################################################################
PROMPT # 1. MASTER TABLE OF CANDIDATES (one row per table)
PROMPT ######################################################################

DROP TABLE fase0_evidence.master_candidates PURGE;
CREATE TABLE fase0_evidence.master_candidates AS
WITH top_tab AS (
  SELECT s.owner, s.segment_name table_name, ROUND(s.bytes/POWER(1024,3),2) gb
  FROM   dba_segments s
  WHERE  s.segment_type = 'TABLE'
  AND    s.owner NOT IN ('SYS','SYSTEM','SYSAUX','OUTLN','AUDSYS','DBSNMP','XDB',
                         'WMSYS','MDSYS','ORDDATA','ORDSYS','CTXSYS','EXFSYS',
                         'OLAPSYS','LBACSYS','DVSYS','OJVMSYS','GSMADMIN_INTERNAL')
  AND    s.owner NOT LIKE 'APEX%'
  ORDER  BY s.bytes DESC
  FETCH FIRST &&num_tables ROWS ONLY)
SELECT tt.owner,
       tt.table_name,
       tt.gb,
       t.num_rows,
       TO_CHAR(t.last_analyzed,'YYYY-MM-DD HH24:MI') stats_asof,
       t.degree      parallel_degree,
       t.iot_type    iot,
       t.cluster_name in_cluster,
       t.compression,
       t.compress_for,
       t.tablespace_name tablespace,
       m.inserts inserts_since_stats,
       m.updates updates_since_stats,
       m.deletes deletes_since_stats,
       m.timestamp mods_measured_at,
       pt.partitioning_type    partitioning_type,
       pt.subpartitioning_type subpartitioning_type,
       pt.partition_count      partition_count,
       (SELECT ROUND(MAX(s2.bytes)/POWER(1024,3),2)
          FROM dba_segments s2
         WHERE s2.owner = tt.owner AND s2.segment_name = tt.table_name
           AND s2.segment_type IN ('TABLE PARTITION','TABLE SUBPARTITION')) largest_partition_gb,
       (SELECT COUNT(*) FROM dba_indexes i
         WHERE i.owner = tt.owner AND i.table_name = tt.table_name
           AND i.index_type = 'BITMAP') bitmap_indexes,
       (SELECT COUNT(*) FROM dba_mviews mv
         WHERE mv.owner = tt.owner AND mv.mview_name = tt.table_name) is_mview,
       (SELECT COUNT(*) FROM dba_mview_detail_relations d
         WHERE d.detailobj_owner = tt.owner
           AND d.detailobj_name  = tt.table_name) dependent_mviews,
       CAST(NULL AS NUMBER)         distinct_sqls_awr,
       CAST(NULL AS VARCHAR2(4000)) predicate_columns,
       CAST(NULL AS VARCHAR2(4000)) awr_access_ops
FROM   top_tab tt
JOIN   dba_tables t ON t.owner = tt.owner AND t.table_name = tt.table_name
LEFT JOIN dba_tab_modifications m
       ON m.table_owner = tt.owner AND m.table_name = tt.table_name
      AND m.partition_name IS NULL
LEFT JOIN dba_part_tables pt
       ON pt.owner = tt.owner AND pt.table_name = tt.table_name;

-- Note: if ORA-00904 on dba_mview_detail_relations, remove only that subselect
-- (the view exists in 19c; in any case the PCT detail will be assessed in
-- Phase 1 with DBMS_MVIEW.EXPLAIN_MVIEW).

PROMPT ######################################################################
PROMPT # 2. AWR PREDICATES -> COLUMNS (heuristic: picks qualified identifiers
PROMPT #    "ALIAS"."COLUMN" from access/filter predicates)
PROMPT ######################################################################

DROP TABLE fase0_evidence.pred_cols PURGE;
CREATE TABLE fase0_evidence.pred_cols (
  object_owner      VARCHAR2(128),
  object_name       VARCHAR2(128),
  predicate_column  VARCHAR2(128));

DECLARE
  v_pack VARCHAR2(30);
BEGIN
  SELECT value INTO v_pack FROM v$parameter WHERE name='control_management_pack_access';
  IF UPPER(v_pack) LIKE 'DIAGNOSTIC%' THEN
    EXECUTE IMMEDIATE q'{
      INSERT INTO fase0_evidence.pred_cols
      SELECT DISTINCT p.object_owner, p.object_name,
             REGEXP_SUBSTR(p.pred, '"[^"]+"\."([^"]+)"', 1, l.lvl, NULL, 1)
      FROM (
        SELECT object_owner, object_name,
               NVL(filter_predicates,' ')||' '||NVL(access_predicates,' ') pred
        FROM   dba_hist_sql_plan
        WHERE  filter_predicates IS NOT NULL
           OR  access_predicates IS NOT NULL
      ) p,
      LATERAL (SELECT LEVEL lvl FROM dual
               CONNECT BY LEVEL <= REGEXP_COUNT(p.pred,'"[^"]+"\."[^"]+"')) l
      WHERE REGEXP_SUBSTR(p.pred,'"[^"]+"\."([^"]+)"',1,l.lvl,NULL,1) IS NOT NULL
    }';
    COMMIT;
  ELSE
    DBMS_OUTPUT.PUT_LINE('> Diagnostics Pack unavailable: pred_cols stays empty;');
    DBMS_OUTPUT.PUT_LINE('> predicate_columns / in_predicates stay NO.');
  END IF;
END;
/

-- Populate the AWR columns of the master table (pack only)
DECLARE
  v_pack VARCHAR2(30);
BEGIN
  SELECT value INTO v_pack FROM v$parameter WHERE name='control_management_pack_access';
  IF UPPER(v_pack) LIKE 'DIAGNOSTIC%' THEN
    EXECUTE IMMEDIATE q'{
      UPDATE fase0_evidence.master_candidates mc
      SET (distinct_sqls_awr, predicate_columns) = (
        SELECT (SELECT COUNT(DISTINCT p.sql_id)
                  FROM dba_hist_sql_plan p
                 WHERE p.object_owner = mc.owner AND p.object_name = mc.table_name),
               (SELECT LISTAGG(pc.predicate_column,', ') WITHIN GROUP (ORDER BY pc.predicate_column)
                  FROM fase0_evidence.pred_cols pc
                 WHERE pc.object_owner = mc.owner AND pc.object_name = mc.table_name)
        FROM dual)
    }';
    EXECUTE IMMEDIATE q'{
      UPDATE fase0_evidence.master_candidates mc
      SET awr_access_ops = (
        SELECT LISTAGG(op,', ') WITHIN GROUP (ORDER BY op)
          FROM (SELECT DISTINCT p.operation||' '||p.options op
                  FROM dba_hist_sql_plan p
                 WHERE p.object_owner = mc.owner AND p.object_name = mc.table_name
                   AND p.operation LIKE 'TABLE ACCESS%'))
    }';
    COMMIT;
  END IF;
END;
/

PROMPT ######################################################################
PROMPT # 3. MASTER TABLE OF COLUMNS (one row per column of the candidates)
PROMPT ######################################################################

DROP TABLE fase0_evidence.master_columns PURGE;
CREATE TABLE fase0_evidence.master_columns AS
WITH top_tab AS (
  SELECT s.owner, s.segment_name table_name
  FROM   dba_segments s
  WHERE  s.segment_type = 'TABLE'
  AND    s.owner NOT IN ('SYS','SYSTEM','SYSAUX','OUTLN','AUDSYS','DBSNMP','XDB',
                         'WMSYS','MDSYS','ORDDATA','ORDSYS','CTXSYS','EXFSYS',
                         'OLAPSYS','LBACSYS','DVSYS','OJVMSYS','GSMADMIN_INTERNAL')
  AND    s.owner NOT LIKE 'APEX%'
  ORDER  BY s.bytes DESC
  FETCH FIRST &&num_tables ROWS ONLY)
SELECT c.owner,
       c.table_name,
       c.column_id   position,
       c.column_name column_name,
       c.data_type   data_type,
       c.nullable    nullable,
       c.num_distinct,
       c.num_nulls,
       c.histogram,
       TO_CHAR(c.last_analyzed,'YYYY-MM-DD') stats_asof,
       CASE WHEN c.data_type IN ('DATE','TIMESTAMP','TIMESTAMP WITH TIME ZONE',
                                 'TIMESTAMP WITH LOCAL TIME ZONE')
            THEN 'YES' ELSE 'NO' END is_temporal,
       CASE WHEN pc.predicate_column IS NOT NULL THEN 'YES' ELSE 'NO' END in_predicates
FROM   dba_tab_columns c
JOIN   top_tab ON top_tab.owner = c.owner AND top_tab.table_name = c.table_name
LEFT JOIN fase0_evidence.pred_cols pc
       ON pc.object_owner = c.owner
      AND pc.object_name  = c.table_name
      AND UPPER(pc.predicate_column) = c.column_name;

PROMPT ######################################################################
PROMPT # 4. TIME PROFILE (full scans - costly!)
PROMPT # min/max/span/nulls/monthly skew per DATE/TIMESTAMP column
PROMPT ######################################################################

DROP TABLE fase0_evidence.prof_time PURGE;
CREATE TABLE fase0_evidence.prof_time (
  owner           VARCHAR2(128),
  table_name      VARCHAR2(128),
  column_name     VARCHAR2(128),
  data_type       VARCHAR2(44),
  min_val         VARCHAR2(20),
  max_val         VARCHAR2(20),
  months_span     NUMBER,
  row_count       NUMBER,
  pct_null        NUMBER(6,2),
  top_month       VARCHAR2(7),
  pct_top_month   NUMBER(6,2),
  measured_at     DATE DEFAULT SYSDATE);

DECLARE
  CURSOR c_cols IS
    SELECT c.owner, c.table_name, c.column_name, c.data_type
    FROM   dba_tab_columns c
    JOIN   fase0_evidence.master_candidates mc
           ON mc.owner = c.owner AND mc.table_name = c.table_name
    WHERE  c.data_type IN ('DATE','TIMESTAMP','TIMESTAMP WITH TIME ZONE',
                           'TIMESTAMP WITH LOCAL TIME ZONE')
    ORDER  BY c.owner, c.table_name, c.column_id;
  v_min        TIMESTAMP;
  v_max        TIMESTAMP;
  v_rows       NUMBER;
  v_not_null   NUMBER;
  v_top_bucket VARCHAR2(7);
  v_top_rows   NUMBER;
  v_span       NUMBER;
  v_stmt       VARCHAR2(4000);
  FUNCTION q(p_name VARCHAR2) RETURN VARCHAR2 IS
  BEGIN RETURN DBMS_ASSERT.SIMPLE_SQL_NAME(p_name); END;
  FUNCTION qsch(p_name VARCHAR2) RETURN VARCHAR2 IS
  BEGIN RETURN DBMS_ASSERT.SCHEMA_NAME(p_name); END;
BEGIN
  FOR r IN c_cols LOOP
    v_stmt := 'SELECT MIN('||q(r.column_name)||'), MAX('||q(r.column_name)||'), COUNT(*), COUNT('||q(r.column_name)||')'
           || ' FROM '||qsch(r.owner)||'.'||q(r.table_name);
    EXECUTE IMMEDIATE v_stmt INTO v_min, v_max, v_rows, v_not_null;

    IF &&measure_buckets = 1 AND v_not_null > 0 THEN
      v_stmt := 'SELECT TO_CHAR('||q(r.column_name)||',''YYYY-MM''), COUNT(*)'
             || ' FROM '||qsch(r.owner)||'.'||q(r.table_name)
             || ' WHERE '||q(r.column_name)||' IS NOT NULL'
             || ' GROUP BY TO_CHAR('||q(r.column_name)||',''YYYY-MM'')'
             || ' ORDER BY COUNT(*) DESC FETCH FIRST 1 ROWS ONLY';
      BEGIN
        EXECUTE IMMEDIATE v_stmt INTO v_top_bucket, v_top_rows;
      EXCEPTION WHEN NO_DATA_FOUND THEN
        v_top_bucket := '-'; v_top_rows := 0;
      END;
    ELSE
      v_top_bucket := '-'; v_top_rows := 0;
    END IF;

    v_span := ROUND(MONTHS_BETWEEN(TRUNC(CAST(v_max AS DATE),'MM'),
                                   TRUNC(CAST(v_min AS DATE),'MM')));
    INSERT INTO fase0_evidence.prof_time
      (owner, table_name, column_name, data_type, min_val, max_val, months_span,
       row_count, pct_null, top_month, pct_top_month, measured_at)
    VALUES
      (r.owner, r.table_name, r.column_name, r.data_type,
       TO_CHAR(v_min,'YYYY-MM-DD HH24:MI:SS'),
       TO_CHAR(v_max,'YYYY-MM-DD HH24:MI:SS'),
       v_span, v_rows,
       ROUND((v_rows - v_not_null)/NULLIF(v_rows,0)*100,2),
       v_top_bucket,
       ROUND(v_top_rows/NULLIF(v_not_null,0)*100,2),
       SYSDATE);
  END LOOP;
  COMMIT;
END;
/

PROMPT ######################################################################
PROMPT # 5. TOP 5 VALUES PER EQUALITY COLUMN (full scans)
PROMPT ######################################################################

DROP TABLE fase0_evidence.prof_top_values PURGE;
CREATE TABLE fase0_evidence.prof_top_values (
  owner        VARCHAR2(128),
  table_name   VARCHAR2(128),
  column_name  VARCHAR2(128),
  position     NUMBER,
  value        VARCHAR2(4000),
  cnt          NUMBER,
  pct_of_total NUMBER(6,2),
  measured_at  DATE DEFAULT SYSDATE);

DECLARE
  CURSOR c_cols IS
    SELECT c.owner, c.table_name, c.column_name, c.num_distinct
    FROM   dba_tab_columns c
    JOIN   fase0_evidence.master_candidates mc
           ON mc.owner = c.owner AND mc.table_name = c.table_name
    WHERE  c.data_type IN ('VARCHAR2','NVARCHAR2','CHAR','NCHAR','NUMBER')
    AND    c.num_distinct BETWEEN 2 AND 2000
    ORDER  BY c.owner, c.table_name, c.column_id;
  v_val   VARCHAR2(4000);
  v_cnt   NUMBER;
  v_tot   NUMBER;
  v_rank  NUMBER;
  v_stmt  VARCHAR2(4000);
  FUNCTION q(p_name VARCHAR2) RETURN VARCHAR2 IS
  BEGIN RETURN DBMS_ASSERT.SIMPLE_SQL_NAME(p_name); END;
  FUNCTION qsch(p_name VARCHAR2) RETURN VARCHAR2 IS
  BEGIN RETURN DBMS_ASSERT.SCHEMA_NAME(p_name); END;
BEGIN
  IF &&measure_top_values = 1 THEN
    FOR r IN c_cols LOOP
      v_stmt := 'SELECT COUNT(*) FROM '||qsch(r.owner)||'.'||q(r.table_name);
      EXECUTE IMMEDIATE v_stmt INTO v_tot;

      v_stmt := 'SELECT RTRIM(TO_CHAR('||q(r.column_name)||')), COUNT(*)'
             || ' FROM '||qsch(r.owner)||'.'||q(r.table_name)
             || ' GROUP BY '||q(r.column_name)
             || ' ORDER BY COUNT(*) DESC FETCH FIRST 5 ROWS ONLY';
      v_rank := 0;
      DECLARE
        TYPE t_cur IS REF CURSOR;
        c t_cur;
      BEGIN
        OPEN c FOR v_stmt;
        LOOP
          FETCH c INTO v_val, v_cnt;
          EXIT WHEN c%NOTFOUND;
          v_rank := v_rank + 1;
          INSERT INTO fase0_evidence.prof_top_values
            (owner, table_name, column_name, position, value, cnt, pct_of_total, measured_at)
          VALUES
            (r.owner, r.table_name, r.column_name, v_rank, v_val, v_cnt,
             ROUND(v_cnt/NULLIF(v_tot,0)*100,2), SYSDATE);
        END LOOP;
        CLOSE c;
      END;
    END LOOP;
    COMMIT;
  ELSE
    DBMS_OUTPUT.PUT_LINE('> measure_top_values=0: prof_top_values stays empty.');
  END IF;
END;
/

PROMPT ######################################################################
PROMPT # 6. CSV EXPORT (3 files = 3 Excel tabs)
PROMPT # ';' delimiter for direct Excel import (PT/EN locale).
PROMPT # Each block: enable CSV -> SPOOL -> SELECT -> SPOOL OFF -> disable.
PROMPT ######################################################################

SET FEEDBACK OFF

SET MARKUP CSV ON DELIMITER ';' QUOTE ON
SPOOL tab1_candidates_&&v_dt..csv
SELECT * FROM fase0_evidence.master_candidates ORDER BY gb DESC;
SPOOL OFF
SET MARKUP CSV OFF

SET MARKUP CSV ON DELIMITER ';' QUOTE ON
SPOOL tab2_columns_&&v_dt..csv
SELECT mc.owner, mc.table_name, mc.column_name, mc.position, mc.data_type, mc.nullable,
       mc.num_distinct, mc.num_nulls, mc.histogram, mc.stats_asof,
       mc.is_temporal, mc.in_predicates,
       pt.min_val, pt.max_val, pt.months_span, pt.row_count, pt.pct_null,
       pt.top_month, pt.pct_top_month,
       tv.value top1_value, tv.pct_of_total top1_pct
FROM   fase0_evidence.master_columns mc
LEFT JOIN fase0_evidence.prof_time pt
       ON pt.owner = mc.owner AND pt.table_name = mc.table_name AND pt.column_name = mc.column_name
LEFT JOIN fase0_evidence.prof_top_values tv
       ON tv.owner = mc.owner AND tv.table_name = mc.table_name AND tv.column_name = mc.column_name
      AND tv.position = 1
ORDER  BY mc.owner, mc.table_name, mc.position;
SPOOL OFF
SET MARKUP CSV OFF

SET MARKUP CSV ON DELIMITER ';' QUOTE ON
SPOOL tab3_top_values_&&v_dt..csv
SELECT * FROM fase0_evidence.prof_top_values
ORDER  BY owner, table_name, column_name, position;
SPOOL OFF
SET MARKUP CSV OFF

SET FEEDBACK ON
SET MARKUP CSV OFF

PROMPT ######################################################################
PROMPT # DONE. Files produced:
PROMPT #   tab1_candidates_&&v_dt..csv   (1 row per candidate table)
PROMPT #   tab2_columns_&&v_dt..csv     (1 row per column - consolidated tab)
PROMPT #   tab3_top_values_&&v_dt..csv  (top 5 values - detail)
PROMPT #
PROMPT # How to use in Excel:
PROMPT #   1. Open each CSV in Excel (data falls into columns, ';' PT).
PROMPT #   2. Or: copy each CSV into a tab of the master workbook
PROMPT #      (Phase0_Template_EN.xlsx has the tabs and headers aligned).
PROMPT #   3. Alternative: SQL Developer -> SELECT on the
PROMPT #      fase0_evidence.* tables -> Export -> xlsx (keeps formatting).
PROMPT #
PROMPT # Persistent tables (reusable in Phases 1/2):
PROMPT #   fase0_evidence.master_candidates / master_columns /
PROMPT #   prof_time / prof_top_values / pred_cols
PROMPT ######################################################################

SPOOL OFF
