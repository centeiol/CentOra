REM ============================================================================
REM PHASE 0 - STEP 2b: COLUMN PROFILE OF THE CANDIDATE TABLES
REM Oracle 19c DW - Partitioning project
REM ----------------------------------------------------------------------------
REM Fills the gap between inventory (Step 1) and workload (Step 2):
REM provides the COLUMN-level data needed by the six partitioning key
REM quality tests:
REM   A. Column catalog: type, nullability, distinct count, histogram,
REM      statistics freshness + immutability proxy (updates since last
REM      statistics, via dba_tab_modifications)
REM   B. Time profile: for each DATE/TIMESTAMP column of the candidates:
REM      MIN, MAX, span in months, null %, monthly skew (top bucket)
REM   C. Value skew: top 5 values with counts, for equality columns
REM      (VARCHAR2/NUMBER of low/medium cardinality)
REM
REM COST: section B performs 2 full scans of the table PER temporal column
REM        (1 for min/max/count, 1 for the monthly bucket); C performs 1 per
REM        equality column. On 1-2 TB tables allow minutes per column.
REM        Run off-peak. Parts can be disabled:
REM          DEFINE measure_buckets = 0    (min/max/count only, no bucket)
REM          DEFINE measure_top_values = 0
REM
REM Run: sqlplus DBA. Adjust &&num_tables to the real number of candidates.
REM ============================================================================

SET ECHO ON FEEDBACK ON LINESIZE 250 PAGESIZE 300 TRIMSPOOL ON SERVEROUTPUT ON SIZE UNLIMITED FORMAT WRAPPED

DEFINE num_tables = 15
DEFINE measure_buckets = 1
DEFINE measure_top_values = 1

ALTER SESSION SET NLS_DATE_FORMAT = 'YYYY-MM-DD HH24:MI:SS';

COLUMN captured_at NEW_VALUE v_dt NOPRINT
SELECT TO_CHAR(SYSDATE,'YYYYMMDD_HH24MI') captured_at FROM dual;

SPOOL phase0_02b_columns_&&v_dt..log

PROMPT ######################################################################
PROMPT # A. COLUMN CATALOG OF THE CANDIDATE TABLES (dictionary - fast)
PROMPT # num_distinct/histogram are only as good as the statistics:
PROMPT # check col_analyzed/tab_analyzed before trusting the numbers.
PROMPT ######################################################################

WITH top_tab AS (
  SELECT owner, segment_name table_name
  FROM   dba_segments
  WHERE  segment_type = 'TABLE'
  AND    owner NOT IN ('SYS','SYSTEM','SYSAUX','OUTLN','AUDSYS','DBSNMP','XDB',
                       'WMSYS','MDSYS','ORDDATA','ORDSYS','CTXSYS','EXFSYS',
                       'OLAPSYS','LBACSYS','DVSYS','OJVMSYS','GSMADMIN_INTERNAL')
  AND    owner NOT LIKE 'APEX%'
  ORDER  BY bytes DESC
  FETCH FIRST &&num_tables ROWS ONLY)
SELECT c.owner, c.table_name, c.column_id, c.column_name, c.data_type,
       c.data_length, c.data_precision, c.data_scale, c.nullable,
       c.num_distinct, c.num_nulls, c.histogram,
       TO_CHAR(c.last_analyzed,'YYYY-MM-DD') col_analyzed,
       TO_CHAR(t.last_analyzed,'YYYY-MM-DD') tab_analyzed
FROM   dba_tab_columns c
JOIN   top_tab ON top_tab.owner = c.owner AND top_tab.table_name = c.table_name
JOIN   dba_tables t ON t.owner = c.owner AND t.table_name = c.table_name
WHERE  c.data_type NOT IN ('BLOB','CLOB','NCLOB','LONG','LONG RAW','BFILE')
ORDER  BY c.owner, c.table_name, c.column_id;

PROMPT ######################################################################
PROMPT # A.2 IMMUTABILITY PROXY (whole table, since last statistics)
PROMPT # updates > 0 means the TABLE was updated; it does not guarantee the
PROMPT # candidate column was touched, but it is the alarm that forces
PROMPT # confirmation with the application team before choosing the key.
PROMPT ######################################################################

WITH top_tab AS (
  SELECT owner, segment_name table_name
  FROM   dba_segments
  WHERE  segment_type = 'TABLE'
  AND    owner NOT IN ('SYS','SYSTEM','SYSAUX','OUTLN','AUDSYS','DBSNMP','XDB',
                       'WMSYS','MDSYS','ORDDATA','ORDSYS','CTXSYS','EXFSYS',
                       'OLAPSYS','LBACSYS','DVSYS','OJVMSYS','GSMADMIN_INTERNAL')
  ORDER  BY bytes DESC
  FETCH FIRST &&num_tables ROWS ONLY)
SELECT m.table_owner, m.table_name, m.partition_name,
       m.inserts, m.updates, m.deletes, m.timestamp last_measured
FROM   dba_tab_modifications m
JOIN   top_tab ON top_tab.owner = m.table_owner
              AND top_tab.table_name = m.table_name
ORDER  BY m.table_owner, m.table_name, m.partition_name;

PROMPT ######################################################################
PROMPT # B. TIME PROFILE OF DATE/TIMESTAMP COLUMNS (full scans)
PROMPT # Interpretation (the six key tests):
PROMPT #  - MONTHS vs target retention: does the span cover the intended
PROMPT #    history?
PROMPT #  - PCT_NULL: mass nulls break the key (rows without a date all fall
PROMPT #    at the same extreme/MAXVALUE) - ALERT if > 5%
PROMPT #  - PCT_TOP_MONTH: % of the table in the largest month. Skew > 30-40%
PROMPT #    indicates a useless time granularity or concentrated history
PROMPT #  - MIN/MAX vs sysdate: future data; truncated at 00:00 (pure date is
PROMPT #    a good candidate) vs scattered hours (consider TRUNC / virtual)
PROMPT ######################################################################

DECLARE
  CURSOR c_cols IS
    WITH top_tab AS (
      SELECT owner, segment_name table_name
      FROM   dba_segments
      WHERE  segment_type = 'TABLE'
      AND    owner NOT IN ('SYS','SYSTEM','SYSAUX','OUTLN','AUDSYS','DBSNMP','XDB',
                           'WMSYS','MDSYS','ORDDATA','ORDSYS','CTXSYS','EXFSYS',
                           'OLAPSYS','LBACSYS','DVSYS','OJVMSYS','GSMADMIN_INTERNAL')
      ORDER  BY bytes DESC
      FETCH FIRST &&num_tables ROWS ONLY)
    SELECT c.owner, c.table_name, c.column_name, c.data_type
    FROM   dba_tab_columns c
    JOIN   top_tab ON top_tab.owner = c.owner AND top_tab.table_name = c.table_name
    WHERE  c.data_type IN ('DATE','TIMESTAMP','TIMESTAMP WITH TIME ZONE',
                           'TIMESTAMP WITH LOCAL TIME ZONE')
    ORDER  BY c.owner, c.table_name, c.column_id;
  v_min        TIMESTAMP;
  v_max        TIMESTAMP;
  v_rows       NUMBER;
  v_not_null   NUMBER;
  v_top_bucket VARCHAR2(7);
  v_top_rows   NUMBER;
  v_span       NUMBER;
  v_stmt       VARCHAR2(4000);
  FUNCTION q(p_name VARCHAR2) RETURN VARCHAR2 IS
  BEGIN RETURN DBMS_ASSERT.SIMPLE_SQL_NAME(p_name); END;
  FUNCTION qsch(p_name VARCHAR2) RETURN VARCHAR2 IS
  BEGIN RETURN DBMS_ASSERT.SCHEMA_NAME(p_name); END;
BEGIN
  DBMS_OUTPUT.PUT_LINE('TABLE|COLUMN|TYPE|MIN|MAX|MONTHS|ROWS|PCT_NULL|TOP_MONTH|PCT_IN_TOP_MONTH');
  FOR r IN c_cols LOOP
    v_stmt := 'SELECT MIN('||q(r.column_name)||'), MAX('||q(r.column_name)||'), COUNT(*), COUNT('||q(r.column_name)||')'
           || ' FROM '||qsch(r.owner)||'.'||q(r.table_name);
    EXECUTE IMMEDIATE v_stmt INTO v_min, v_max, v_rows, v_not_null;

    IF &&measure_buckets = 1 AND v_not_null > 0 THEN
      v_stmt := 'SELECT TO_CHAR('||q(r.column_name)||',''YYYY-MM''), COUNT(*)'
             || ' FROM '||qsch(r.owner)||'.'||q(r.table_name)
             || ' WHERE '||q(r.column_name)||' IS NOT NULL'
             || ' GROUP BY TO_CHAR('||q(r.column_name)||',''YYYY-MM'')'
             || ' ORDER BY COUNT(*) DESC FETCH FIRST 1 ROWS ONLY';
      BEGIN
        EXECUTE IMMEDIATE v_stmt INTO v_top_bucket, v_top_rows;
      EXCEPTION WHEN NO_DATA_FOUND THEN
        v_top_bucket := '-'; v_top_rows := 0;
      END;
    ELSE
      v_top_bucket := '-'; v_top_rows := 0;
    END IF;

    v_span := ROUND(MONTHS_BETWEEN(TRUNC(CAST(v_max AS DATE),'MM'),
                                   TRUNC(CAST(v_min AS DATE),'MM')));
    DBMS_OUTPUT.PUT_LINE(
      r.table_name ||'|'|| r.column_name ||'|'|| r.data_type ||'|'||
      TO_CHAR(v_min,'YYYY-MM-DD HH24:MI:SS') ||'|'||
      TO_CHAR(v_max,'YYYY-MM-DD HH24:MI:SS') ||'|'||
      v_span ||'|'|| v_rows ||'|'||
      TO_CHAR(ROUND((v_rows - v_not_null)/NULLIF(v_rows,0)*100,1),'990.0') ||'|'||
      v_top_bucket ||'|'||
      TO_CHAR(ROUND(v_top_rows/NULLIF(v_not_null,0)*100,1),'990.0'));
  END LOOP;
END;
/

PROMPT ######################################################################
PROMPT # C. VALUE SKEW OF EQUALITY COLUMNS (top 5 values per column)
PROMPT # Only columns with 2 to 2000 distinct values per the statistics
PROMPT # (outside that, the histogram or the cardinality already answers).
PROMPT # List/DEFAULT: stable discrete domains = good candidates.
PROMPT # Hash: requires an ALMOST UNIQUE column - if the column has < 100
PROMPT # distinct values, hashing it is the wrong choice.
PROMPT ######################################################################

DECLARE
  CURSOR c_cols IS
    WITH top_tab AS (
      SELECT owner, segment_name table_name
      FROM   dba_segments
      WHERE  segment_type = 'TABLE'
      AND    owner NOT IN ('SYS','SYSTEM','SYSAUX','OUTLN','AUDSYS','DBSNMP','XDB',
                           'WMSYS','MDSYS','ORDDATA','ORDSYS','CTXSYS','EXFSYS',
                           'OLAPSYS','LBACSYS','DVSYS','OJVMSYS','GSMADMIN_INTERNAL')
      ORDER  BY bytes DESC
      FETCH FIRST &&num_tables ROWS ONLY)
    SELECT c.owner, c.table_name, c.column_name, c.data_type, c.num_distinct
    FROM   dba_tab_columns c
    JOIN   top_tab ON top_tab.owner = c.owner AND top_tab.table_name = c.table_name
    WHERE  c.data_type IN ('VARCHAR2','NVARCHAR2','CHAR','NUMBER','NCHAR')
    AND    c.num_distinct BETWEEN 2 AND 2000
    ORDER  BY c.owner, c.table_name, c.column_id;
  v_val  VARCHAR2(4000);
  v_cnt  NUMBER;
  v_tot  NUMBER;
  v_line VARCHAR2(32767);
  v_stmt VARCHAR2(4000);
  FUNCTION q(p_name VARCHAR2) RETURN VARCHAR2 IS
  BEGIN RETURN DBMS_ASSERT.SIMPLE_SQL_NAME(p_name); END;
  FUNCTION qsch(p_name VARCHAR2) RETURN VARCHAR2 IS
  BEGIN RETURN DBMS_ASSERT.SCHEMA_NAME(p_name); END;
BEGIN
  FOR r IN c_cols LOOP
    v_stmt := 'SELECT COUNT(*) FROM '||qsch(r.owner)||'.'||q(r.table_name);
    EXECUTE IMMEDIATE v_stmt INTO v_tot;

    v_stmt := 'SELECT RTRIM(TO_CHAR('||q(r.column_name)||')), COUNT(*)'
           || ' FROM '||qsch(r.owner)||'.'||q(r.table_name)
           || ' GROUP BY '||q(r.column_name)
           || ' ORDER BY COUNT(*) DESC FETCH FIRST 5 ROWS ONLY';
    v_line := r.table_name ||'|'|| r.column_name ||'|'|| r.data_type
            ||'|distinct='|| r.num_distinct ||'|rows='|| v_tot ||' -> ';
    -- explicit loop with a dynamic cursor
    DECLARE
      TYPE t_cur IS REF CURSOR;
      c t_cur;
    BEGIN
      OPEN c FOR v_stmt;
      LOOP
        FETCH c INTO v_val, v_cnt;
        EXIT WHEN c%NOTFOUND;
        v_line := v_line ||' ['||v_val||'='||v_cnt
                ||' ('||TO_CHAR(ROUND(v_cnt/NULLIF(v_tot,0)*100,1),'990.0')||'%)]';
      END LOOP;
      CLOSE c;
    END;
    DBMS_OUTPUT.PUT_LINE(v_line);
  END LOOP;
END;
/

SPOOL OFF
PROMPT END OF STEP 2b. Attach the log to the dossier (section 3b).
