REM ============================================================================
REM PHASE 0 - STEP 4 (ZERO-OBJECT VARIANT): EXCEL OUTPUT WITHOUT CREATING
REM ANY DATABASE OBJECT — ONLY SELECTs
REM Oracle 19c DW - Partitioning project
REM ----------------------------------------------------------------------------
REM This variant creates NOTHING in the database: no tables, no schemas, no
REM SQL Tuning Sets, no baselines. Only SELECT statements run.
REM
REM How it works: the "joining" that the table-based version did inside the
REM database is here done by GENERATING SQL files (client-side, spooled) that
REM contain one big UNION ALL of SELECTs — one SELECT per column. You then run
REM the generated files; they spool the CSVs themselves.
REM
REM   STEP 1 (this file): TAB1 candidates CSV  ->  tab1_candidates_core.csv
REM          (pure SELECT, always safe to run)
REM   STEP 2: generate phase0_gen_columns_<dt>.sql   (run it -> tab2_columns.csv)
REM   STEP 3: generate phase0_gen_topvals_<dt>.sql   (run it -> tab3_top_values.csv)
REM   STEP 4 (OPTIONAL, ONLY IF DIAGNOSTICS PACK LICENSED):
REM          generate phase0_tab1_awr_<dt>.sql (run it -> tab1_awr.csv and
REM          merge its 3 columns into the CANDIDATES tab of the workbook)
REM
REM The generated files also contain ONLY SELECTs. Nothing is persisted in
REM the database by any of these scripts.
REM
REM COST: tab2 generator emits, for each DATE/TIMESTAMP column, subselects
REM that scan the table (min/max/count + monthly bucket if measure_buckets=1);
REM tab3 scans once per discrete column. Off-peak. Nothing else is heavy.
REM
REM Run: sqlplus as DBA (in the DW PDB). Adjust DEFINE num_tables.
REM Template: Phase0_Template_EN.xlsx (same headers as the table-based kit).
REM ============================================================================

SET ECHO ON FEEDBACK ON LINESIZE 2000 PAGESIZE 500 TRIMSPOOL ON SERVEROUTPUT ON SIZE UNLIMITED FORMAT WRAPPED

DEFINE num_tables = 15
DEFINE measure_buckets = 1

ALTER SESSION SET NLS_DATE_FORMAT = 'YYYY-MM-DD HH24:MI:SS';
ALTER SESSION SET NLS_NUMERIC_CHARACTERS = '.,';

COLUMN captured_at NEW_VALUE v_dt NOPRINT
SELECT TO_CHAR(SYSDATE,'YYYYMMDD_HH24MI') captured_at FROM dual;

SPOOL phase0_04_noobj_&&v_dt..log

PROMPT ######################################################################
PROMPT # STEP 1: TAB1 — CANDIDATES (pure SELECT, always safe)
PROMPT ######################################################################

SET MARKUP CSV ON DELIMITER ';' QUOTE ON
SPOOL tab1_candidates_core_&&v_dt..csv
WITH top_tab AS (
  SELECT s.owner, s.segment_name table_name, ROUND(s.bytes/POWER(1024,3),2) gb
  FROM   dba_segments s
  WHERE  s.segment_type = 'TABLE'
  AND    s.owner NOT IN ('SYS','SYSTEM','SYSAUX','OUTLN','AUDSYS','DBSNMP','XDB')
  AND    s.owner NOT IN ('WMSYS','MDSYS','ORDDATA','ORDSYS','CTXSYS','EXFSYS',
                         'OLAPSYS','LBACSYS','DVSYS','OJVMSYS','GSMADMIN_INTERNAL')
  AND    s.owner NOT LIKE 'APEX%'
  ORDER  BY s.bytes DESC
  FETCH FIRST &&num_tables ROWS ONLY)
SELECT tt.owner,
       tt.table_name,
       tt.gb,
       t.num_rows,
       TO_CHAR(t.last_analyzed,'YYYY-MM-DD HH24:MI') stats_asof,
       t.degree      parallel_degree,
       t.iot_type    iot,
       t.cluster_name in_cluster,
       t.compression,
       t.compress_for,
       t.tablespace_name tablespace,
       m.inserts inserts_since_stats,
       m.updates updates_since_stats,
       m.deletes deletes_since_stats,
       m.timestamp mods_measured_at,
       pt.partitioning_type,
       pt.subpartitioning_type,
       pt.partition_count,
       (SELECT ROUND(MAX(s2.bytes)/POWER(1024,3),2)
          FROM dba_segments s2
         WHERE s2.owner = tt.owner AND s2.segment_name = tt.table_name
           AND s2.segment_type IN ('TABLE PARTITION','TABLE SUBPARTITION')) largest_partition_gb,
       (SELECT COUNT(*) FROM dba_indexes i
         WHERE i.owner = tt.owner AND i.table_name = tt.table_name
           AND i.index_type = 'BITMAP') bitmap_indexes,
       (SELECT COUNT(*) FROM dba_mviews mv
         WHERE mv.owner = tt.owner AND mv.mview_name = tt.table_name) is_mview,
       (SELECT COUNT(*) FROM dba_mview_detail_relations d
         WHERE d.detailobj_owner = tt.owner
           AND d.detailobj_name  = tt.table_name) dependent_mviews
FROM   top_tab tt
JOIN   dba_tables t ON t.owner = tt.owner AND t.table_name = tt.table_name
LEFT JOIN dba_tab_modifications m
       ON m.table_owner = tt.owner AND m.table_name = tt.table_name
      AND m.partition_name IS NULL
LEFT JOIN dba_part_tables pt
       ON pt.owner = tt.owner AND pt.table_name = tt.table_name
ORDER  BY tt.gb DESC;
SPOOL OFF
SET MARKUP CSV OFF

PROMPT ######################################################################
PROMPT # STEP 2: GENERATE phase0_gen_columns_<dt>.sql (UNION ALL of SELECTs,
REM one per column of the candidates, with the full consolidated profile)
REM Then:  @phase0_gen_columns_<dt>.sql   ->  tab2_columns_<dt>.csv
PROMPT ######################################################################

SPOOL phase0_gen_columns_&&v_dt..sql
DECLARE
  CURSOR c_cols IS
    WITH top_tab AS (
      SELECT s.owner, s.segment_name table_name
      FROM   dba_segments s
      WHERE  s.segment_type = 'TABLE'
      AND    s.owner NOT IN ('SYS','SYSTEM','SYSAUX','OUTLN','AUDSYS','DBSNMP','XDB')
      AND    s.owner NOT IN ('WMSYS','MDSYS','ORDDATA','ORDSYS','CTXSYS','EXFSYS',
                             'OLAPSYS','LBACSYS','DVSYS','OJVMSYS','GSMADMIN_INTERNAL')
      AND    s.owner NOT LIKE 'APEX%'
      ORDER  BY s.bytes DESC
      FETCH FIRST &&num_tables ROWS ONLY)
    SELECT c.owner, c.table_name, c.column_id, c.column_name, c.data_type,
           c.nullable, c.num_distinct, c.num_nulls, c.histogram, c.last_analyzed
    FROM   dba_tab_columns c
    JOIN   top_tab ON top_tab.owner = c.owner AND top_tab.table_name = c.table_name
    WHERE  c.data_type NOT IN ('BLOB','CLOB','NCLOB','LONG','LONG RAW','BFILE')
    ORDER  BY c.owner, c.table_name, c.column_id;
  v_dt    VARCHAR2(20);
  v_buf   VARCHAR2(2000);
  v_first BOOLEAN := TRUE;
  PROCEDURE emit(p_line VARCHAR2) IS
  BEGIN DBMS_OUTPUT.PUT_LINE(p_line); END;
  PROCEDURE add_item(p_piece VARCHAR2) IS
  BEGIN
    IF v_buf IS NULL THEN v_buf := '   '; END IF;
    v_buf := v_buf || ' ' || p_piece;
    IF LENGTH(v_buf) > 320 THEN
      DBMS_OUTPUT.PUT_LINE(v_buf);
      v_buf := '   ';
    END IF;
  END;
  PROCEDURE add_last(p_piece VARCHAR2) IS
  BEGIN
    IF v_buf IS NULL THEN v_buf := '   '; END IF;
    v_buf := v_buf || ' ' || RTRIM(p_piece, ',');
    IF LENGTH(v_buf) > 320 THEN
      DBMS_OUTPUT.PUT_LINE(v_buf);
      v_buf := '   ';
    END IF;
  END;
  PROCEDURE end_branch IS
  BEGIN
    v_buf := RTRIM(RTRIM(v_buf), ',');
    IF v_buf IS NOT NULL AND LENGTH(v_buf) > 3 THEN
      DBMS_OUTPUT.PUT_LINE(v_buf);
    END IF;
    v_buf := NULL;
    emit('FROM dual');
  END;
  FUNCTION q(p_name VARCHAR2) RETURN VARCHAR2 IS
  BEGIN RETURN DBMS_ASSERT.SIMPLE_SQL_NAME(p_name); END;
  FUNCTION qsch(p_name VARCHAR2) RETURN VARCHAR2 IS
  BEGIN RETURN DBMS_ASSERT.SCHEMA_NAME(p_name); END;
  FUNCTION lit_str(p_val VARCHAR2) RETURN VARCHAR2 IS
  BEGIN
    IF p_val IS NULL THEN RETURN 'NULL';
    ELSE RETURN '''' || REPLACE(p_val,'''','''''') || ''''; END IF;
  END;
  FUNCTION lit_num(p_val NUMBER) RETURN VARCHAR2 IS
  BEGIN
    IF p_val IS NULL THEN RETURN 'NULL'; ELSE RETURN TO_CHAR(p_val); END IF;
  END;
BEGIN
  SELECT TO_CHAR(SYSDATE,'YYYYMMDD_HH24MI') INTO v_dt FROM dual;
  emit('-- GENERATED FILE - read-only: only SELECTs. Run with:');
  emit('--   @phase0_gen_columns_' || v_dt || '.sql');
  emit('SET LINESIZE 2000');
  emit(q'[SET MARKUP CSV ON DELIMITER ';' QUOTE ON]');
  emit('SET FEEDBACK OFF');
  emit(q'[ALTER SESSION SET NLS_NUMERIC_CHARACTERS = '.,';]');
  emit('SPOOL tab2_columns_' || v_dt || '.csv');
  FOR r IN c_cols LOOP
    DECLARE
      v_t   VARCHAR2(300) := qsch(r.owner) || '.' || q(r.table_name);
      v_c   VARCHAR2(150) := q(r.column_name);
      v_ist BOOLEAN := r.data_type IN ('DATE','TIMESTAMP','TIMESTAMP WITH TIME ZONE',
                                       'TIMESTAMP WITH LOCAL TIME ZONE');
      v_isd BOOLEAN := r.data_type IN ('VARCHAR2','NVARCHAR2','CHAR','NCHAR','NUMBER')
                       AND r.num_distinct BETWEEN 2 AND 2000;
      v_str VARCHAR2(400);
    BEGIN
      v_str := CASE WHEN r.data_type = 'NUMBER'
                    THEN 'RTRIM(TO_CHAR(' || v_c || ',''TM9''))'
                    ELSE 'RTRIM(TO_CHAR(' || v_c || '))' END;
      IF v_first THEN v_first := FALSE; ELSE emit('UNION ALL'); END IF;
      add_item('SELECT ' || lit_str(r.owner)          || ' owner,');
      add_item(lit_str(r.table_name)                  || ' table_name,');
      add_item(lit_str(r.column_name)                 || ' column_name,');
      add_item(TO_CHAR(r.column_id)                   || ' position,');
      add_item(lit_str(r.data_type)                   || ' data_type,');
      add_item(lit_str(r.nullable)                    || ' nullable,');
      add_item(lit_num(r.num_distinct)                || ' num_distinct,');
      add_item(lit_num(r.num_nulls)                   || ' num_nulls,');
      add_item(lit_str(r.histogram)                   || ' histogram,');
      add_item(lit_str(TO_CHAR(r.last_analyzed,'YYYY-MM-DD')) || ' stats_asof,');
      add_item(CASE WHEN v_ist THEN '''YES''' ELSE '''NO''' END || ' is_temporal,');
      add_item('NULL in_predicates,');
      IF v_ist THEN
        add_item('(SELECT TO_CHAR(MIN('||v_c||'),''YYYY-MM-DD HH24:MI:SS'') FROM '||v_t||') min_val,');
        add_item('(SELECT TO_CHAR(MAX('||v_c||'),''YYYY-MM-DD HH24:MI:SS'') FROM '||v_t||') max_val,');
        add_item('(SELECT ROUND(MONTHS_BETWEEN(TRUNC(MAX('||v_c||'),''MM''),TRUNC(MIN('||v_c||'),''MM''))) FROM '||v_t||') months_span,');
        add_item('(SELECT COUNT(*) FROM '||v_t||') row_count,');
        add_item('(SELECT ROUND((COUNT(*)-COUNT('||v_c||'))*100.0/NULLIF(COUNT(*),0),2) FROM '||v_t||') pct_null,');
        IF &&measure_buckets = 1 THEN
          add_item('(SELECT y FROM (SELECT TO_CHAR('||v_c||',''YYYY-MM'') y, COUNT(*) c FROM '||v_t||' WHERE '||v_c||' IS NOT NULL GROUP BY TO_CHAR('||v_c||',''YYYY-MM'') ORDER BY c DESC FETCH FIRST 1 ROWS ONLY)) top_month,');
          add_item('(SELECT ROUND(c*100.0/NULLIF((SELECT COUNT('||v_c||') FROM '||v_t||'),0),2) FROM (SELECT COUNT(*) c FROM '||v_t||' WHERE '||v_c||' IS NOT NULL GROUP BY TO_CHAR('||v_c||',''YYYY-MM'') ORDER BY c DESC FETCH FIRST 1 ROWS ONLY)) pct_top_month,');
        ELSE
          add_item('NULL top_month,');
          add_item('NULL pct_top_month,');
        END IF;
      ELSE
        add_item('NULL min_val,'); add_item('NULL max_val,');
        add_item('NULL months_span,'); add_item('NULL row_count,');
        add_item('NULL pct_null,'); add_item('NULL top_month,');
        add_item('NULL pct_top_month,');
      END IF;
      IF v_isd THEN
        add_item('(SELECT v FROM (SELECT '||v_str||' v, COUNT(*) c FROM '||v_t||' GROUP BY '||v_c||' ORDER BY c DESC FETCH FIRST 1 ROWS ONLY)) top1_value,');
        add_last('(SELECT ROUND(c*100.0/NULLIF((SELECT COUNT(*) FROM '||v_t||'),0),2) FROM (SELECT COUNT(*) c FROM '||v_t||' GROUP BY '||v_c||' ORDER BY c DESC FETCH FIRST 1 ROWS ONLY)) top1_pct,');
      ELSE
        add_item('NULL top1_value,'); add_last('NULL top1_pct,');
      END IF;
      end_branch;
    END;
  END LOOP;
  emit('SPOOL OFF');
  emit('SET MARKUP CSV OFF');
  emit('-- end of generated file');
END;
/
SPOOL OFF

PROMPT ######################################################################
REM # STEP 3: GENERATE phase0_gen_topvals_<dt>.sql (top 5 values per discrete
REM # column). Then:  @phase0_gen_topvals_<dt>.sql -> tab3_top_values_<dt>.csv
PROMPT ######################################################################

SPOOL phase0_gen_topvals_&&v_dt..sql
DECLARE
  CURSOR c_cols IS
    WITH top_tab AS (
      SELECT s.owner, s.segment_name table_name
      FROM   dba_segments s
      WHERE  s.segment_type = 'TABLE'
      AND    s.owner NOT IN ('SYS','SYSTEM','SYSAUX','OUTLN','AUDSYS','DBSNMP','XDB')
      AND    s.owner NOT IN ('WMSYS','MDSYS','ORDDATA','ORDSYS','CTXSYS','EXFSYS',
                             'OLAPSYS','LBACSYS','DVSYS','OJVMSYS','GSMADMIN_INTERNAL')
      AND    s.owner NOT LIKE 'APEX%'
      ORDER  BY s.bytes DESC
      FETCH FIRST &&num_tables ROWS ONLY)
    SELECT c.owner, c.table_name, c.column_name, c.data_type
    FROM   dba_tab_columns c
    JOIN   top_tab ON top_tab.owner = c.owner AND top_tab.table_name = c.table_name
    WHERE  c.data_type IN ('VARCHAR2','NVARCHAR2','CHAR','NCHAR','NUMBER')
    AND    c.num_distinct BETWEEN 2 AND 2000
    ORDER  BY c.owner, c.table_name, c.column_id;
  v_dt    VARCHAR2(20);
  v_buf   VARCHAR2(2000);
  v_first BOOLEAN := TRUE;
  PROCEDURE emit(p_line VARCHAR2) IS
  BEGIN DBMS_OUTPUT.PUT_LINE(p_line); END;
  PROCEDURE add_item(p_piece VARCHAR2) IS
  BEGIN
    IF v_buf IS NULL THEN v_buf := '   '; END IF;
    v_buf := v_buf || ' ' || p_piece;
    IF LENGTH(v_buf) > 320 THEN
      DBMS_OUTPUT.PUT_LINE(v_buf);
      v_buf := '   ';
    END IF;
  END;
  PROCEDURE end_branch IS
  BEGIN
    v_buf := RTRIM(RTRIM(v_buf), ',');
    IF v_buf IS NOT NULL AND LENGTH(v_buf) > 3 THEN
      DBMS_OUTPUT.PUT_LINE(v_buf);
    END IF;
    v_buf := NULL;
  END;
  FUNCTION q(p_name VARCHAR2) RETURN VARCHAR2 IS
  BEGIN RETURN DBMS_ASSERT.SIMPLE_SQL_NAME(p_name); END;
  FUNCTION qsch(p_name VARCHAR2) RETURN VARCHAR2 IS
  BEGIN RETURN DBMS_ASSERT.SCHEMA_NAME(p_name); END;
  FUNCTION lit_str(p_val VARCHAR2) RETURN VARCHAR2 IS
  BEGIN
    IF p_val IS NULL THEN RETURN 'NULL';
    ELSE RETURN '''' || REPLACE(p_val,'''','''''') || ''''; END IF;
  END;
BEGIN
  SELECT TO_CHAR(SYSDATE,'YYYYMMDD_HH24MI') INTO v_dt FROM dual;
  emit('-- GENERATED FILE - read-only: only SELECTs. Run with:');
  emit('--   @phase0_gen_topvals_' || v_dt || '.sql');
  emit('SET LINESIZE 2000');
  emit(q'[SET MARKUP CSV ON DELIMITER ';' QUOTE ON]');
  emit('SET FEEDBACK OFF');
  emit(q'[ALTER SESSION SET NLS_NUMERIC_CHARACTERS = '.,';]');
  emit('SPOOL tab3_top_values_' || v_dt || '.csv');
  FOR r IN c_cols LOOP
    DECLARE
      v_t   VARCHAR2(300) := qsch(r.owner) || '.' || q(r.table_name);
      v_c   VARCHAR2(150) := q(r.column_name);
      v_str VARCHAR2(400) :=
        CASE WHEN r.data_type = 'NUMBER'
             THEN 'RTRIM(TO_CHAR(' || v_c || ',''TM9''))'
             ELSE 'RTRIM(TO_CHAR(' || v_c || '))' END;
    BEGIN
      IF v_first THEN v_first := FALSE; ELSE emit('UNION ALL'); END IF;
      add_item('SELECT ' || lit_str(r.owner)     || ' owner,');
      add_item(lit_str(r.table_name)             || ' table_name,');
      add_item(lit_str(r.column_name)            || ' column_name,');
      add_item('ROW_NUMBER() OVER (ORDER BY c DESC) position,');
      add_item('v value,');
      add_item('c cnt,');
      add_item('ROUND(c*100.0/NULLIF(tot,0),2) pct_of_total,');
      add_item('SYSDATE measured_at,');
      add_item('FROM (SELECT '||v_str||' v, COUNT(*) c FROM '||v_t||' GROUP BY '||v_c||' ORDER BY c DESC FETCH FIRST 5 ROWS ONLY)');
      add_item('CROSS JOIN (SELECT COUNT(*) tot FROM '||v_t||')');
      end_branch;
    END;
  END LOOP;
  emit('SPOOL OFF');
  emit('SET MARKUP CSV OFF');
  emit('-- end of generated file');
END;
/
SPOOL OFF

PROMPT ######################################################################
REM # STEP 4 (OPTIONAL - ONLY IF DIAGNOSTICS PACK LICENSED):
REM # generate phase0_tab1_awr_<dt>.sql (table-level AWR columns to merge
REM # into the CANDIDATES tab of the workbook). If not licensed, the
REM # generated file contains only a comment and is safe to run anyway.
PROMPT ######################################################################

SPOOL phase0_tab1_awr_&&v_dt..sql
DECLARE
  v_pack VARCHAR2(30);
  v_dt   VARCHAR2(20);
  PROCEDURE emit(p_line VARCHAR2) IS
  BEGIN DBMS_OUTPUT.PUT_LINE(p_line); END;
BEGIN
  SELECT value INTO v_pack FROM v$parameter WHERE name='control_management_pack_access';
  SELECT TO_CHAR(SYSDATE,'YYYYMMDD_HH24MI') INTO v_dt FROM dual;
  IF UPPER(v_pack) LIKE 'DIAGNOSTIC%' THEN
    emit('-- GENERATED FILE - read-only: only SELECTs. Run with:');
    emit('--   @phase0_tab1_awr_' || v_dt || '.sql   ->  tab1_awr_' || v_dt || '.csv');
    emit('SET LINESIZE 2000');
    emit(q'[SET MARKUP CSV ON DELIMITER ';' QUOTE ON]');
    emit('SET FEEDBACK OFF');
    emit('SPOOL tab1_awr_' || v_dt || '.csv');
    emit(q'[SELECT t.owner, t.table_name,]');
    emit(q'[  (SELECT COUNT(DISTINCT p.sql_id) FROM dba_hist_sql_plan p]');
    emit(q'[    WHERE p.object_owner = t.owner AND p.object_name = t.table_name) distinct_sqls_awr,]');
    emit(q'[  (SELECT LISTAGG(col,', ') WITHIN GROUP (ORDER BY col) FROM (]');
    emit(q'[    SELECT DISTINCT REGEXP_SUBSTR(p.pred, '"[^"]+"\."([^"]+)"', 1, l.lvl, NULL, 1) col]');
    emit(q'[    FROM (SELECT object_owner, object_name,]');
    emit(q'[                 NVL(filter_predicates,' ')||' '||NVL(access_predicates,' ') pred]');
    emit(q'[          FROM dba_hist_sql_plan) p,]');
    emit(q'[         LATERAL (SELECT LEVEL lvl FROM dual]');
    emit(q'[                CONNECT BY LEVEL <= REGEXP_COUNT(p.pred,'"[^"]+"\."[^"]+"')) l]');
    emit(q'[    WHERE p.object_owner = t.owner AND p.object_name = t.table_name]');
    emit(q'[      AND REGEXP_SUBSTR(p.pred,'"[^"]+"\."([^"]+)"',1,l.lvl,NULL,1) IS NOT NULL)) predicate_columns,]');
    emit(q'[  (SELECT LISTAGG(op,', ') WITHIN GROUP (ORDER BY op) FROM (]');
    emit(q'[    SELECT DISTINCT p.operation||' '||p.options op FROM dba_hist_sql_plan p]');
    emit(q'[    WHERE p.object_owner = t.owner AND p.object_name = t.table_name]');
    emit(q'[      AND p.operation LIKE 'TABLE ACCESS%')) awr_access_ops]');
    emit(q'[FROM (]');
    emit(q'[  SELECT s.owner, s.segment_name table_name]');
    emit(q'[  FROM dba_segments s]');
    emit(q'[  WHERE s.segment_type = 'TABLE']');
    emit(q'[    AND s.owner NOT IN ('SYS','SYSTEM','SYSAUX','OUTLN','AUDSYS','DBSNMP','XDB')]');
    emit(q'[    AND s.owner NOT IN ('WMSYS','MDSYS','ORDDATA','ORDSYS','CTXSYS','EXFSYS')]');
    emit(q'[    AND s.owner NOT IN ('OLAPSYS','LBACSYS','DVSYS','OJVMSYS','GSMADMIN_INTERNAL')]');
    emit(q'[    AND s.owner NOT LIKE 'APEX%']');
    emit(q'[  ORDER BY s.bytes DESC]');
    emit(q'[  FETCH FIRST ]' || '&&num_tables' || q'[ ROWS ONLY) t]');
    emit(q'[ORDER BY t.owner, t.table_name;]');
    emit('SPOOL OFF');
    emit('SET MARKUP CSV OFF');
  ELSE
    emit('-- Diagnostics Pack NOT licensed (control_management_pack_access=' || v_pack || ').');
    emit('-- This file was intentionally left empty: run TAB1 core only.');
    emit('-- Predicate columns can be sourced from phase0_02b (manual analysis).');
  END IF;
END;
/
SPOOL OFF

PROMPT ######################################################################
PROMPT # DONE. Files produced so far:
PROMPT #   tab1_candidates_core_&&v_dt..csv          (from STEP 1)
PROMPT #   phase0_gen_columns_&&v_dt..sql           (run it -> tab2_columns CSV)
PROMPT #   phase0_gen_topvals_&&v_dt..sql           (run it -> tab3_top_values CSV)
PROMPT #   phase0_tab1_awr_&&v_dt..sql              (OPTIONAL - pack only)
PROMPT #
PROMPT # Next:
PROMPT #   @phase0_gen_columns_&&v_dt..sql
PROMPT #   @phase0_gen_topvals_&&v_dt..sql
PROMPT # Then paste each CSV into the matching tab of Phase0_Template_EN.xlsx.
PROMPT # NOTE: in_predicates / AWR columns stay empty unless the pack file
PROMPT # was generated (Step 4). No database objects were created at any point.
PROMPT ######################################################################

SPOOL OFF
