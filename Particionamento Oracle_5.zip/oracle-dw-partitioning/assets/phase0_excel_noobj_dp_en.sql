REM ============================================================================
REM PHASE 0 - FOCUSED EXCEL KIT (ZERO-OBJECT + DIAGNOSTICS PACK LICENSED)
REM Oracle 19c DW - Partitioning project
REM ----------------------------------------------------------------------------
REM Prerequisites: Diagnostics Pack LICENSED (control_management_pack_access
REM contains DIAGNOSTIC). This kit creates NOTHING in the database: no tables,
REM no schemas, no SQL Tuning Sets. Only SELECT statements run.
REM
REM Produces the 3 tabs of Phase0_Template_EN.xlsx:
REM   STEP 1: tab1_candidates_<dt>.csv   (full profile incl. AWR columns)
REM   STEP 2: generates phase0_gen_columns_<dt>.sql  -> run -> tab2_columns CSV
REM            (ONE standalone SELECT per column, run statement by statement
REM             into the same CSV: no UNION ALL, no echoed query, heading only
REM             on the first row; consolidated profile, in_predicates from AWR)
REM   STEP 3: generates phase0_gen_topvals_<dt>.sql  -> run -> tab3_top_values CSV
REM            (same statement-by-statement design)
REM
REM The generated files also contain ONLY SELECTs (one per line of output,
REM terminated by ';'), plus SET commands. If one statement fails, the rest
REM still run.
REM
REM COST: temporal columns -> table scans (min/max/count + monthly bucket);
REM discrete columns -> 1 scan (top 5 values); in_predicates/AWR columns ->
REM dictionary work on DBA_HIST_SQL_PLAN only. Run off-peak.
REM
REM Run: sqlplus as DBA (in the DW PDB). Adjust DEFINE num_tables.
REM Template: Phase0_Template_EN.xlsx (headers already aligned).
REM ============================================================================

SET ECHO ON FEEDBACK ON LINESIZE 2000 PAGESIZE 500 TRIMSPOOL ON SERVEROUTPUT ON SIZE UNLIMITED FORMAT WRAPPED

DEFINE num_tables = 15
DEFINE measure_buckets = 1

ALTER SESSION SET NLS_DATE_FORMAT = 'YYYY-MM-DD HH24:MI:SS';
ALTER SESSION SET NLS_NUMERIC_CHARACTERS = '.,';

COLUMN captured_at NEW_VALUE v_dt NOPRINT
SELECT TO_CHAR(SYSDATE,'YYYYMMDD_HH24MI') captured_at FROM dual;

SPOOL phase0_excel_noobj_dp_&&v_dt..log

PROMPT ######################################################################
PROMPT # STEP 1: TAB1 — CANDIDATES (full profile incl. AWR, pure SELECT)
PROMPT ######################################################################

SET MARKUP CSV ON DELIMITER ';' QUOTE ON
SPOOL tab1_candidates_&&v_dt..csv
WITH top_tab AS (
  SELECT s.owner, s.segment_name table_name, ROUND(s.bytes/POWER(1024,3),2) gb
  FROM   dba_segments s
  WHERE  s.segment_type = 'TABLE'
  AND    s.owner NOT IN ('SYS','SYSTEM','SYSAUX','OUTLN','AUDSYS','DBSNMP','XDB')
  AND    s.owner NOT IN ('WMSYS','MDSYS','ORDDATA','ORDSYS','CTXSYS','EXFSYS',
                         'OLAPSYS','LBACSYS','DVSYS','OJVMSYS','GSMADMIN_INTERNAL')
  AND    s.owner NOT LIKE 'APEX%'
  ORDER  BY s.bytes DESC
  FETCH FIRST &&num_tables ROWS ONLY)
SELECT tt.owner,
       tt.table_name,
       tt.gb,
       t.num_rows,
       TO_CHAR(t.last_analyzed,'YYYY-MM-DD HH24:MI') stats_asof,
       t.degree      parallel_degree,
       t.iot_type    iot,
       t.cluster_name in_cluster,
       t.compression,
       t.compress_for,
       t.tablespace_name tablespace,
       m.inserts inserts_since_stats,
       m.updates updates_since_stats,
       m.deletes deletes_since_stats,
       m.timestamp mods_measured_at,
       pt.partitioning_type,
       pt.subpartitioning_type,
       pt.partition_count,
       (SELECT ROUND(MAX(s2.bytes)/POWER(1024,3),2)
          FROM dba_segments s2
         WHERE s2.owner = tt.owner AND s2.segment_name = tt.table_name
           AND s2.segment_type IN ('TABLE PARTITION','TABLE SUBPARTITION')) largest_partition_gb,
       (SELECT COUNT(*) FROM dba_indexes i
         WHERE i.owner = tt.owner AND i.table_name = tt.table_name
           AND i.index_type = 'BITMAP') bitmap_indexes,
       (SELECT COUNT(*) FROM dba_mviews mv
         WHERE mv.owner = tt.owner AND mv.mview_name = tt.table_name) is_mview,
       (SELECT COUNT(*) FROM dba_mview_detail_relations d
         WHERE d.detailobj_owner = tt.owner
           AND d.detailobj_name  = tt.table_name) dependent_mviews,
       (SELECT COUNT(DISTINCT p.sql_id)
          FROM dba_hist_sql_plan p
         WHERE p.object_owner = tt.owner AND p.object_name = tt.table_name) distinct_sqls_awr,
       (SELECT LISTAGG(col,', ') WITHIN GROUP (ORDER BY col)
          FROM (
            SELECT DISTINCT REGEXP_SUBSTR(p.pred,'"[^"]+"\."([^"]+)"',1,l.lvl,NULL,1) col
            FROM (
              SELECT NVL(filter_predicates,' ')||' '||NVL(access_predicates,' ') pred
              FROM   dba_hist_sql_plan
              WHERE  object_owner = tt.owner AND object_name = tt.table_name
                AND (filter_predicates IS NOT NULL OR access_predicates IS NOT NULL)
            ) p,
            LATERAL (SELECT LEVEL lvl FROM dual
                     CONNECT BY LEVEL <= REGEXP_COUNT(p.pred,'"[^"]+"\."[^"]+"')) l
            WHERE REGEXP_SUBSTR(p.pred,'"[^"]+"\."([^"]+)"',1,l.lvl,NULL,1) IS NOT NULL
          )) predicate_columns,
       (SELECT LISTAGG(op,', ') WITHIN GROUP (ORDER BY op)
          FROM (
            SELECT DISTINCT p.operation||' '||p.options op
            FROM   dba_hist_sql_plan p
            WHERE  p.object_owner = tt.owner AND p.object_name = tt.table_name
              AND  p.operation LIKE 'TABLE ACCESS%'
          )) awr_access_ops
FROM   top_tab tt
JOIN   dba_tables t ON t.owner = tt.owner AND t.table_name = tt.table_name
LEFT JOIN dba_tab_modifications m
       ON m.table_owner = tt.owner AND m.table_name = tt.table_name
      AND m.partition_name IS NULL
LEFT JOIN dba_part_tables pt
       ON pt.owner = tt.owner AND pt.table_name = tt.table_name
ORDER  BY tt.gb DESC;
SPOOL OFF
SET MARKUP CSV OFF

PROMPT ######################################################################
PROMPT # STEP 2: GENERATE phase0_gen_columns_<dt>.sql (one SELECT per column,
REM run statement by statement into the same CSV, heading only once)
REM Then:  @phase0_gen_columns_<dt>.sql   ->  tab2_columns_<dt>.csv
PROMPT ######################################################################

SPOOL phase0_gen_columns_&&v_dt..sql
DECLARE
  CURSOR c_cols IS
    WITH top_tab AS (
      SELECT s.owner, s.segment_name table_name
      FROM   dba_segments s
      WHERE  s.segment_type = 'TABLE'
      AND    s.owner NOT IN ('SYS','SYSTEM','SYSAUX','OUTLN','AUDSYS','DBSNMP','XDB')
      AND    s.owner NOT IN ('WMSYS','MDSYS','ORDDATA','ORDSYS','CTXSYS','EXFSYS',
                             'OLAPSYS','LBACSYS','DVSYS','OJVMSYS','GSMADMIN_INTERNAL')
      AND    s.owner NOT LIKE 'APEX%'
      ORDER  BY s.bytes DESC
      FETCH FIRST &&num_tables ROWS ONLY)
    SELECT c.owner, c.table_name, c.column_id, c.column_name, c.data_type,
           c.nullable, c.num_distinct, c.num_nulls, c.histogram, c.last_analyzed
    FROM   dba_tab_columns c
    JOIN   top_tab ON top_tab.owner = c.owner AND top_tab.table_name = c.table_name
    WHERE  c.data_type NOT IN ('BLOB','CLOB','NCLOB','LONG','LONG RAW','BFILE')
    ORDER  BY c.owner, c.table_name, c.column_id;
  v_dt    VARCHAR2(20);
  v_buf   VARCHAR2(2000);
  v_first BOOLEAN := TRUE;
  PROCEDURE emit(p_line VARCHAR2) IS
  BEGIN DBMS_OUTPUT.PUT_LINE(p_line); END;
  PROCEDURE add_item(p_piece VARCHAR2) IS
  BEGIN
    IF v_buf IS NULL THEN v_buf := '   '; END IF;
    v_buf := v_buf || ' ' || p_piece;
    IF LENGTH(v_buf) > 320 THEN
      DBMS_OUTPUT.PUT_LINE(v_buf);
      v_buf := '   ';
    END IF;
  END;
  PROCEDURE add_last(p_piece VARCHAR2) IS
  BEGIN
    IF v_buf IS NULL THEN v_buf := '   '; END IF;
    v_buf := v_buf || ' ' || RTRIM(p_piece, ',');
    IF LENGTH(v_buf) > 320 THEN
      DBMS_OUTPUT.PUT_LINE(v_buf);
      v_buf := '   ';
    END IF;
  END;
  PROCEDURE end_branch IS
  BEGIN
    v_buf := RTRIM(RTRIM(v_buf), ',');
    IF v_buf IS NOT NULL AND LENGTH(v_buf) > 3 THEN
      DBMS_OUTPUT.PUT_LINE(v_buf);
    END IF;
    v_buf := NULL;
    emit('FROM dual;');
  END;
  FUNCTION q(p_name VARCHAR2) RETURN VARCHAR2 IS
  BEGIN RETURN DBMS_ASSERT.SIMPLE_SQL_NAME(p_name); END;
  FUNCTION qsch(p_name VARCHAR2) RETURN VARCHAR2 IS
  BEGIN RETURN DBMS_ASSERT.SCHEMA_NAME(p_name); END;
  FUNCTION lit_str(p_val VARCHAR2) RETURN VARCHAR2 IS
  BEGIN
    IF p_val IS NULL THEN RETURN 'NULL';
    ELSE RETURN '''' || REPLACE(p_val,'''','''''') || ''''; END IF;
  END;
  FUNCTION lit_num(p_val NUMBER) RETURN VARCHAR2 IS
  BEGIN
    IF p_val IS NULL THEN RETURN 'NULL'; ELSE RETURN TO_CHAR(p_val); END IF;
  END;
BEGIN
  SELECT TO_CHAR(SYSDATE,'YYYYMMDD_HH24MI') INTO v_dt FROM dual;
  emit('-- GENERATED FILE - read-only: only SELECTs, ONE PER COLUMN, executed');
  emit('-- statement by statement into the same CSV (no UNION ALL).');
  emit('--   @phase0_gen_columns_' || v_dt || '.sql');
  emit('SET LINESIZE 2000');
  emit('SET ECHO OFF');
  emit('SET FEEDBACK OFF');
  emit('SET PAGESIZE 50000');
  emit(q'[SET MARKUP CSV ON DELIMITER ';' QUOTE ON]');
  emit(q'[ALTER SESSION SET NLS_NUMERIC_CHARACTERS = '.,';]');
  emit('SPOOL tab2_columns_' || v_dt || '.csv');
  emit('SET HEADING ON');
  FOR r IN c_cols LOOP
    DECLARE
      v_t   VARCHAR2(300) := qsch(r.owner) || '.' || q(r.table_name);
      v_c   VARCHAR2(150) := q(r.column_name);
      v_ist BOOLEAN := r.data_type IN ('DATE','TIMESTAMP','TIMESTAMP WITH TIME ZONE',
                                       'TIMESTAMP WITH LOCAL TIME ZONE');
      v_isd BOOLEAN := r.data_type IN ('VARCHAR2','NVARCHAR2','CHAR','NCHAR','NUMBER')
                       AND r.num_distinct BETWEEN 2 AND 2000;
      v_str VARCHAR2(400);
      v_pred VARCHAR2(2000);
    BEGIN
      v_str := CASE WHEN r.data_type = 'NUMBER'
                    THEN 'RTRIM(TO_CHAR(' || v_c || ',''TM9''))'
                    ELSE 'RTRIM(TO_CHAR(' || v_c || '))' END;
      -- in_predicates: EXISTS over the AWR predicate columns of this table
      v_pred :=
        '(SELECT CASE WHEN EXISTS (SELECT 1 FROM ('
        || 'SELECT DISTINCT REGEXP_SUBSTR(p.pred,''"[^"]+"\."([^"]+)"'',1,l.lvl,NULL,1) col '
        || 'FROM (SELECT NVL(filter_predicates,'' '')||'' ''||NVL(access_predicates,'' '') pred '
        || 'FROM dba_hist_sql_plan '
        || 'WHERE object_owner=' || lit_str(r.owner)
        || ' AND object_name=' || lit_str(r.table_name)
        || ' AND (filter_predicates IS NOT NULL OR access_predicates IS NOT NULL)) p, '
        || 'LATERAL (SELECT LEVEL lvl FROM dual '
        || 'CONNECT BY LEVEL <= REGEXP_COUNT(p.pred,''"[^"]+"\."[^"]+"'')) l '
        || ') WHERE col=' || lit_str(r.column_name)
        || ') THEN ''YES'' ELSE ''NO'' END FROM dual) in_predicates,';
      IF v_first THEN v_first := FALSE; ELSE emit('SET HEADING OFF'); END IF;
      add_item('SELECT ' || lit_str(r.owner)          || ' owner,');
      add_item(lit_str(r.table_name)                  || ' table_name,');
      add_item(lit_str(r.column_name)                 || ' column_name,');
      add_item(TO_CHAR(r.column_id)                   || ' position,');
      add_item(lit_str(r.data_type)                   || ' data_type,');
      add_item(lit_str(r.nullable)                    || ' nullable,');
      add_item(lit_num(r.num_distinct)                || ' num_distinct,');
      add_item(lit_num(r.num_nulls)                   || ' num_nulls,');
      add_item(lit_str(r.histogram)                   || ' histogram,');
      add_item(lit_str(TO_CHAR(r.last_analyzed,'YYYY-MM-DD')) || ' stats_asof,');
      add_item(CASE WHEN v_ist THEN '''YES''' ELSE '''NO''' END || ' is_temporal,');
      add_item(v_pred);
      IF v_ist THEN
        add_item('(SELECT TO_CHAR(MIN('||v_c||'),''YYYY-MM-DD HH24:MI:SS'') FROM '||v_t||') min_val,');
        add_item('(SELECT TO_CHAR(MAX('||v_c||'),''YYYY-MM-DD HH24:MI:SS'') FROM '||v_t||') max_val,');
        add_item('(SELECT ROUND(MONTHS_BETWEEN(TRUNC(MAX('||v_c||'),''MM''),TRUNC(MIN('||v_c||'),''MM''))) FROM '||v_t||') months_span,');
        add_item('(SELECT COUNT(*) FROM '||v_t||') row_count,');
        add_item('(SELECT ROUND((COUNT(*)-COUNT('||v_c||'))*100.0/NULLIF(COUNT(*),0),2) FROM '||v_t||') pct_null,');
        IF &&measure_buckets = 1 THEN
          add_item('(SELECT y FROM (SELECT TO_CHAR('||v_c||',''YYYY-MM'') y, COUNT(*) c FROM '||v_t||' WHERE '||v_c||' IS NOT NULL GROUP BY TO_CHAR('||v_c||',''YYYY-MM'') ORDER BY c DESC FETCH FIRST 1 ROWS ONLY)) top_month,');
          add_item('(SELECT ROUND(c*100.0/NULLIF((SELECT COUNT('||v_c||') FROM '||v_t||'),0),2) FROM (SELECT COUNT(*) c FROM '||v_t||' WHERE '||v_c||' IS NOT NULL GROUP BY TO_CHAR('||v_c||',''YYYY-MM'') ORDER BY c DESC FETCH FIRST 1 ROWS ONLY)) pct_top_month,');
        ELSE
          add_item('NULL top_month,');
          add_item('NULL pct_top_month,');
        END IF;
      ELSE
        add_item('NULL min_val,'); add_item('NULL max_val,');
        add_item('NULL months_span,'); add_item('NULL row_count,');
        add_item('NULL pct_null,'); add_item('NULL top_month,');
        add_item('NULL pct_top_month,');
      END IF;
      IF v_isd THEN
        add_item('(SELECT v FROM (SELECT '||v_str||' v, COUNT(*) c FROM '||v_t||' GROUP BY '||v_c||' ORDER BY c DESC FETCH FIRST 1 ROWS ONLY)) top1_value,');
        add_last('(SELECT ROUND(c*100.0/NULLIF((SELECT COUNT(*) FROM '||v_t||'),0),2) FROM (SELECT COUNT(*) c FROM '||v_t||' GROUP BY '||v_c||' ORDER BY c DESC FETCH FIRST 1 ROWS ONLY)) top1_pct,');
      ELSE
        add_item('NULL top1_value,'); add_last('NULL top1_pct,');
      END IF;
      end_branch;
    END;
  END LOOP;
  emit('SPOOL OFF');
  emit('SET MARKUP CSV OFF');
  emit('-- end of generated file');
END;
/
SPOOL OFF

PROMPT ######################################################################
REM # STEP 3: GENERATE phase0_gen_topvals_<dt>.sql (top 5 values per discrete
REM # column, one SELECT per column, statement by statement into one CSV,
REM # heading only once). Then: @phase0_gen_topvals_<dt>.sql -> tab3 CSV
PROMPT ######################################################################

SPOOL phase0_gen_topvals_&&v_dt..sql
DECLARE
  CURSOR c_cols IS
    WITH top_tab AS (
      SELECT s.owner, s.segment_name table_name
      FROM   dba_segments s
      WHERE  s.segment_type = 'TABLE'
      AND    s.owner NOT IN ('SYS','SYSTEM','SYSAUX','OUTLN','AUDSYS','DBSNMP','XDB')
      AND    s.owner NOT IN ('WMSYS','MDSYS','ORDDATA','ORDSYS','CTXSYS','EXFSYS',
                             'OLAPSYS','LBACSYS','DVSYS','OJVMSYS','GSMADMIN_INTERNAL')
      AND    s.owner NOT LIKE 'APEX%'
      ORDER  BY s.bytes DESC
      FETCH FIRST &&num_tables ROWS ONLY)
    SELECT c.owner, c.table_name, c.column_name, c.data_type
    FROM   dba_tab_columns c
    JOIN   top_tab ON top_tab.owner = c.owner AND top_tab.table_name = c.table_name
    WHERE  c.data_type IN ('VARCHAR2','NVARCHAR2','CHAR','NCHAR','NUMBER')
    AND    c.num_distinct BETWEEN 2 AND 2000
    ORDER  BY c.owner, c.table_name, c.column_id;
  v_dt    VARCHAR2(20);
  v_buf   VARCHAR2(2000);
  v_first BOOLEAN := TRUE;
  PROCEDURE emit(p_line VARCHAR2) IS
  BEGIN DBMS_OUTPUT.PUT_LINE(p_line); END;
  PROCEDURE add_item(p_piece VARCHAR2) IS
  BEGIN
    IF v_buf IS NULL THEN v_buf := '   '; END IF;
    v_buf := v_buf || ' ' || p_piece;
    IF LENGTH(v_buf) > 320 THEN
      DBMS_OUTPUT.PUT_LINE(v_buf);
      v_buf := '   ';
    END IF;
  END;
  PROCEDURE end_branch IS
  BEGIN
    v_buf := RTRIM(RTRIM(v_buf), ',');
    IF v_buf IS NOT NULL AND LENGTH(v_buf) > 3 THEN
      DBMS_OUTPUT.PUT_LINE(v_buf);
    END IF;
    v_buf := NULL;
  END;
  FUNCTION q(p_name VARCHAR2) RETURN VARCHAR2 IS
  BEGIN RETURN DBMS_ASSERT.SIMPLE_SQL_NAME(p_name); END;
  FUNCTION qsch(p_name VARCHAR2) RETURN VARCHAR2 IS
  BEGIN RETURN DBMS_ASSERT.SCHEMA_NAME(p_name); END;
  FUNCTION lit_str(p_val VARCHAR2) RETURN VARCHAR2 IS
  BEGIN
    IF p_val IS NULL THEN RETURN 'NULL';
    ELSE RETURN '''' || REPLACE(p_val,'''','''''') || ''''; END IF;
  END;
BEGIN
  SELECT TO_CHAR(SYSDATE,'YYYYMMDD_HH24MI') INTO v_dt FROM dual;
  emit('-- GENERATED FILE - read-only: only SELECTs, ONE PER COLUMN, executed');
  emit('-- statement by statement into the same CSV (no UNION ALL).');
  emit('--   @phase0_gen_topvals_' || v_dt || '.sql');
  emit('SET LINESIZE 2000');
  emit('SET ECHO OFF');
  emit('SET FEEDBACK OFF');
  emit('SET PAGESIZE 50000');
  emit(q'[SET MARKUP CSV ON DELIMITER ';' QUOTE ON]');
  emit(q'[ALTER SESSION SET NLS_NUMERIC_CHARACTERS = '.,';]');
  emit('SPOOL tab3_top_values_' || v_dt || '.csv');
  emit('SET HEADING ON');
  FOR r IN c_cols LOOP
    DECLARE
      v_t   VARCHAR2(300) := qsch(r.owner) || '.' || q(r.table_name);
      v_c   VARCHAR2(150) := q(r.column_name);
      v_str VARCHAR2(400) :=
        CASE WHEN r.data_type = 'NUMBER'
             THEN 'RTRIM(TO_CHAR(' || v_c || ',''TM9''))'
             ELSE 'RTRIM(TO_CHAR(' || v_c || '))' END;
    BEGIN
      IF v_first THEN v_first := FALSE; ELSE emit('SET HEADING OFF'); END IF;
      add_item('SELECT ' || lit_str(r.owner)     || ' owner,');
      add_item(lit_str(r.table_name)             || ' table_name,');
      add_item(lit_str(r.column_name)            || ' column_name,');
      add_item('ROW_NUMBER() OVER (ORDER BY c DESC) position,');
      add_item('v value,');
      add_item('c cnt,');
      add_item('ROUND(c*100.0/NULLIF(tot,0),2) pct_of_total,');
      add_item('SYSDATE measured_at,');
      add_item('FROM (SELECT '||v_str||' v, COUNT(*) c FROM '||v_t||' GROUP BY '||v_c||' ORDER BY c DESC FETCH FIRST 5 ROWS ONLY)');
      add_item('CROSS JOIN (SELECT COUNT(*) tot FROM '||v_t||');');
      end_branch;
    END;
  END LOOP;
  emit('SPOOL OFF');
  emit('SET MARKUP CSV OFF');
  emit('-- end of generated file');
END;
/
SPOOL OFF

PROMPT ######################################################################
PROMPT # DONE. Files:
PROMPT #   tab1_candidates_&&v_dt..csv            (STEP 1)
PROMPT #   phase0_gen_columns_&&v_dt..sql         (run -> tab2_columns CSV)
PROMPT #   phase0_gen_topvals_&&v_dt..sql         (run -> tab3_top_values CSV)
PROMPT #
PROMPT # Next:
PROMPT #   @phase0_gen_columns_&&v_dt..sql
PROMPT #   @phase0_gen_topvals_&&v_dt..sql
PROMPT # Then paste the 3 CSVs into Phase0_Template_EN.xlsx (CANDIDATES,
PROMPT # COLUMNS, TOP_VALUES). No database objects were created at any point.
PROMPT # Note: the generated files run one SELECT per column (statement by
PROMPT # statement, same CSV, headings only once). If one fails, the rest run.
PROMPT ######################################################################

SPOOL OFF
