REM ============================================================================
REM PHASE 0 - STEP 1: GENERAL ENVIRONMENT INVENTORY
REM Oracle 19c DW (~60 TB) - Partitioning project
REM ----------------------------------------------------------------------------
REM Purpose: produce DOCUMENTED evidence of:
REM   1.1 Environment identification (version, RAC, PDB, role)
REM   1.2 Installed options and relevant licensing (Partitioning, packs)
REM   1.3 Tablespaces (type, free space, autoextend)
REM   1.4 Top segments (tables, partitions, indexes, LOBs)
REM   1.5 Existing partitioning (including size skew)
REM   1.6 Materialized views (refresh, compilation state, size)
REM   1.7 Compression already in use
REM   1.8 IOT / cluster tables / declared parallelism
REM
REM Run: sqlplus as a user with data dictionary read privileges
REM      (DBA or SELECT_CATALOG_ROLE). Run in the PDB where the DW lives.
REM      Keep SPOOL active: the .log file is dossier evidence.
REM
REM NOTE: this script changes NOTHING in the database (read-only).
REM       It may run at peak, but off-peak is recommended.
REM ============================================================================

SET ECHO ON FEEDBACK ON LINESIZE 250 PAGESIZE 300 TRIMSPOOL ON SERVEROUTPUT ON SIZE UNLIMITED

ALTER SESSION SET NLS_DATE_FORMAT = 'YYYY-MM-DD HH24:MI:SS';
ALTER SESSION SET NLS_TIMESTAMP_FORMAT = 'YYYY-MM-DD HH24:MI:SS';

COLUMN captured_at NEW_VALUE v_dt NOPRINT
SELECT TO_CHAR(SYSDATE,'YYYYMMDD_HH24MI') captured_at FROM dual;

SPOOL phase0_01_inventory_&&v_dt..log

PROMPT ######################################################################
PROMPT # 1.1 ENVIRONMENT IDENTIFICATION
PROMPT ######################################################################

SELECT SYSDATE capture_moment FROM dual;

SELECT name, db_unique_name, database_role, open_mode, platform_name, log_mode, created
FROM   v$database;

SELECT banner AS full_version FROM v$version;

SELECT instance_name, host_name, status, startup_time, edition
FROM   v$instance;

-- RAC?
SELECT inst_id, instance_name, host_name, status FROM gv$instance ORDER BY inst_id;

-- Multitenant? Which container are we in?
SELECT con_id, name, open_mode FROM v$pdbs ORDER BY con_id;
SELECT sys_context('USERENV','CON_NAME') current_container FROM dual;

-- Standby/Data Guard active? (impacts the online conversion strategy)
SELECT dest_id, status, database_mode, recovery_mode FROM v$archive_dest_status WHERE status <> 'INACTIVE';

PROMPT ######################################################################
PROMPT # 1.2 OPTIONS AND LICENSING
PROMPT ######################################################################

-- Options installed in the binary (TRUE = available in software)
SELECT parameter, value
FROM   v$option
WHERE  UPPER(parameter) IN ('PARTITIONING','REAL APPLICATION CLUSTERS',
                            'ADVANCED COMPRESSION','OLAP','ADVANCED ANALYTICS',
                            'LABEL SECURITY','DATABASE VAULT','IN-MEMORY COLUMN STORE')
ORDER BY parameter;

-- Packs: the parameter reveals whether the functionality is enabled server-side.
-- WARNING: an active value IMPLIES the need for a Diagnostics/Tuning Pack
-- license (see oracle.com - Database Licensing Information User Manual, 19c).
SELECT name, value
FROM   v$parameter
WHERE  name IN ('control_management_pack_access','statistics_level');

-- Usage history detected by Oracle itself (internal audit)
SELECT name, version, detected_usages, total_samples, currently_used,
       first_usage_date, last_usage_date
FROM   dba_feature_usage_statistics
WHERE  LOWER(name) LIKE '%partition%'
   OR  LOWER(name) LIKE '%workload repository%'
   OR  LOWER(name) LIKE '%active session history%'
   OR  LOWER(name) LIKE '%sql monitoring%'
   OR  LOWER(name) LIKE '%sql tuning%'
   OR  LOWER(name) LIKE '%segment advisor%'
   OR  LOWER(name) LIKE '%compression%'
   OR  LOWER(name) LIKE '%data guard%'
ORDER BY name;

PROMPT ######################################################################
PROMPT # 1.3 TABLESPACES
PROMPT ######################################################################

WITH f AS (
  SELECT tablespace_name, SUM(bytes) free_bytes
  FROM   dba_free_space
  GROUP  BY tablespace_name)
SELECT df.tablespace_name,
       t.bigfile, t.extent_management, t.segment_space_management, t.status,
       ROUND(SUM(df.bytes)/POWER(1024,3),1)        alloc_gb,
       ROUND(NVL(f.free_bytes,0)/POWER(1024,3),1)  free_gb,
       ROUND((SUM(df.bytes)-NVL(f.free_bytes,0))/POWER(1024,3),1) used_gb,
       ROUND(SUM(CASE WHEN df.autoextensible='YES' THEN df.maxbytes ELSE df.bytes END)/POWER(1024,3),1) max_autoextend_gb
FROM   dba_data_files df
JOIN   dba_tablespaces t ON t.tablespace_name = df.tablespace_name
LEFT JOIN f ON f.tablespace_name = df.tablespace_name
GROUP  BY df.tablespace_name, t.bigfile, t.extent_management,
          t.segment_space_management, t.status, f.free_bytes
ORDER  BY alloc_gb DESC;

-- Tempfiles
SELECT tablespace_name, ROUND(SUM(bytes)/POWER(1024,3),1) alloc_gb
FROM   dba_temp_files GROUP BY tablespace_name ORDER BY alloc_gb DESC;

-- If the database is not on ASM, ORA-00942 below is expected: ignore it.
SELECT name, state, type,
       ROUND(total_mb/1024,1) total_gb,
       ROUND(free_mb/1024,1)  free_gb,
       ROUND((total_mb-free_mb)/total_mb*100,1) pct_used
FROM   v$asm_diskgroup ORDER BY total_gb DESC;

PROMPT ######################################################################
PROMPT # 1.4 TOP 60 SEGMENTS (tables, partitions, indexes, LOBs)
PROMPT ######################################################################

SELECT owner, segment_name, NVL(partition_name,'-') partition_name,
       segment_type, ROUND(bytes/POWER(1024,3),2) gb, tablespace_name
FROM   dba_segments
WHERE  owner NOT IN ('SYS','SYSTEM','SYSAUX','OUTLN','AUDSYS','DBSNMP','XDB',
                     'WMSYS','MDSYS','ORDDATA','ORDSYS','CTXSYS','EXFSYS',
                     'OLAPSYS','LBACSYS','DVSYS','OJVMSYS','GSMADMIN_INTERNAL')
AND    owner NOT LIKE 'APEX%'
ORDER  BY bytes DESC
FETCH FIRST 60 ROWS ONLY;

PROMPT ######################################################################
PROMPT # 1.4b TOP 50 TABLES (physical size vs estimated row count)
PROMPT NOTE: num_rows comes from the last statistics - see last_analyzed.
PROMPT ######################################################################

SELECT t.owner, t.table_name, t.num_rows,
       TO_CHAR(t.last_analyzed,'YYYY-MM-DD HH24:MI') last_analyzed,
       ROUND(SUM(s.bytes)/POWER(1024,3),2) gb
FROM   dba_tables t
JOIN   dba_segments s ON s.owner = t.owner AND s.segment_name = t.table_name
       AND s.segment_type = 'TABLE'
WHERE  t.owner NOT IN ('SYS','SYSTEM','SYSAUX','OUTLN','AUDSYS','DBSNMP','XDB',
                       'WMSYS','MDSYS','ORDDATA','ORDSYS','CTXSYS','EXFSYS',
                       'OLAPSYS','LBACSYS','DVSYS','OJVMSYS','GSMADMIN_INTERNAL')
AND    t.owner NOT LIKE 'APEX%'
GROUP  BY t.owner, t.table_name, t.num_rows, t.last_analyzed
ORDER  BY gb DESC
FETCH FIRST 50 ROWS ONLY;

PROMPT ######################################################################
PROMPT # 1.4c TOP 50 INDEXES (includes index partitions)
PROMPT ######################################################################

SELECT owner, segment_name, NVL(partition_name,'-') partition_name,
       segment_type, ROUND(SUM(bytes)/POWER(1024,3),2) gb, tablespace_name
FROM   dba_segments
WHERE  segment_type IN ('INDEX','INDEX PARTITION','INDEX SUBPARTITION','IOT INDEX','LOBINDEX')
AND    owner NOT IN ('SYS','SYSTEM','SYSAUX','OUTLN','AUDSYS','DBSNMP','XDB',
                     'WMSYS','MDSYS','ORDDATA','ORDSYS','CTXSYS','EXFSYS',
                     'OLAPSYS','LBACSYS','DVSYS','OJVMSYS','GSMADMIN_INTERNAL')
AND    owner NOT LIKE 'APEX%'
GROUP  BY owner, segment_name, partition_name, segment_type, tablespace_name
ORDER  BY gb DESC
FETCH FIRST 50 ROWS ONLY;

PROMPT ######################################################################
PROMPT # 1.5 EXISTING PARTITIONING
PROMPT ######################################################################

SELECT p.owner, p.table_name, p.partitioning_type, p.subpartitioning_type,
       p.partition_count, p.def_tablespace_name,
       t.num_rows, TO_CHAR(t.last_analyzed,'YYYY-MM-DD') last_analyzed
FROM   dba_part_tables p
JOIN   dba_tables t ON t.owner = p.owner AND t.table_name = p.table_name
WHERE  p.owner NOT IN ('SYS','SYSTEM','SYSAUX','OUTLN','AUDSYS','DBSNMP','XDB',
                       'WMSYS','MDSYS','ORDDATA','ORDSYS','CTXSYS','EXFSYS',
                       'OLAPSYS','LBACSYS','DVSYS','OJVMSYS','GSMADMIN_INTERNAL')
ORDER  BY p.partition_count DESC
FETCH FIRST 60 ROWS ONLY;

-- Skew of the 20 largest partitioned tables: size per partition.
-- Partitions far larger than the others are an ALERT of a poorly chosen
-- key or unbalanced load.
SELECT s.table_owner, s.table_name, s.partition_name, s.segment_type,
       ROUND(SUM(s.bytes)/POWER(1024,3),2) gb
FROM   dba_segments s
WHERE  s.segment_type IN ('TABLE PARTITION','TABLE SUBPARTITION')
AND    (s.table_owner, s.table_name) IN (
         SELECT owner, segment_name
         FROM   dba_segments
         WHERE  segment_type = 'TABLE PARTITION'
         GROUP  BY owner, segment_name
         ORDER  BY SUM(bytes) DESC
         FETCH FIRST 20 ROWS ONLY)
GROUP  BY s.table_owner, s.table_name, s.partition_name, s.segment_type
ORDER  BY s.table_owner, s.table_name, gb DESC
FETCH FIRST 300 ROWS ONLY;

PROMPT ######################################################################
PROMPT # 1.6 MATERIALIZED VIEWS (DW-typical: refresh, state, size)
PROMPT ######################################################################

SELECT m.owner, m.mview_name, m.refresh_method, m.refresh_mode, m.refresh_on,
       m.last_refresh_date, m.compile_state,
       ROUND(SUM(s.bytes)/POWER(1024,3),2) gb
FROM   dba_mviews m
JOIN   dba_segments s ON s.owner = m.owner AND s.segment_name = m.mview_name
GROUP  BY m.owner, m.mview_name, m.refresh_method, m.refresh_mode, m.refresh_on,
          m.last_refresh_date, m.compile_state
ORDER  BY gb DESC
FETCH FIRST 40 ROWS ONLY;

PROMPT ######################################################################
PROMPT # 1.7 COMPRESSION ALREADY IN USE
PROMPT ######################################################################

SELECT owner, segment_type, compression, compress_for,
       COUNT(*) segments, ROUND(SUM(bytes)/POWER(1024,3),1) gb
FROM   dba_segments
WHERE  compression <> 'DISABLED'
AND    owner NOT IN ('SYS','SYSTEM','SYSAUX','OUTLN','AUDSYS','DBSNMP','XDB',
                     'WMSYS','MDSYS','ORDDATA','ORDSYS','CTXSYS','EXFSYS',
                     'OLAPSYS','LBACSYS','DVSYS','OJVMSYS','GSMADMIN_INTERNAL')
GROUP  BY owner, segment_type, compression, compress_for
ORDER  BY gb DESC;

PROMPT ######################################################################
PROMPT # 1.8 IOT / CLUSTER TABLES / DECLARED PARALLEL DEGREE
PROMPT (restrictions for MODIFY PARTITION BY ONLINE and conversion cost)
PROMPT ######################################################################

SELECT owner, table_name, degree, instances, iot_type, cluster_name,
       partitioned, compression, compress_for
FROM   dba_tables
WHERE  owner NOT IN ('SYS','SYSTEM','SYSAUX','OUTLN','AUDSYS','DBSNMP','XDB',
                     'WMSYS','MDSYS','ORDDATA','ORDSYS','CTXSYS','EXFSYS',
                     'OLAPSYS','LBACSYS','DVSYS','OJVMSYS','GSMADMIN_INTERNAL')
AND    owner NOT LIKE 'APEX%'
AND   (degree NOT IN ('1','0') OR instances NOT IN ('1','0')
       OR iot_type IS NOT NULL OR cluster_name IS NOT NULL)
ORDER  BY owner, table_name;

PROMPT ######################################################################
PROMPT # 1.9 LARGE LOBs (outside "normal" tables)
PROMPT ######################################################################

SELECT owner, segment_name table_name, partition_name, segment_type,
       ROUND(bytes/POWER(1024,3),2) gb
FROM   dba_segments
WHERE  segment_type IN ('LOBSEGMENT','LOB PARTITION')
AND    owner NOT IN ('SYS','SYSTEM','SYSAUX','OUTLN','AUDSYS','DBSNMP','XDB',
                     'WMSYS','MDSYS','ORDDATA','ORDSYS','CTXSYS','EXFSYS',
                     'OLAPSYS','LBACSYS','DVSYS','OJVMSYS','GSMADMIN_INTERNAL')
ORDER  BY bytes DESC
FETCH FIRST 30 ROWS ONLY;

SPOOL OFF
PROMPT END OF STEP 1. Keep the log file as dossier evidence.
