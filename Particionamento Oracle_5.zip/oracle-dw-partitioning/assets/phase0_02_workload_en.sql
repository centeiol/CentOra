REM ============================================================================
REM PHASE 0 - STEP 2: DW WORKLOAD PROFILE
REM Oracle 19c - Partitioning project
REM ----------------------------------------------------------------------------
REM Purpose: identify, with historical evidence (AWR):
REM   2.1 Licensing gate: is the Diagnostics Pack available/licensed?
REM   2.2 AWR snapshot time window
REM   2.3 Top SQLs by elapsed time / physical reads
REM   2.4 Text and plans of top SQLs (PREDICATES = future partition key)
REM   2.5 How each large table is accessed (FULL vs INDEX, partitions)
REM   2.6 How many distinct SQLs touch each large table (criticality)
REM   2.7 Time profile (DW load/query windows)
REM   2.8 SQL Tuning Set capture (reusable evidence for Phases 1/2)
REM
REM PLAN B (no Diagnostics Pack): see the section at the end of this file.
REM
REM Run: sqlplus DBA. Adjust &&days (default 7) to AWR retention.
REM NOTE: in a DW the window should cover a full load AND query cycle
REM       (e.g., 7 to 14 days). Default AWR retention is 8 days.
REM ============================================================================

SET ECHO ON FEEDBACK ON LINESIZE 250 PAGESIZE 300 TRIMSPOOL ON SERVEROUTPUT ON SIZE UNLIMITED

DEFINE days = 7

ALTER SESSION SET NLS_DATE_FORMAT = 'YYYY-MM-DD HH24:MI:SS';

COLUMN captured_at NEW_VALUE v_dt NOPRINT
SELECT TO_CHAR(SYSDATE,'YYYYMMDD_HH24MI') captured_at FROM dual;

SPOOL phase0_02_workload_&&v_dt..log

PROMPT ######################################################################
PROMPT # 2.1 GATE: DIAGNOSTICS PACK (AWR/ASH)
PROMPT ######################################################################

-- If the value is NONE, the DBA_HIST_* views are blocked / using them
-- requires a Diagnostics Pack license: stop and use PLAN B at the end.
SELECT value control_management_pack_access
FROM   v$parameter WHERE name = 'control_management_pack_access';

SELECT name, currently_used, detected_usages
FROM   dba_feature_usage_statistics
WHERE  LOWER(name) LIKE '%workload repository%'
   OR  LOWER(name) LIKE '%active session history%';

PROMPT ######################################################################
PROMPT # 2.2 AWR SNAPSHOT TIME WINDOW
PROMPT ######################################################################

SELECT MIN(begin_interval_time) window_start,
       MAX(end_interval_time) window_end,
       COUNT(*) snapshots,
       ROUND(AVG(EXTRACT(SECOND FROM (end_interval_time - begin_interval_time))/60 +
                 EXTRACT(MINUTE FROM (end_interval_time - begin_interval_time)) +
                 EXTRACT(HOUR   FROM (end_interval_time - begin_interval_time))*60),1) avg_interval_min
FROM   dba_hist_snapshot
WHERE  begin_interval_time > SYSDATE - &&days;

-- If the window is empty/shorter than &&days: insufficient AWR retention.
-- To extend it (requires Diagnostics Pack):
--   EXEC dbms_workload_repository.modify_snapshot_settings(retention => 20160, interval => 60);

PROMPT ######################################################################
PROMPT # 2.3 TOP 40 SQLs BY ELAPSED TIME (last &&days days)
PROMPT ######################################################################

SELECT st.sql_id, st.plan_hash_value,
       ROUND(SUM(st.elapsed_time_delta)/1e6/60,1)      minutes,
       SUM(st.executions_delta)                        executions,
       ROUND(SUM(st.disk_reads_delta)/
             NULLIF(SUM(st.executions_delta),0))        reads_per_exec,
       ROUND(SUM(st.rows_processed_delta)/
             NULLIF(SUM(st.executions_delta),0))        rows_per_exec,
       ROUND(SUM(st.physical_read_bytes_delta)/POWER(1024,3),1) gb_physical_reads
FROM   dba_hist_sqlstat st
JOIN   dba_hist_snapshot sn
       ON  sn.snap_id = st.snap_id
       AND sn.dbid = st.dbid
       AND sn.instance_number = st.instance_number
WHERE  sn.begin_interval_time > SYSDATE - &&days
GROUP  BY st.sql_id, st.plan_hash_value
ORDER  BY minutes DESC
FETCH FIRST 40 ROWS ONLY;

PROMPT ######################################################################
PROMPT # 2.3b TEXT OF THE TOP 20 SQLs (for manual classification:
PROMPT      report? ETL? nightly job? record a note in the dossier)
PROMPT ######################################################################

WITH top_sql AS (
  SELECT st.sql_id
  FROM   dba_hist_sqlstat st
  JOIN   dba_hist_snapshot sn
         ON sn.snap_id = st.snap_id AND sn.dbid = st.dbid
         AND sn.instance_number = st.instance_number
  WHERE  sn.begin_interval_time > SYSDATE - &&days
  GROUP  BY st.sql_id
  ORDER  BY SUM(st.elapsed_time_delta) DESC
  FETCH FIRST 20 ROWS ONLY)
SELECT t.sql_id, DBMS_LOB.SUBSTR(t.sql_text,4000) sql_text
FROM   dba_hist_sqltext t
JOIN   top_sql USING (sql_id)
ORDER  BY t.sql_id;

PROMPT ######################################################################
PROMPT # 2.4 PLANS AND PREDICATES OF THE TOP 20 SQLs
PROMPT # >>> This is the most important evidence of Phase 0 <<<
PROMPT # The ACCESS_PREDICATES / FILTER_PREDICATES columns reveal which columns
PROMPT # filter the data = partition key candidates.
PROMPT # Also watch OPTIONS for 'PARTITION RANGE/LIST ...': if you see
PROMPT # 'PARTITION RANGE ALL' in a critical SQL, existing partitioning has
PROMPT # no pruning (ALERT).
PROMPT ######################################################################

WITH top_sql AS (
  SELECT st.sql_id
  FROM   dba_hist_sqlstat st
  JOIN   dba_hist_snapshot sn
         ON sn.snap_id = st.snap_id AND sn.dbid = st.dbid
         AND sn.instance_number = st.instance_number
  WHERE  sn.begin_interval_time > SYSDATE - &&days
  GROUP  BY st.sql_id
  ORDER  BY SUM(st.elapsed_time_delta) DESC
  FETCH FIRST 20 ROWS ONLY)
SELECT p.sql_id, p.plan_hash_value, p.id, p.parent_id,
       p.operation, p.options, p.object_owner, p.object_name, p.object_type,
       p.access_predicates, p.filter_predicates
FROM   dba_hist_sql_plan p
JOIN   top_sql USING (sql_id)
ORDER  BY p.sql_id, p.plan_hash_value, p.id;

PROMPT ######################################################################
PROMPT # 2.5 HOW EACH LARGE TABLE IS ACCESSED (FULL SCAN vs INDEX ...)
PROMPT ######################################################################

WITH top_tab AS (
  SELECT owner, segment_name table_name
  FROM   dba_segments
  WHERE  segment_type = 'TABLE'
  AND    owner NOT IN ('SYS','SYSTEM','SYSAUX','OUTLN','AUDSYS','DBSNMP','XDB',
                       'WMSYS','MDSYS','ORDDATA','ORDSYS','CTXSYS','EXFSYS',
                       'OLAPSYS','LBACSYS','DVSYS','OJVMSYS','GSMADMIN_INTERNAL')
  ORDER  BY bytes DESC
  FETCH FIRST 25 ROWS ONLY)
SELECT t.owner, t.table_name, p.operation, p.options,
       COUNT(DISTINCT p.sql_id) distinct_sqls
FROM   top_tab t
JOIN   dba_hist_sql_plan p
       ON p.object_owner = t.owner AND p.object_name = t.table_name
WHERE  p.sql_id IN (SELECT sql_id FROM dba_hist_sqlstat)
GROUP  BY t.owner, t.table_name, p.operation, p.options
ORDER  BY t.owner, t.table_name, distinct_sqls DESC;

PROMPT ######################################################################
PROMPT # 2.6 CRITICALITY: NUMBER OF DISTINCT SQLs TOUCHING EACH LARGE TABLE
PROMPT ######################################################################

WITH top_tab AS (
  SELECT owner, segment_name table_name
  FROM   dba_segments
  WHERE  segment_type = 'TABLE'
  AND    owner NOT IN ('SYS','SYSTEM','SYSAUX','OUTLN','AUDSYS','DBSNMP','XDB',
                       'WMSYS','MDSYS','ORDDATA','ORDSYS','CTXSYS','EXFSYS',
                       'OLAPSYS','LBACSYS','DVSYS','OJVMSYS','GSMADMIN_INTERNAL')
  ORDER  BY bytes DESC
  FETCH FIRST 25 ROWS ONLY)
SELECT t.owner, t.table_name,
       COUNT(DISTINCT p.sql_id)          distinct_sqls,
       COUNT(DISTINCT p.plan_hash_value) distinct_plans
FROM   top_tab t
JOIN   dba_hist_sql_plan p
       ON p.object_owner = t.owner AND p.object_name = t.table_name
GROUP  BY t.owner, t.table_name
ORDER  BY distinct_sqls DESC;

PROMPT ######################################################################
PROMPT # 2.7 TIME PROFILE (DW load vs query windows)
PROMPT ######################################################################

SELECT TO_CHAR(sample_time,'DY HH24') slot,
       COUNT(*) ash_samples
FROM   dba_hist_active_sess_history
WHERE  sample_time > SYSDATE - &&days
GROUP  BY TO_CHAR(sample_time,'DY HH24')
ORDER  BY 1;

SELECT event, COUNT(*) samples
FROM   dba_hist_active_sess_history
WHERE  sample_time > SYSDATE - &&days
AND    session_type = 'FOREGROUND'
GROUP  BY event
ORDER  BY samples DESC
FETCH FIRST 15 ROWS ONLY;

PROMPT ######################################################################
PROMPT # 2.8 SQL TUNING SET (reusable evidence for Phases 1 and 2)
PROMPT # Stores the workload in a queryable object (DBMS_SQLTUNE).
PROMPT # Creating/loading an STS does NOT require the Tuning Pack; RUNNING the
PROMPT # SQL Tuning Advisor / SQL Access Advisor DOES require a Tuning Pack license.
PROMPT ######################################################################

BEGIN
  dbms_sqltune.create_sqlset(
    sqlset_name => 'PHASE0_DW_STS',
    description => 'Phase 0 - DW workload - evidence for partitioning design');
END;
/

DECLARE
  cur dbms_sqltune.sqlset_cursor;
BEGIN
  OPEN cur FOR
    SELECT VALUE(x)
    FROM   TABLE(dbms_sqltune.select_workload_repository(
             begin_snap     => (SELECT MAX(snap_id)-100 FROM dba_hist_snapshot),
             end_snap       => (SELECT MAX(snap_id)     FROM dba_hist_snapshot),
             basic_filter   => 'parsing_schema_name NOT IN (''SYS'',''SYSTEM'')',
             result_limit   => 1000,
             attribute_list => 'TYPICAL')) x;
  dbms_sqltune.load_sqlset(sqlset_name => 'PHASE0_DW_STS', populate_cursor => cur);
  CLOSE cur;
END;
/

SELECT COUNT(*) stmts_in_sts,
       ROUND(SUM(elapsed_time)/1e6/60,1) total_minutes
FROM   TABLE(dbms_sqltune.select_sqlset('PHASE0_DW_STS'));

PROMPT ######################################################################
PROMPT # PLAN B - IF THE DIAGNOSTICS PACK IS NOT LICENSED
PROMPT ######################################################################
PROMPT # 1) Do NOT run sections 2.3 to 2.8 (they use DBA_HIST_*).
PROMPT # 2) Take your own snapshots, repeating every 6-24h over N days,
PROMPT #    at both load-peak and query-peak times:

-- CAPTURE 1: current SQL cache (point-in-time)
CREATE TABLE phase0_sql_snap AS
SELECT SYSDATE captured_at, sql_id, plan_hash_value, executions,
       elapsed_time, disk_reads, rows_processed,
       DBMS_LOB.SUBSTR(sql_text,4000) sql_text
FROM   v$sql
WHERE  parsing_schema_name NOT IN ('SYS','SYSTEM');

-- CAPTURE 2: for the growth diff, use the baseline tables from
--    phase0_03_capacity_growth_en.sql (section 3.5).

-- CAPTURE 3: current cache plans with predicates
CREATE TABLE phase0_plan_snap AS
SELECT SYSDATE captured_at, sql_id, plan_hash_value, id, parent_id,
       operation, options, object_owner, object_name, object_type,
       access_predicates, filter_predicates
FROM   v$sql_plan
WHERE  sql_id IN (SELECT sql_id FROM v$sql
                  WHERE parsing_schema_name NOT IN ('SYS','SYSTEM'));

-- To analyze later: diff between captures (executions/rows per SQL) and
-- column frequency in filter/access_predicates (text analysis).

SPOOL OFF
PROMPT END OF STEP 2. Keep the log and the STS as evidence.
