---
name: oracle-dw-partitioning
description: "Evidence-based partitioning assessment and design for Oracle data warehouses and VLDBs (12c/19c/21c+). Use when asked to plan, assess, or implement table partitioning in Oracle: Phase 0 evidence gathering (segment inventory, AWR workload predicates, column profiles, capacity/growth), partitioning key and strategy decision framework (Range/Interval, Hash, List, composite, Reference), online conversion planning (MODIFY PARTITION BY ONLINE, DBMS_REDEFINITION), Excel consolidation of evidence, and Oracle licensing gates (Partitioning option, Diagnostics/Tuning Packs)."
---

# Oracle DW Partitioning

Design and deliver table partitioning for Oracle DW/VLDB databases with an accuracy-first, evidence-based method grounded in Oracle's official documentation (VLDB and Partitioning Guide, SQL Language Reference, Licensing Information).

## Operating principles

1. **Accuracy over speed.** No decision without measured evidence; no production step without a test-environment validation (pruning verified with `EXPLAIN PLAN`/`DBMS_XPLAN`, skew measured, top queries timed).
2. **Predicates drive keys.** Table size tells *where* to partition; the filter predicates of the critical SQLs tell *how*. The partitioning key must come from the workload, never from convenience.
3. **Official Oracle documentation first**, especially for version-specific claims and licensing.
4. **Licensing gates before any DDL.** Confirm the Partitioning option (extra-cost, Enterprise Edition only) and check `control_management_pack_access` before touching AWR/ASH.

## Workflow (Phase 0 → 4)

- **Phase 0 — evidence:** run the bundled scripts (below) and produce a dossier. Read `references/phase0-runbook.md` for detailed interpretation per section, acceptance criteria, and the dossier template.
- **Phase 1 — modeling:** choose key + strategy per table from the decision framework below; deliver DDL per table.
- **Phase 2 — validation:** build candidate structures in a test environment; verify pruning (`PSTART/PSTOP`, `PARTITION RANGE/LIST SINGLE/ITERATOR`), measure skew and elapsed time on the top SQLs; simulate PMOs (SPLIT/DROP/TRUNCATE with `UPDATE INDEXES`).
- **Phase 3 — implementation:** convert online, table by table, pilot first; validate stats and critical SQLs after each.
- **Phase 4 — operations:** interval/auto-list partition creation, retention via `DROP/TRUNCATE PARTITION ... UPDATE INDEXES`, read-only/compressed cold tiers, incremental statistics, monitoring.

## Phase 0 scripts (assets/)

Run in order with sqlplus as DBA (in the DW PDB), always with SPOOL on — the logs are the dossier evidence.

| Script | Produces | Cost notes |
|---|---|---|
| `phase0_01_inventory_en.sql` | Environment, options/licensing, tablespaces, top segments, existing partitioning + skew, MVs, compression, IOT/cluster detection | Light; read-only |
| `phase0_02_workload_en.sql` | AWR gate, top SQLs, **plans with ACCESS/FILTER_PREDICATES**, per-table access, time profile, SQL Tuning Set | Needs Diagnostics Pack; Plan B at file end if unlicensed |
| `phase0_02b_columns_en.sql` | Column catalog, immutability proxy (`dba_tab_modifications`), time profile (min/max/span/null %/monthly skew), top values | Full scans per column — off-peak; disable via `DEFINE` flags |
| `phase0_03_capacity_growth_en.sql` | Space/autoextend, UNDO peak, REDO/FRA, TEMP, RMAN windows, growth baseline tables | Creates baseline tables in `fase0_evidence` |
| `phase0_04_excel_dw_en.sql` | Master tables + 3 CSVs (candidates / columns / top values) ready for Excel | Consolidates all evidence; schema `fase0_evidence` required |
| `phase0_04_noobj_en.sql` | **Zero-object variant**: TAB1 as a pure SELECT; spools generated SELECT-only scripts that produce the tab2/tab3 CSVs when run; AWR add-on generated only if the pack is licensed | Use whenever the user forbids creating any object (no tables, schemas, STS, baselines) |
| `phase0_excel_noobj_dp_en.sql` | **Focused zero-object variant for licensed Diagnostics Pack**: one kit producing all 3 Excel tabs with AWR columns (`distinct_sqls_awr`, `predicate_columns`, `awr_access_ops`, per-column `in_predicates`) inlined, no pack gate, nothing created in the DB. Generated files run **one standalone SELECT per column, statement by statement into the same CSV** (`SET ECHO OFF`, headings only on the first statement) — a giant UNION ALL is slow to parse/execute and aborts entirely if one branch fails | Default deliverable when the user says: Excel output + zero objects + Diagnostics Pack licensed |

Deliver the Excel workbook by copying each CSV into the matching tab of `assets/Phase0_Template_EN.xlsx` (headers aligned), or export `fase0_evidence.*` to xlsx from SQL Developer.

## Decision framework (core)

Build the predicate matrix per table (column → predicate type → #critical SQLs), then apply the **six key quality tests**:

1. Immutability (updates on the table since stats = alarm; confirm column with the app team).
2. Alignment with maintenance (retention via `DROP PARTITION`; rolling window loads).
3. Acceptable skew (no value/month holding an excessive share; measure, don't guess).
4. Granularity useful for real filters (partition unit must match typical query ranges).
5. Pruning-compatible syntax (a function on the key kills pruning — use a virtual column instead).
6. Join alignment (large tables joining on a key → partition both on it, or use Reference Partitioning for PK-FK children).

Map predicate type to strategy (pruning rules per Oracle docs: Range/List prune with range, LIKE, equality, IN; **Hash prunes only with equality/IN**):

| Evidence | Strategy | Official requirements |
|---|---|---|
| Dominant business-date range | **Range or Interval** (auto-creates partitions) | Immutable column; monthly/weekly granularity sized by volume and maintenance window |
| Equality on almost-unique column, no time axis | **Hash** | Number of partitions = **power of 2**; multiple of the parallel degree for partition-wise joins |
| Equality on small stable domain | **List** with `DEFAULT` (Auto-List for emerging values) | Stable value list |
| Time axis + heavy joins on a dimension key | **Composite Range/Interval + Hash subpartitions** (classic DW pattern) | Subpartition template; hash column almost unique |
| Children tied by FK to the parent | **Reference** | PK-FK permanently enabled and validated |
| Valid filter via function on a column | **Virtual column** partitioning | Redefine key as `TRUNC(col)` etc. |

Granularity rules: partition ≈ one maintenance unit (fits the shortest DROP/EXCHANGE/backup window); cover typical query windows in 1–4 partitions; size for projected 12–24 month growth (GB/day from the Phase 0 baseline), not current size.

Anti-patterns to reject: Hash on a range-filtered column (zero pruning); partitioning by load date when business filters use business date; updatable key without `ENABLE ROW MOVEMENT`; subpartitions hash on low-cardinality columns; global indexes on tables with frequent PMOs; bitmap indexes present when enabling compression without the documented UNUSABLE→rebuild sequence.

## Conversion methods (12.2+, incl. 19c)

Prefer, in order:

1. `ALTER TABLE ... MODIFY PARTITION BY ... ONLINE UPDATE INDEXES` — preserves data, triggers, constraints, VPD; DML stays open. Restrictions: no IOT, no domain index (Spatial/Text/XML), no object types; reference-partitioned children convert offline only.
2. `DBMS_REDEFINITION` when method 1 does not apply.
3. New partitioned table + load/`EXCHANGE` (short rename window) as last resort.

After each conversion: `DBMS_STATS` (partition level; `GRANULARITY => 'APPROX_GLOBAL AND PARTITION'` after exchanges), incremental stats (`INCREMENTAL=TRUE`) for ongoing loads, smoke-test the critical SQLs before the next table. Start with 1–2 high-value pilots; define rollback per table (the original table stays intact until the online swap finishes).

## Licensing gates (verify first, always)

- **Partitioning option:** extra-cost, Enterprise Edition only; Oracle audits usage via `DBA_FEATURE_USAGE_STATISTICS`.
- **Diagnostics Pack:** AWR/ASH/ADDM — *any* direct access to `DBA_HIST_*` requires the pack (`control_management_pack_access` gate; Plan B = own snapshots of `v$SQL`/`v$SQL_plan` + manual growth baseline).
- **Tuning Pack:** required to *run* SQL Tuning/SQL Access Advisor; creating/loading a SQL Tuning Set does not require it.
- Statspack exists for backward compatibility only (reporting).

## Version notes

- 19c specifics used throughout the assets: Hybrid Partitioned Tables (19c, cold partitions on external files), online conversion (12.2+), read-only partitions, partial indexes, Auto-List (12.2+), `NLS_NUMERIC_CHARACTERS` for CSV export.
- Real-time statistics (19c) is engineered-systems oriented and off by default since 19.10 — do not design the statistics strategy around it.

## Language

All bundled assets are in English. If the user asks in another language, deliver the same kit translated (scripts' comments/PROMPTs + aliases + template tabs must stay consistent within one kit — never mix languages between the CSV headers and the workbook).
